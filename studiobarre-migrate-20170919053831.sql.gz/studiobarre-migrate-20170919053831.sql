# WordPress MySQL database migration
#
# Generated: Tuesday 19. September 2017 05:38 UTC
# Hostname: localhost
# Database: `studiobarre`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_blog_versions`
#

DROP TABLE IF EXISTS `wp_blog_versions`;


#
# Table structure of table `wp_blog_versions`
#

CREATE TABLE `wp_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_blog_versions`
#

#
# End of data contents of table `wp_blog_versions`
# --------------------------------------------------------



#
# Delete any existing table `wp_blogs`
#

DROP TABLE IF EXISTS `wp_blogs`;


#
# Table structure of table `wp_blogs`
#

CREATE TABLE `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_blogs`
#
INSERT INTO `wp_blogs` ( `blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES
(1, 1, 'studiobarre-demo.com', '/', '2017-07-23 22:58:16', '2017-09-19 04:22:01', 1, 0, 0, 0, 0, 0) ;

#
# End of data contents of table `wp_blogs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://studiobarre-demo.com', 'yes'),
(2, 'home', 'http://studiobarre-demo.com', 'yes'),
(3, 'blogname', 'Studio Barre', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrettcullen@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/blog/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:52:"blog/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:47:"blog/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:28:"blog/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:40:"blog/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:22:"blog/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:49:"blog/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:44:"blog/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:25:"blog/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:37:"blog/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:19:"blog/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:50:"blog/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:45:"blog/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:26:"blog/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:38:"blog/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:20:"blog/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:16:".*wp-signup.php$";s:21:"index.php?signup=true";s:18:".*wp-activate.php$";s:23:"index.php?activate=true";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:52:"blog/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:47:"blog/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:28:"blog/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:40:"blog/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:22:"blog/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:74:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:44:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"blog/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"blog/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"blog/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"blog/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:31:"blog/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:48:"blog/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:43:"blog/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:24:"blog/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:36:"blog/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:18:"blog/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:32:"blog/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"blog/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"blog/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blog/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blog/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"blog/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"blog/([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:25:"blog/([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:45:"blog/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:40:"blog/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:33:"blog/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:40:"blog/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:29:"blog/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:21:"blog/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"blog/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"blog/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"blog/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"blog/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"blog/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'studiobarrecorporate', 'yes'),
(41, 'stylesheet', 'studiobarrecorporate', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '18', 'yes'),
(84, 'page_on_front', '5', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:6:{i:1505815866;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1505818721;a:1:{s:21:"update_network_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1505859068;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1505863870;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1505881475;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(124, 'can_compress_scripts', '1', 'no'),
(133, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1500847950;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(134, 'current_theme', 'Studio Barre Corporate', 'yes'),
(135, 'theme_mods_starter', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1500850589;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(138, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(139, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(140, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(143, 'recently_activated', 'a:0:{}', 'yes'),
(152, 'theme_mods_studiobarrecorporate', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:9:"main_menu";i:2;}}', 'yes'),
(154, 'post_count', '3', 'yes'),
(158, 'WPLANG', '', 'yes'),
(159, 'new_admin_email', 'garrettcullen@yahoo.com', 'yes'),
(162, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(163, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(164, 'rg_form_version', '2.2.4.1', 'yes'),
(167, 'rg_gforms_key', '06531379cf8e19681c4045b7a998bf23', 'yes'),
(168, 'rg_gforms_disable_css', '1', 'yes'),
(169, 'rg_gforms_enable_html5', '0', 'yes'),
(170, 'gform_enable_noconflict', '0', 'yes'),
(171, 'rg_gforms_enable_akismet', '', 'yes'),
(172, 'rg_gforms_captcha_public_key', '', 'yes'),
(173, 'rg_gforms_captcha_private_key', '', 'yes'),
(174, 'rg_gforms_currency', 'USD', 'yes'),
(175, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(176, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(177, 'gf_is_upgrading', '0', 'yes'),
(178, 'gf_previous_db_version', '2.2.3', 'yes'),
(179, 'gf_db_version', '2.2.4.1', 'yes'),
(183, 'category_children', 'a:0:{}', 'yes'),
(226, 'acf_version', '5.6.1', 'yes'),
(227, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNeU9ETjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEEzSURJeE9qSTRPak0yIjtzOjM6InVybCI7czoyNzoiaHR0cDovL3N0dWRpb2JhcnJlLWRlbW8uY29tIjt9', 'yes'),
(228, 'hookturn_acftcp_license_key', '631dfe9835ead92c781c66a4654e1c79', 'yes'),
(231, '2057dd01900c5459c5051c796e8d92e2', 'a:2:{s:7:"timeout";i:1503383891;s:5:"value";s:6696:"{"new_version":"2.1.0","stable_version":"2.1.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2017-08-17 10:11:17","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUwMzQ5NTQ4OTo2MzFkZmU5ODM1ZWFkOTJjNzgxYzY2YTQ2NTRlMWM3OToxNTowOGQ3NmU3YmVhZmQ2Nzc3NzFiYjU5NDMwNGQ5MDA1NzpodHRwQC8vc3R1ZGlvYmFycmUtZGVtby5jb206MA==","download_link":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUwMzQ5NTQ4OTo2MzFkZmU5ODM1ZWFkOTJjNzgxYzY2YTQ2NTRlMWM3OToxNTowOGQ3NmU3YmVhZmQ2Nzc3NzFiYjU5NDMwNGQ5MDA1NzpodHRwQC8vc3R1ZGlvYmFycmUtZGVtby5jb206MA==","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.8 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.1.0\\u00a0released in July 2017<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(233, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7, 5, '_edit_lock', '1503373427:1'),
(8, 5, '_edit_last', '1'),
(9, 5, '_wp_page_template', 'page-home.php'),
(13, 8, '_edit_last', '1'),
(14, 8, '_wp_page_template', 'default'),
(15, 8, '_edit_lock', '1500858543:1'),
(16, 10, '_edit_last', '1'),
(17, 10, '_wp_page_template', 'default'),
(18, 10, '_edit_lock', '1500858553:1'),
(19, 13, '_edit_lock', '1505792784:1'),
(20, 13, '_edit_last', '1'),
(21, 13, '_wp_page_template', 'page-faqs.php'),
(22, 16, '_edit_last', '1'),
(23, 16, '_wp_page_template', 'page-press.php'),
(24, 16, '_edit_lock', '1505799285:1'),
(25, 18, '_edit_last', '1'),
(26, 18, '_wp_page_template', 'default'),
(27, 18, '_edit_lock', '1505792381:1'),
(28, 20, '_edit_lock', '1503377743:1'),
(29, 20, '_edit_last', '1'),
(30, 20, '_wp_page_template', 'page-contact.php'),
(112, 31, '_menu_item_type', 'post_type'),
(113, 31, '_menu_item_menu_item_parent', '0'),
(114, 31, '_menu_item_object_id', '20'),
(115, 31, '_menu_item_object', 'page'),
(116, 31, '_menu_item_target', ''),
(117, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(118, 31, '_menu_item_xfn', ''),
(119, 31, '_menu_item_url', ''),
(121, 32, '_menu_item_type', 'post_type'),
(122, 32, '_menu_item_menu_item_parent', '0'),
(123, 32, '_menu_item_object_id', '18'),
(124, 32, '_menu_item_object', 'page'),
(125, 32, '_menu_item_target', ''),
(126, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(127, 32, '_menu_item_xfn', ''),
(128, 32, '_menu_item_url', ''),
(130, 33, '_menu_item_type', 'post_type'),
(131, 33, '_menu_item_menu_item_parent', '0'),
(132, 33, '_menu_item_object_id', '16'),
(133, 33, '_menu_item_object', 'page'),
(134, 33, '_menu_item_target', ''),
(135, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(136, 33, '_menu_item_xfn', ''),
(137, 33, '_menu_item_url', ''),
(139, 34, '_menu_item_type', 'post_type'),
(140, 34, '_menu_item_menu_item_parent', '0'),
(141, 34, '_menu_item_object_id', '13'),
(142, 34, '_menu_item_object', 'page'),
(143, 34, '_menu_item_target', ''),
(144, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(145, 34, '_menu_item_xfn', ''),
(146, 34, '_menu_item_url', ''),
(166, 37, '_menu_item_type', 'custom'),
(167, 37, '_menu_item_menu_item_parent', '0'),
(168, 37, '_menu_item_object_id', '37'),
(169, 37, '_menu_item_object', 'custom'),
(170, 37, '_menu_item_target', ''),
(171, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(172, 37, '_menu_item_xfn', ''),
(173, 37, '_menu_item_url', '#'),
(175, 38, '_edit_last', '1'),
(176, 38, '_wp_page_template', 'page-about.php'),
(177, 38, '_edit_lock', '1503373446:1'),
(178, 40, '_edit_last', '1'),
(179, 40, '_wp_page_template', 'page-caseresults.php'),
(180, 40, '_edit_lock', '1503374345:1'),
(181, 42, '_edit_lock', '1503373253:1'),
(182, 42, '_edit_last', '1'),
(183, 42, '_wp_page_template', 'page-society.php'),
(184, 44, '_menu_item_type', 'post_type'),
(185, 44, '_menu_item_menu_item_parent', '48'),
(186, 44, '_menu_item_object_id', '42'),
(187, 44, '_menu_item_object', 'page'),
(188, 44, '_menu_item_target', ''),
(189, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(190, 44, '_menu_item_xfn', ''),
(191, 44, '_menu_item_url', ''),
(193, 45, '_menu_item_type', 'post_type'),
(194, 45, '_menu_item_menu_item_parent', '48'),
(195, 45, '_menu_item_object_id', '40'),
(196, 45, '_menu_item_object', 'page'),
(197, 45, '_menu_item_target', ''),
(198, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(199, 45, '_menu_item_xfn', ''),
(200, 45, '_menu_item_url', ''),
(202, 46, '_menu_item_type', 'post_type'),
(203, 46, '_menu_item_menu_item_parent', '48'),
(204, 46, '_menu_item_object_id', '38'),
(205, 46, '_menu_item_object', 'page'),
(206, 46, '_menu_item_target', ''),
(207, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(208, 46, '_menu_item_xfn', ''),
(209, 46, '_menu_item_url', ''),
(210, 48, '_menu_item_type', 'custom'),
(211, 48, '_menu_item_menu_item_parent', '0'),
(212, 48, '_menu_item_object_id', '48'),
(213, 48, '_menu_item_object', 'custom'),
(214, 48, '_menu_item_target', ''),
(215, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(216, 48, '_menu_item_xfn', ''),
(217, 48, '_menu_item_url', ''),
(219, 49, '_menu_item_type', 'custom'),
(220, 49, '_menu_item_menu_item_parent', '0'),
(221, 49, '_menu_item_object_id', '49'),
(222, 49, '_menu_item_object', 'custom'),
(223, 49, '_menu_item_target', ''),
(224, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(225, 49, '_menu_item_xfn', ''),
(226, 49, '_menu_item_url', ''),
(228, 50, '_menu_item_type', 'custom'),
(229, 50, '_menu_item_menu_item_parent', '49'),
(230, 50, '_menu_item_object_id', '50'),
(231, 50, '_menu_item_object', 'custom'),
(232, 50, '_menu_item_target', ''),
(233, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(234, 50, '_menu_item_xfn', ''),
(235, 50, '_menu_item_url', '#'),
(237, 51, '_menu_item_type', 'custom'),
(238, 51, '_menu_item_menu_item_parent', '49'),
(239, 51, '_menu_item_object_id', '51'),
(240, 51, '_menu_item_object', 'custom'),
(241, 51, '_menu_item_target', ''),
(242, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(243, 51, '_menu_item_xfn', ''),
(244, 51, '_menu_item_url', '#'),
(246, 52, '_menu_item_type', 'post_type'),
(247, 52, '_menu_item_menu_item_parent', '49'),
(248, 52, '_menu_item_object_id', '8'),
(249, 52, '_menu_item_object', 'page'),
(250, 52, '_menu_item_target', ''),
(251, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(252, 52, '_menu_item_xfn', ''),
(253, 52, '_menu_item_url', ''),
(254, 56, '_edit_lock', '1505792541:1'),
(255, 56, '_edit_last', '1'),
(258, 58, '_edit_lock', '1503462478:1'),
(259, 58, '_edit_last', '1'),
(262, 60, '_edit_lock', '1505791837:1'),
(263, 60, '_edit_last', '1'),
(268, 63, '_wp_attached_file', '2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM.png'),
(269, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:908;s:6:"height";i:1128;s:4:"file";s:48:"2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"Screen-Shot-2017-09-18-at-8.33.40-PM-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:48:"Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png";s:5:"width";i:241;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:48:"Screen-Shot-2017-09-18-at-8.33.40-PM-768x954.png";s:5:"width";i:768;s:6:"height";i:954;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:49:"Screen-Shot-2017-09-18-at-8.33.40-PM-824x1024.png";s:5:"width";i:824;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(286, 77, '_edit_last', '1'),
(287, 77, '_wp_page_template', 'default'),
(288, 77, '_edit_lock', '1505794501:1'),
(289, 77, '_wp_trash_meta_status', 'publish'),
(290, 77, '_wp_trash_meta_time', '1505794645'),
(291, 77, '_wp_desired_post_slug', 'test') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(5, 1, '2017-07-23 23:31:30', '2017-07-23 23:31:30', '', 'Welcome To Studio Barre', '', 'publish', 'closed', 'closed', '', 'welcome-to-studio-barre', '', '', '2017-07-23 23:33:12', '2017-07-23 23:33:12', '', 0, 'http://studiobarre-demo.com/?page_id=5', 0, 'page', '', 0),
(6, 1, '2017-07-23 23:31:30', '2017-07-23 23:31:30', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-07-23 23:31:30', '2017-07-23 23:31:30', '', 5, 'http://studiobarre-demo.com/blog/2017/07/23/5-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 'Find Your Studio', '', 'publish', 'closed', 'closed', '', 'find-your-studio', '', '', '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 0, 'http://studiobarre-demo.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 'Find Your Studio', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 8, 'http://studiobarre-demo.com/blog/2017/07/24/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 0, 'http://studiobarre-demo.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 10, 'http://studiobarre-demo.com/blog/2017/07/24/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-07-24 01:11:37', '2017-07-24 01:11:37', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2017-07-24 01:11:37', '2017-07-24 01:11:37', '', 10, 'http://studiobarre-demo.com/blog/2017/07/24/10-autosave-v1/', 0, 'revision', '', 0),
(13, 1, '2017-07-24 01:12:00', '2017-07-24 01:12:00', '', 'Questions?', '', 'publish', 'closed', 'closed', '', 'q-a', '', '', '2017-09-19 03:48:45', '2017-09-19 03:48:45', '', 0, 'http://studiobarre-demo.com/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-07-24 01:12:00', '2017-07-24 01:12:00', '', 'Q + A', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-07-24 01:12:00', '2017-07-24 01:12:00', '', 13, 'http://studiobarre-demo.com/blog/2017/07/24/13-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2017-07-24 01:12:09', '2017-07-24 01:12:09', '', 'Press', '', 'publish', 'closed', 'closed', '', 'press', '', '', '2017-09-19 04:22:01', '2017-09-19 04:22:01', '', 0, 'http://studiobarre-demo.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2017-07-24 01:12:09', '2017-07-24 01:12:09', '', 'Press', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-07-24 01:12:09', '2017-07-24 01:12:09', '', 16, 'http://studiobarre-demo.com/blog/2017/07/24/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 0, 'http://studiobarre-demo.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 18, 'http://studiobarre-demo.com/blog/2017/07/24/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2017-07-24 01:12:40', '2017-07-24 01:12:40', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-08-22 04:57:58', '2017-08-22 04:57:58', '', 0, 'http://studiobarre-demo.com/?page_id=20', 0, 'page', '', 0),
(21, 1, '2017-07-24 01:12:40', '2017-07-24 01:12:40', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2017-07-24 01:12:40', '2017-07-24 01:12:40', '', 20, 'http://studiobarre-demo.com/blog/2017/07/24/20-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=31', 13, 'nav_menu_item', '', 0),
(32, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=32', 11, 'nav_menu_item', '', 0),
(33, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', ' ', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=33', 10, 'nav_menu_item', '', 0),
(34, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', '', 'Q + A', '', 'publish', 'closed', 'closed', '', '34', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=34', 9, 'nav_menu_item', '', 0),
(37, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', '', 'Own a Studio', '', 'publish', 'closed', 'closed', '', 'own-a-studio', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=37', 12, 'nav_menu_item', '', 0),
(38, 1, '2017-07-24 01:41:37', '2017-07-24 01:41:37', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'our-story', '', '', '2017-08-22 03:46:26', '2017-08-22 03:46:26', '', 0, 'http://studiobarre-demo.com/?page_id=38', 0, 'page', '', 0),
(39, 1, '2017-07-24 01:41:37', '2017-07-24 01:41:37', '', 'Our Story', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2017-07-24 01:41:37', '2017-07-24 01:41:37', '', 38, 'http://studiobarre-demo.com/blog/2017/07/24/38-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2017-07-24 01:41:51', '2017-07-24 01:41:51', '', 'Client Results', '', 'publish', 'closed', 'closed', '', 'client-results', '', '', '2017-08-22 04:01:24', '2017-08-22 04:01:24', '', 0, 'http://studiobarre-demo.com/?page_id=40', 0, 'page', '', 0),
(41, 1, '2017-07-24 01:41:51', '2017-07-24 01:41:51', '', 'Client Results', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2017-07-24 01:41:51', '2017-07-24 01:41:51', '', 40, 'http://studiobarre-demo.com/blog/2017/07/24/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2017-07-24 01:42:15', '2017-07-24 01:42:15', '', 'The Society', '', 'publish', 'closed', 'closed', '', 'studio-barre-society', '', '', '2017-08-22 03:43:11', '2017-08-22 03:43:11', '', 0, 'http://studiobarre-demo.com/?page_id=42', 0, 'page', '', 0),
(43, 1, '2017-07-24 01:42:15', '2017-07-24 01:42:15', '', 'Studio Barre Society', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-07-24 01:42:15', '2017-07-24 01:42:15', '', 42, 'http://studiobarre-demo.com/blog/2017/07/24/42-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2017-07-24 01:42:55', '2017-07-24 01:42:55', '', 'Studio Barre Society', '', 'publish', 'closed', 'closed', '', '44', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=44', 8, 'nav_menu_item', '', 0),
(45, 1, '2017-07-24 01:42:55', '2017-07-24 01:42:55', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=45', 7, 'nav_menu_item', '', 0),
(46, 1, '2017-07-24 01:42:55', '2017-07-24 01:42:55', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=46', 6, 'nav_menu_item', '', 0),
(48, 1, '2017-08-07 02:00:15', '2017-08-07 02:00:15', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=48', 5, 'nav_menu_item', '', 0),
(49, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', '', 'Find Your Studio', '', 'publish', 'closed', 'closed', '', 'find-your-studio', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', '', 'Location 1', '', 'publish', 'closed', 'closed', '', 'location-1', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=50', 2, 'nav_menu_item', '', 0),
(51, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', '', 'Location 2', '', 'publish', 'closed', 'closed', '', 'location-2', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=51', 3, 'nav_menu_item', '', 0),
(52, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-09-19 03:53:11', '2017-09-19 03:53:11', '', 0, 'http://studiobarre-demo.com/?p=52', 4, 'nav_menu_item', '', 0),
(54, 1, '2017-08-22 03:43:11', '2017-08-22 03:43:11', '', 'The Society', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-08-22 03:43:11', '2017-08-22 03:43:11', '', 42, 'http://studiobarre-demo.com/blog/2017/08/22/42-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2017-08-22 03:46:26', '2017-08-22 03:46:26', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2017-08-22 03:46:26', '2017-08-22 03:46:26', '', 38, 'http://studiobarre-demo.com/blog/2017/08/22/38-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2017-08-28 04:30:02', '2017-08-28 04:30:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'publish', 'open', 'open', '', 'post-one', '', '', '2017-09-19 03:42:21', '2017-09-19 03:42:21', '', 0, 'http://studiobarre-demo.com/?p=56', 0, 'post', '', 0),
(57, 1, '2017-08-23 04:30:02', '2017-08-23 04:30:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-08-23 04:30:02', '2017-08-23 04:30:02', '', 56, 'http://studiobarre-demo.com/blog/2017/08/23/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2017-08-23 04:30:17', '2017-08-23 04:30:17', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Three', '', 'publish', 'open', 'open', '', 'post-three', '', '', '2017-08-23 04:30:17', '2017-08-23 04:30:17', '', 0, 'http://studiobarre-demo.com/?p=58', 0, 'post', '', 0),
(59, 1, '2017-08-23 04:30:17', '2017-08-23 04:30:17', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Three', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-08-23 04:30:17', '2017-08-23 04:30:17', '', 58, 'http://studiobarre-demo.com/blog/2017/08/23/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-07-03 04:30:32', '2017-07-03 04:30:32', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Two', '', 'publish', 'open', 'open', '', 'post-two', '', '', '2017-09-19 03:30:37', '2017-09-19 03:30:37', '', 0, 'http://studiobarre-demo.com/?p=60', 0, 'post', '', 0),
(61, 1, '2017-08-23 04:30:32', '2017-08-23 04:30:32', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Two', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2017-08-23 04:30:32', '2017-08-23 04:30:32', '', 60, 'http://studiobarre-demo.com/blog/2017/08/23/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2017-09-19 03:07:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-09-19 03:07:25', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/?p=62', 0, 'post', '', 0),
(63, 1, '2017-09-19 03:34:07', '2017-09-19 03:34:07', '', 'Screen Shot 2017-09-18 at 8.33.40 PM', '', 'inherit', 'open', 'closed', '', 'screen-shot-2017-09-18-at-8-33-40-pm', '', '', '2017-09-19 03:34:07', '2017-09-19 03:34:07', '', 56, 'http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM.png', 0, 'attachment', 'image/png', 0),
(64, 1, '2017-09-19 03:35:20', '2017-09-19 03:35:20', '<img class="alignleft size-medium wp-image-63" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:35:20', '2017-09-19 03:35:20', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2017-09-19 03:36:12', '2017-09-19 03:36:12', '<img class="alignleft size-medium wp-image-63" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:36:12', '2017-09-19 03:36:12', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2017-09-19 03:36:33', '2017-09-19 03:36:33', '<img class="size-medium wp-image-63 aligncenter" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:36:33', '2017-09-19 03:36:33', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2017-09-19 03:37:03', '2017-09-19 03:37:03', '<img class="size-medium wp-image-63 alignright" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:37:03', '2017-09-19 03:37:03', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2017-09-19 03:37:28', '2017-09-19 03:37:28', '<img class="alignright wp-image-63 size-full" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM.png" alt="" width="908" height="1128" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:37:28', '2017-09-19 03:37:28', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2017-09-19 03:38:25', '2017-09-19 03:38:25', '<img class="alignright wp-image-63 size-large" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-824x1024.png" alt="" width="824" height="1024" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:38:25', '2017-09-19 03:38:25', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2017-09-19 03:38:41', '2017-09-19 03:38:41', '<img class="alignright wp-image-63 size-medium" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:38:41', '2017-09-19 03:38:41', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2017-09-19 03:42:21', '2017-09-19 03:42:21', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:42:21', '2017-09-19 03:42:21', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2017-09-19 03:48:24', '2017-09-19 03:48:24', '', 'FAQs', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-09-19 03:48:24', '2017-09-19 03:48:24', '', 13, 'http://studiobarre-demo.com/blog/13-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2017-09-19 03:48:45', '2017-09-19 03:48:45', '', 'Questions?', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-09-19 03:48:45', '2017-09-19 03:48:45', '', 13, 'http://studiobarre-demo.com/blog/13-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2017-09-19 04:07:36', '2017-09-19 04:07:36', 'afa s f sfv sfv sf vs fdv sfv sf vs fdv sdfv sdf vsd fv sdfvs f', 'Press', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-09-19 04:07:36', '2017-09-19 04:07:36', '', 16, 'http://studiobarre-demo.com/blog/16-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-09-19 04:15:02', '2017-09-19 04:15:02', '', 'Press', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-09-19 04:15:02', '2017-09-19 04:15:02', '', 16, 'http://studiobarre-demo.com/blog/16-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2017-09-19 04:15:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-09-19 04:15:41', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/?p=76', 0, 'post', '', 0),
(77, 1, '2017-09-19 04:15:51', '2017-09-19 04:15:51', 'ads ads v sv sv sf', 'test', '', 'trash', 'closed', 'closed', '', 'test__trashed', '', '', '2017-09-19 04:17:25', '2017-09-19 04:17:25', '', 0, 'http://studiobarre-demo.com/?page_id=77', 0, 'page', '', 0),
(78, 1, '2017-09-19 04:15:51', '2017-09-19 04:15:51', '', 'test', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-09-19 04:15:51', '2017-09-19 04:15:51', '', 77, 'http://studiobarre-demo.com/blog/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2017-09-19 04:17:16', '2017-09-19 04:17:16', 'ads ads v sv sv sf', 'test', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-09-19 04:17:16', '2017-09-19 04:17:16', '', 77, 'http://studiobarre-demo.com/blog/77-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_registration_log`
#

DROP TABLE IF EXISTS `wp_registration_log`;


#
# Table structure of table `wp_registration_log`
#

CREATE TABLE `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `IP` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_registration_log`
#

#
# End of data contents of table `wp_registration_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Corporate Newsletter Signup', '2017-07-24 04:24:57', 1, 0),
(2, 'Contact Us Form', '2017-08-22 04:54:11', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8_unicode_ci,
  `entries_grid_meta` longtext COLLATE utf8_unicode_ci,
  `confirmations` longtext COLLATE utf8_unicode_ci,
  `notifications` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Corporate Newsletter Signup","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"email","id":1,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1}],"version":"2.2.3","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null}', NULL, '{"59757699129c8":{"id":"59757699129c8","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"597576991242d":{"id":"597576991242d","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(2, '{"title":"Contact Us Form","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":6,"label":"Phone","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","pageNumber":1},{"type":"text","id":4,"label":"Which Studio\\/Location are you inquiring about?","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Comment","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.4.1","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null}', NULL, '{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2017-07-24 04:26:39', '::1', 63),
(2, 1, '2017-08-06 20:34:41', '::1', 214),
(3, 1, '2017-08-08 04:34:19', '::1', 52),
(4, 1, '2017-08-22 03:16:51', '::1', 129),
(5, 2, '2017-08-22 05:07:34', '::1', 29),
(6, 1, '2017-08-23 03:44:58', '::1', 58),
(7, 1, '2017-09-19 03:03:22', '::1', 97) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` longtext COLLATE utf8_unicode_ci NOT NULL,
  `submission` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `note_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_signups`
#

DROP TABLE IF EXISTS `wp_signups`;


#
# Table structure of table `wp_signups`
#

CREATE TABLE `wp_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` longtext COLLATE utf8_unicode_ci NOT NULL,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `meta` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_signups`
#

#
# End of data contents of table `wp_signups`
# --------------------------------------------------------



#
# Delete any existing table `wp_site`
#

DROP TABLE IF EXISTS `wp_site`;


#
# Table structure of table `wp_site`
#

CREATE TABLE `wp_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_site`
#
INSERT INTO `wp_site` ( `id`, `domain`, `path`) VALUES
(1, 'studiobarre-demo.com', '/') ;

#
# End of data contents of table `wp_site`
# --------------------------------------------------------



#
# Delete any existing table `wp_sitemeta`
#

DROP TABLE IF EXISTS `wp_sitemeta`;


#
# Table structure of table `wp_sitemeta`
#

CREATE TABLE `wp_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_sitemeta`
#
INSERT INTO `wp_sitemeta` ( `meta_id`, `site_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'site_name', 'Studio Barre Sites'),
(2, 1, 'admin_email', 'garrettcullen@yahoo.com'),
(3, 1, 'admin_user_id', '1'),
(4, 1, 'registration', 'none'),
(5, 1, 'upload_filetypes', 'jpg jpeg png gif mov avi mpg 3gp 3g2 midi mid pdf doc ppt odt pptx docx pps ppsx xls xlsx key mp3 ogg m4a wav mp4 m4v webm ogv flv'),
(6, 1, 'blog_upload_space', '100'),
(7, 1, 'fileupload_maxk', '1500'),
(8, 1, 'site_admins', 'a:1:{i:0;s:9:"destroyer";}'),
(9, 1, 'allowedthemes', 'a:2:{s:20:"studiobarrecorporate";b:1;s:15:"twentyseventeen";b:1;}'),
(10, 1, 'illegal_names', 'a:9:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:5:"files";i:8;s:4:"blog";}'),
(11, 1, 'wpmu_upgrade_site', '38590'),
(12, 1, 'welcome_email', 'Howdy USERNAME,\n\nYour new SITE_NAME site has been successfully set up at:\nBLOG_URL\n\nYou can log in to the administrator account with the following information:\n\nUsername: USERNAME\nPassword: PASSWORD\nLog in here: BLOG_URLwp-login.php\n\nWe hope you enjoy your new site. Thanks!\n\n--The Team @ SITE_NAME'),
(13, 1, 'first_post', 'Welcome to %s. This is your first post. Edit or delete it, then start blogging!'),
(14, 1, 'siteurl', 'http://studiobarre-demo.com/'),
(15, 1, 'add_new_users', '0'),
(16, 1, 'upload_space_check_disabled', '1'),
(17, 1, 'subdomain_install', '0'),
(18, 1, 'global_terms_enabled', '0'),
(19, 1, 'ms_files_rewriting', '0'),
(20, 1, 'initial_db_version', '38590'),
(21, 1, 'active_sitewide_plugins', 'a:4:{s:29:"gravityforms/gravityforms.php";i:1500870274;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:1502076040;s:34:"advanced-custom-fields-pro/acf.php";i:1503373044;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:1503373044;}'),
(22, 1, 'WPLANG', 'en_US'),
(28, 1, 'user_count', '1'),
(29, 1, 'blog_count', '1'),
(30, 1, 'can_compress_scripts', '1'),
(37, 1, 'recently_activated', 'a:0:{}'),
(76, 1, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1505799511;}'),
(162, 1, 'registrationnotification', 'yes'),
(163, 1, 'welcome_user_email', 'Howdy USERNAME,\n\nYour new account is set up.\n\nYou can log in with the following information:\nUsername: USERNAME\nPassword: PASSWORD\nLOGINLINK\n\nThanks!\n\n--The Team @ SITE_NAME') ;

#
# End of data contents of table `wp_sitemeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(31, 2, 0),
(32, 2, 0),
(33, 2, 0),
(34, 2, 0),
(37, 2, 0),
(44, 2, 0),
(45, 2, 0),
(46, 2, 0),
(48, 2, 0),
(49, 2, 0),
(50, 2, 0),
(51, 2, 0),
(52, 2, 0),
(56, 1, 0),
(58, 1, 0),
(60, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'nav_menu', '', 0, 13) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Nav', 'top-nav', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'destroyer'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"654a2e8ffeaec65247eef82371b0e162dd169dfe25ae6ab0e04312f3b258bcf1";a:4:{s:10:"expiration";i:1505963243;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36";s:5:"login";i:1505790443;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '62'),
(17, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(18, 1, 'source_domain', 'studiobarre-demo.com'),
(19, 1, 'primary_blog', '1'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'wp_user-settings', 'libraryContent=browse&align=left&editor=tinymce'),
(24, 1, 'wp_user-settings-time', '1505792190') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`, `spam`, `deleted`) VALUES
(1, 'destroyer', '$P$BNUWMvXQG/jMtjjvz0sAw.khv3todR1', 'destroyer', 'garrettcullen@yahoo.com', '', '2017-07-23 22:11:06', '', 0, 'destroyer', 0, 0) ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

