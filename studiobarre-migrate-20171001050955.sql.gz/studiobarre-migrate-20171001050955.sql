# WordPress MySQL database migration
#
# Generated: Sunday 1. October 2017 05:09 UTC
# Hostname: localhost
# Database: `studiobarre`
# URL: //studiobarre-demo.com
# Path: /Applications/MAMP/htdocs/studiobarre-new
# Tables: wp_2_commentmeta, wp_2_comments, wp_2_hc_hmw_short_code, wp_2_links, wp_2_options, wp_2_postmeta, wp_2_posts, wp_2_rg_form, wp_2_rg_form_meta, wp_2_rg_form_view, wp_2_rg_incomplete_submissions, wp_2_rg_lead, wp_2_rg_lead_detail, wp_2_rg_lead_detail_long, wp_2_rg_lead_meta, wp_2_rg_lead_notes, wp_2_simple_history, wp_2_simple_history_contexts, wp_2_term_relationships, wp_2_term_taxonomy, wp_2_termmeta, wp_2_terms, wp_2_yoast_seo_links, wp_2_yoast_seo_meta, wp_3_commentmeta, wp_3_comments, wp_3_links, wp_3_options, wp_3_postmeta, wp_3_posts, wp_3_rg_form, wp_3_rg_form_meta, wp_3_rg_form_view, wp_3_rg_incomplete_submissions, wp_3_rg_lead, wp_3_rg_lead_detail, wp_3_rg_lead_detail_long, wp_3_rg_lead_meta, wp_3_rg_lead_notes, wp_3_simple_history, wp_3_simple_history_contexts, wp_3_term_relationships, wp_3_term_taxonomy, wp_3_termmeta, wp_3_terms, wp_3_yoast_seo_links, wp_3_yoast_seo_meta, wp_blog_versions, wp_blogs, wp_commentmeta, wp_comments, wp_hc_hmw_short_code, wp_itsec_lockouts, wp_itsec_log, wp_itsec_temp, wp_links, wp_options, wp_postmeta, wp_posts, wp_registration_log, wp_rg_form, wp_rg_form_meta, wp_rg_form_view, wp_rg_incomplete_submissions, wp_rg_lead, wp_rg_lead_detail, wp_rg_lead_detail_long, wp_rg_lead_meta, wp_rg_lead_notes, wp_signups, wp_simple_history, wp_simple_history_contexts, wp_site, wp_sitemeta, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_yoast_seo_links, wp_yoast_seo_meta
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post, events
# Protocol: http
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_2_commentmeta`
#

DROP TABLE IF EXISTS `wp_2_commentmeta`;


#
# Table structure of table `wp_2_commentmeta`
#

CREATE TABLE `wp_2_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_commentmeta`
#

#
# End of data contents of table `wp_2_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_comments`
#

DROP TABLE IF EXISTS `wp_2_comments`;


#
# Table structure of table `wp_2_comments`
#

CREATE TABLE `wp_2_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_comments`
#
INSERT INTO `wp_2_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'http://studiobarre-demo.com/', '', '2017-09-20 03:33:55', '2017-09-20 03:33:55', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_2_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_hc_hmw_short_code`
#

DROP TABLE IF EXISTS `wp_2_hc_hmw_short_code`;


#
# Table structure of table `wp_2_hc_hmw_short_code`
#

CREATE TABLE `wp_2_hc_hmw_short_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `short_code` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_2_hc_hmw_short_code`
#

#
# End of data contents of table `wp_2_hc_hmw_short_code`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_links`
#

DROP TABLE IF EXISTS `wp_2_links`;


#
# Table structure of table `wp_2_links`
#

CREATE TABLE `wp_2_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_links`
#

#
# End of data contents of table `wp_2_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_options`
#

DROP TABLE IF EXISTS `wp_2_options`;


#
# Table structure of table `wp_2_options`
#

CREATE TABLE `wp_2_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_options`
#
INSERT INTO `wp_2_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://studiobarre-demo.com/carmel-valley', 'yes'),
(2, 'home', 'http://studiobarre-demo.com/carmel-valley', 'yes'),
(3, 'blogname', 'Studio Barre - Carmel Valley, Ca', 'yes'),
(4, 'blogdescription', 'Just another Studio Barre Sites site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrettcullen@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'studiobarrezee', 'yes'),
(41, 'stylesheet', 'studiobarrezee', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:47:"healcode-mindbody-widget/healcode-mb-widget.php";s:24:"hc_hmw_network_uninstall";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '5', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_2_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(92, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(98, 'WPLANG', '', 'yes'),
(99, 'acf_version', '5.6.2', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_2_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(110, 'cron', 'a:5:{i:1506807586;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506828839;a:2:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506836730;a:1:{s:29:"simple_history/maybe_purge_db";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506836944;a:1:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(111, 'gform_enable_background_updates', '1', 'yes'),
(112, 'gf_db_version', '2.2.5', 'yes'),
(113, 'gform_pending_installation', '', 'yes'),
(114, 'rg_form_version', '2.2.5', 'yes'),
(141, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1506288126;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(142, 'current_theme', '', 'yes'),
(143, 'theme_mods_studiobarrezee', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:4:{s:9:"main_menu";i:3;s:10:"local_menu";i:3;s:18:"local_menu_classes";i:3;s:21:"local_menu_our_studio";i:4;}}', 'yes'),
(144, 'theme_switched', '', 'yes'),
(145, 'post_count', '1', 'yes'),
(147, 'fresh_site', '0', 'yes'),
(153, 'rg_gforms_key', '06531379cf8e19681c4045b7a998bf23', 'yes'),
(154, 'rg_gforms_enable_akismet', '0', 'yes'),
(155, 'rg_gforms_currency', 'USD', 'yes'),
(156, 'gform_enable_toolbar_menu', '1', 'yes'),
(157, 'rg_gforms_disable_css', '1', 'yes'),
(158, 'rg_gforms_captcha_public_key', '', 'yes'),
(159, 'rg_gforms_captcha_private_key', '', 'yes'),
(160, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(161, 'gform_email_count', '1', 'yes'),
(163, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(168, 'recently_activated', 'a:0:{}', 'yes'),
(169, 'dd9b23a13775ccc12b5389d301f8ef5d', 'a:2:{s:7:"timeout";i:1506315743;s:5:"value";s:6302:"{"new_version":"2.1.0","stable_version":"2.1.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2017-09-01 06:12:45","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"","download_link":"","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.8 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.1.0\\u00a0released in July 2017<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(172, 'options_global_nav', 'a:1:{i:0;s:1:"1";}', 'no'),
(173, '_options_global_nav', 'field_59c8688104392', 'no'),
(175, 'hc_hmw_limit', '20', 'yes'),
(176, 'wpseo', 'a:25:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:1;s:7:"version";s:5:"5.4.2";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1506318050;}', 'yes'),
(177, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(178, 'wpseo_titles', 'a:53:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(179, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"882d8b694ed1101d2a301c3719e87cd2";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(180, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(181, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(182, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(183, 'mucd_duplicable', 'no', 'yes'),
(184, 'simple_history_db_version', '5', 'yes'),
(185, 'simple_history_show_as_page', '1', 'yes'),
(186, 'simple_history_show_on_dashboard', '1', 'yes'),
(187, 'simple_history_enable_rss_feed', '0', 'yes'),
(188, 'simple_history_rss_secret', 'jdkhpdgrevoasawprkgg', 'yes'),
(189, 'widget_hc_insert_html_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(190, 'widget_mla-text-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(192, 'gf_is_upgrading', '0', 'yes'),
(193, 'gf_previous_db_version', '2.2.4.1', 'yes'),
(194, 'rewrite_rules', 'a:117:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"events/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"events/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"events/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"events/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"events/([^/]+)/embed/?$";s:39:"index.php?events=$matches[1]&embed=true";s:27:"events/([^/]+)/trackback/?$";s:33:"index.php?events=$matches[1]&tb=1";s:35:"events/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?events=$matches[1]&paged=$matches[2]";s:42:"events/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?events=$matches[1]&cpage=$matches[2]";s:31:"events/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?events=$matches[1]&page=$matches[2]";s:23:"events/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"events/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"events/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"events/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:60:"attachment_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:55:"attachment_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:36:"attachment_category/([^/]+)/embed/?$";s:52:"index.php?attachment_category=$matches[1]&embed=true";s:48:"attachment_category/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?attachment_category=$matches[1]&paged=$matches[2]";s:30:"attachment_category/([^/]+)/?$";s:41:"index.php?attachment_category=$matches[1]";s:55:"attachment_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:50:"attachment_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:31:"attachment_tag/([^/]+)/embed/?$";s:47:"index.php?attachment_tag=$matches[1]&embed=true";s:43:"attachment_tag/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?attachment_tag=$matches[1]&paged=$matches[2]";s:25:"attachment_tag/([^/]+)/?$";s:36:"index.php?attachment_tag=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(196, 'mla_custom_field_mapping', 'a:0:{}', 'yes'),
(197, 'mla_iptc_exif_mapping', 'a:3:{s:8:"standard";a:5:{s:10:"post_title";a:5:{s:4:"name";s:5:"Title";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"post_name";a:5:{s:4:"name";s:9:"Name/Slug";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"image_alt";a:5:{s:4:"name";s:8:"ALT Text";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_excerpt";a:5:{s:4:"name";s:7:"Caption";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_content";a:5:{s:4:"name";s:11:"Description";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}}s:8:"taxonomy";a:0:{}s:6:"custom";a:0:{}}', 'yes'),
(198, 'mla_upload_mimes', 'a:4:{s:6:"custom";a:0:{}s:8:"disabled";a:53:{s:3:"aac";b:1;s:3:"ac3";b:1;s:2:"ai";b:1;s:3:"aif";b:1;s:4:"aifc";b:1;s:4:"aiff";b:1;s:2:"au";b:1;s:3:"bin";b:1;s:3:"cat";b:1;s:3:"cdf";b:1;s:3:"cgm";b:1;s:3:"clp";b:1;s:3:"crd";b:1;s:3:"dat";b:1;s:3:"dll";b:1;s:3:"dot";b:1;s:3:"dtd";b:1;s:3:"eps";b:1;s:4:"gtar";b:1;s:3:"ief";b:1;s:3:"ifb";b:1;s:3:"m13";b:1;s:3:"m14";b:1;s:3:"mml";b:1;s:3:"mny";b:1;s:5:"movie";b:1;s:3:"mp2";b:1;s:3:"mpa";b:1;s:3:"msg";b:1;s:3:"mvb";b:1;s:3:"otf";b:1;s:3:"pic";b:1;s:4:"pict";b:1;s:2:"ps";b:1;s:3:"pub";b:1;s:3:"rgb";b:1;s:3:"scd";b:1;s:3:"snd";b:1;s:3:"sql";b:1;s:3:"sst";b:1;s:3:"stl";b:1;s:3:"svg";b:1;s:3:"trm";b:1;s:3:"ttf";b:1;s:3:"w6w";b:1;s:3:"wmf";b:1;s:4:"woff";b:1;s:4:"word";b:1;s:3:"xlc";b:1;s:3:"xlm";b:1;s:3:"xml";b:1;s:3:"xsl";b:1;s:4:"xslt";b:1;}s:11:"description";a:0:{}s:9:"icon_type";a:82:{s:2:"ai";s:10:"postscript";s:4:"aifc";s:5:"audio";s:3:"asx";s:5:"video";s:2:"au";s:5:"audio";s:3:"bin";s:6:"binary";s:1:"c";s:8:"source_c";s:2:"cc";s:10:"source_cpp";s:3:"cgm";s:5:"image";s:5:"class";s:11:"source_java";s:3:"clp";s:6:"knotes";s:3:"crd";s:6:"knotes";s:3:"css";s:10:"stylesheet";s:3:"dat";s:6:"binary";s:3:"dll";s:8:"exe_wine";s:3:"dot";s:8:"document";s:4:"dotx";s:8:"document";s:3:"dtd";s:4:"code";s:3:"eps";s:10:"postscript";s:3:"exe";s:8:"exe_wine";s:4:"gtar";s:7:"archive";s:4:"gzip";s:7:"archive";s:1:"h";s:8:"source_h";s:3:"ics";s:8:"calendar";s:3:"ief";s:5:"image";s:3:"ifb";s:8:"calendar";s:2:"js";s:11:"source_java";s:3:"mdb";s:8:"database";s:3:"mid";s:5:"audio";s:4:"midi";s:5:"audio";s:3:"mml";s:8:"kformula";s:5:"movie";s:5:"video";s:3:"mpa";s:5:"audio";s:3:"mpe";s:5:"video";s:3:"msg";s:7:"message";s:3:"odb";s:8:"database";s:3:"odc";s:3:"log";s:3:"odf";s:8:"kformula";s:3:"odg";s:2:"3d";s:6:"onepkg";s:6:"knotes";s:6:"onetmp";s:6:"knotes";s:6:"onetoc";s:6:"knotes";s:7:"onetoc2";s:6:"knotes";s:3:"otf";s:4:"font";s:3:"pdf";s:3:"pdf";s:3:"pic";s:5:"image";s:4:"pict";s:5:"image";s:3:"pot";s:11:"interactive";s:4:"potm";s:11:"interactive";s:4:"potx";s:11:"interactive";s:4:"ppam";s:11:"interactive";s:2:"ps";s:10:"postscript";s:3:"psd";s:5:"image";s:3:"pub";s:8:"document";s:2:"qt";s:9:"quicktime";s:2:"ra";s:5:"audio";s:3:"rgb";s:5:"image";s:3:"rtx";s:4:"text";s:3:"snd";s:5:"audio";s:3:"sql";s:8:"database";s:3:"svg";s:9:"vectorgfx";s:3:"trm";s:11:"interactive";s:3:"ttf";s:13:"font_truetype";s:3:"w6w";s:8:"document";s:3:"wax";s:5:"audio";s:4:"webm";s:5:"video";s:2:"wm";s:5:"video";s:3:"wmf";s:9:"vectorgfx";s:3:"wmx";s:5:"video";s:4:"woff";s:4:"font";s:4:"word";s:8:"document";s:3:"wri";s:8:"document";s:3:"xla";s:11:"spreadsheet";s:4:"xlam";s:11:"spreadsheet";s:3:"xlc";s:11:"spreadsheet";s:3:"xlm";s:11:"spreadsheet";s:3:"xlt";s:11:"spreadsheet";s:4:"xltm";s:11:"spreadsheet";s:4:"xltx";s:11:"spreadsheet";s:3:"xlw";s:11:"spreadsheet";s:3:"xml";s:4:"code";s:3:"xsl";s:5:"style";s:4:"xslt";s:4:"code";}}', 'yes'),
(199, 'mla_current_version', '2.60', 'yes'),
(214, 'mla_post_mime_types', 'a:0:{}', 'yes'),
(215, 'wpseo_sitemap_1_cache_validator', '9oKQ', 'no'),
(216, 'wpseo_sitemap_events_cache_validator', '9oKS', 'no'),
(221, 'wpseo_sitemap_post_cache_validator', '2xI8G', 'no'),
(223, 'wpseo_sitemap_page_cache_validator', '2zfG9', 'no') ;

#
# End of data contents of table `wp_2_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_postmeta`
#

DROP TABLE IF EXISTS `wp_2_postmeta`;


#
# Table structure of table `wp_2_postmeta`
#

CREATE TABLE `wp_2_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_postmeta`
#
INSERT INTO `wp_2_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 2, '_wp_trash_meta_status', 'publish'),
(3, 2, '_wp_trash_meta_time', '1506289181'),
(4, 2, '_wp_desired_post_slug', 'sample-page'),
(5, 5, '_edit_lock', '1506289079:1'),
(6, 5, '_edit_last', '1'),
(7, 5, '_wp_page_template', 'page-home.php'),
(8, 7, '_menu_item_type', 'post_type'),
(9, 7, '_menu_item_menu_item_parent', '0'),
(10, 7, '_menu_item_object_id', '5'),
(11, 7, '_menu_item_object', 'page'),
(12, 7, '_menu_item_target', ''),
(13, 7, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(14, 7, '_menu_item_xfn', ''),
(15, 7, '_menu_item_url', ''),
(16, 7, '_menu_item_orphaned', '1506292156'),
(17, 8, '_menu_item_type', 'post_type'),
(18, 8, '_menu_item_menu_item_parent', '0'),
(19, 8, '_menu_item_object_id', '5'),
(20, 8, '_menu_item_object', 'page'),
(21, 8, '_menu_item_target', ''),
(22, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(23, 8, '_menu_item_xfn', ''),
(24, 8, '_menu_item_url', ''),
(25, 8, '_menu_item_orphaned', '1506292156'),
(26, 9, '_edit_last', '1'),
(27, 9, '_wp_page_template', 'default'),
(28, 9, '_edit_lock', '1506295126:1'),
(76, 18, '_menu_item_type', 'post_type'),
(77, 18, '_menu_item_menu_item_parent', '0'),
(78, 18, '_menu_item_object_id', '5'),
(79, 18, '_menu_item_object', 'page'),
(80, 18, '_menu_item_target', ''),
(81, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 18, '_menu_item_xfn', ''),
(83, 18, '_menu_item_url', ''),
(84, 18, '_menu_item_orphaned', '1506310334'),
(85, 19, '_menu_item_type', 'post_type'),
(86, 19, '_menu_item_menu_item_parent', '0'),
(87, 19, '_menu_item_object_id', '9'),
(88, 19, '_menu_item_object', 'page'),
(89, 19, '_menu_item_target', ''),
(90, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(91, 19, '_menu_item_xfn', ''),
(92, 19, '_menu_item_url', ''),
(93, 19, '_menu_item_orphaned', '1506310334'),
(94, 20, '_menu_item_type', 'post_type'),
(95, 20, '_menu_item_menu_item_parent', '0'),
(96, 20, '_menu_item_object_id', '5'),
(97, 20, '_menu_item_object', 'page'),
(98, 20, '_menu_item_target', ''),
(99, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(100, 20, '_menu_item_xfn', ''),
(101, 20, '_menu_item_url', ''),
(102, 20, '_menu_item_orphaned', '1506310334'),
(130, 24, '_edit_last', '1'),
(131, 24, '_wp_page_template', 'page-about.php'),
(132, 24, '_edit_lock', '1506311410:1'),
(133, 26, '_edit_last', '1'),
(134, 26, '_wp_page_template', 'page-contact.php'),
(135, 26, '_edit_lock', '1506314751:1'),
(136, 28, '_edit_lock', '1506314469:1'),
(137, 28, '_edit_last', '1'),
(138, 28, '_wp_page_template', 'page-schedule.php'),
(139, 30, '_edit_last', '1'),
(140, 30, '_wp_page_template', 'page-pricing.php'),
(141, 30, '_edit_lock', '1506488575:1'),
(142, 32, '_edit_last', '1'),
(143, 32, '_wp_page_template', 'page-promos.php'),
(144, 32, '_edit_lock', '1506317038:1'),
(145, 35, '_edit_last', '1'),
(146, 35, '_wp_page_template', 'page-barretenders.php'),
(147, 35, '_edit_lock', '1506315178:1'),
(148, 37, '_edit_last', '1'),
(149, 37, '_wp_page_template', 'page-events.php'),
(150, 37, '_edit_lock', '1506402855:1'),
(151, 39, '_menu_item_type', 'post_type'),
(152, 39, '_menu_item_menu_item_parent', '0'),
(153, 39, '_menu_item_object_id', '30'),
(154, 39, '_menu_item_object', 'page'),
(155, 39, '_menu_item_target', ''),
(156, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(157, 39, '_menu_item_xfn', ''),
(158, 39, '_menu_item_url', ''),
(160, 40, '_menu_item_type', 'post_type'),
(161, 40, '_menu_item_menu_item_parent', '0'),
(162, 40, '_menu_item_object_id', '32'),
(163, 40, '_menu_item_object', 'page'),
(164, 40, '_menu_item_target', ''),
(165, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(166, 40, '_menu_item_xfn', ''),
(167, 40, '_menu_item_url', ''),
(169, 41, '_menu_item_type', 'post_type'),
(170, 41, '_menu_item_menu_item_parent', '0'),
(171, 41, '_menu_item_object_id', '28'),
(172, 41, '_menu_item_object', 'page'),
(173, 41, '_menu_item_target', ''),
(174, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(175, 41, '_menu_item_xfn', ''),
(176, 41, '_menu_item_url', '') ;
INSERT INTO `wp_2_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(178, 42, '_menu_item_type', 'post_type'),
(179, 42, '_menu_item_menu_item_parent', '0'),
(180, 42, '_menu_item_object_id', '37'),
(181, 42, '_menu_item_object', 'page'),
(182, 42, '_menu_item_target', ''),
(183, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(184, 42, '_menu_item_xfn', ''),
(185, 42, '_menu_item_url', ''),
(187, 43, '_menu_item_type', 'post_type'),
(188, 43, '_menu_item_menu_item_parent', '0'),
(189, 43, '_menu_item_object_id', '35'),
(190, 43, '_menu_item_object', 'page'),
(191, 43, '_menu_item_target', ''),
(192, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(193, 43, '_menu_item_xfn', ''),
(194, 43, '_menu_item_url', ''),
(196, 44, '_menu_item_type', 'post_type'),
(197, 44, '_menu_item_menu_item_parent', '0'),
(198, 44, '_menu_item_object_id', '26'),
(199, 44, '_menu_item_object', 'page'),
(200, 44, '_menu_item_target', ''),
(201, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(202, 44, '_menu_item_xfn', ''),
(203, 44, '_menu_item_url', ''),
(205, 45, '_menu_item_type', 'post_type'),
(206, 45, '_menu_item_menu_item_parent', '0'),
(207, 45, '_menu_item_object_id', '24'),
(208, 45, '_menu_item_object', 'page'),
(209, 45, '_menu_item_target', ''),
(210, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(211, 45, '_menu_item_xfn', ''),
(212, 45, '_menu_item_url', ''),
(214, 48, '_edit_lock', '1506319884:1'),
(215, 48, '_edit_last', '1'),
(216, 48, '_yoast_wpseo_content_score', '30'),
(217, 49, '_wp_attached_file', '2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM.png'),
(218, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1508;s:6:"height";i:1306;s:4:"file";s:48:"2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"Screen-Shot-2017-09-20-at-7.58.57-PM-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:48:"Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png";s:5:"width";i:300;s:6:"height";i:260;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:48:"Screen-Shot-2017-09-20-at-7.58.57-PM-768x665.png";s:5:"width";i:768;s:6:"height";i:665;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:49:"Screen-Shot-2017-09-20-at-7.58.57-PM-1024x887.png";s:5:"width";i:1024;s:6:"height";i:887;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(225, 51, '_edit_lock', '1506320856:1'),
(226, 51, '_edit_last', '1'),
(227, 37, '_yoast_wpseo_content_score', '30'),
(228, 53, '_edit_last', '1'),
(229, 53, '_yoast_wpseo_content_score', '30'),
(230, 53, '_edit_lock', '1506319897:1'),
(231, 54, '_edit_last', '1'),
(232, 54, '_yoast_wpseo_content_score', '30'),
(233, 54, '_edit_lock', '1506402901:1') ;

#
# End of data contents of table `wp_2_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_posts`
#

DROP TABLE IF EXISTS `wp_2_posts`;


#
# Table structure of table `wp_2_posts`
#

CREATE TABLE `wp_2_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_posts`
#
INSERT INTO `wp_2_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-09-20 03:33:55', '2017-09-20 03:33:55', 'Welcome to <a href="http://studiobarre-demo.com/">Studio Barre Sites</a>. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2017-09-20 03:33:55', '2017-09-20 03:33:55', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=1', 0, 'post', '', 1),
(2, 1, '2017-09-20 03:33:55', '2017-09-20 03:33:55', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://studiobarre-demo.com/carmel-valley/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2017-09-24 21:39:41', '2017-09-24 21:39:41', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=2', 0, 'page', '', 0),
(4, 1, '2017-09-24 21:39:41', '2017-09-24 21:39:41', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://studiobarre-demo.com/carmel-valley/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-09-24 21:39:41', '2017-09-24 21:39:41', '', 2, 'http://studiobarre-demo.com/carmel-valley/2017/09/24/2-revision-v1/', 0, 'revision', '', 0),
(5, 1, '2017-09-24 21:40:10', '2017-09-24 21:40:10', '', 'Welcome to Studio Barre Carmel Valley, CA', '', 'publish', 'closed', 'closed', '', 'welcome', '', '', '2017-09-24 21:40:19', '2017-09-24 21:40:19', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=5', 0, 'page', '', 0),
(6, 1, '2017-09-24 21:40:10', '2017-09-24 21:40:10', '', 'Welcome to Studio Barre Carmel Valley, CA', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-09-24 21:40:10', '2017-09-24 21:40:10', '', 5, 'http://studiobarre-demo.com/carmel-valley/2017/09/24/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2017-09-24 22:29:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-09-24 22:29:16', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=7', 1, 'nav_menu_item', '', 0),
(8, 1, '2017-09-24 22:29:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-09-24 22:29:16', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=8', 1, 'nav_menu_item', '', 0),
(9, 1, '2017-09-24 23:21:06', '2017-09-24 23:21:06', '', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2017-09-24 23:21:06', '2017-09-24 23:21:06', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=9', 0, 'page', '', 0),
(10, 1, '2017-09-24 23:21:06', '2017-09-24 23:21:06', '', 'Thank You', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-09-24 23:21:06', '2017-09-24 23:21:06', '', 9, 'http://studiobarre-demo.com/carmel-valley/2017/09/24/9-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2017-09-25 03:32:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-09-25 03:32:14', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=18', 1, 'nav_menu_item', '', 0),
(19, 1, '2017-09-25 03:32:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-09-25 03:32:14', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=19', 1, 'nav_menu_item', '', 0),
(20, 1, '2017-09-25 03:32:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-09-25 03:32:14', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=20', 1, 'nav_menu_item', '', 0),
(24, 1, '2017-09-25 03:42:39', '2017-09-25 03:42:39', '', 'about this barre', '', 'publish', 'closed', 'closed', '', 'about-this-barre', '', '', '2017-09-25 03:52:08', '2017-09-25 03:52:08', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=24', 0, 'page', '', 0),
(25, 1, '2017-09-25 03:42:39', '2017-09-25 03:42:39', '', 'about this barre', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2017-09-25 03:42:39', '2017-09-25 03:42:39', '', 24, 'http://studiobarre-demo.com/carmel-valley/24-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2017-09-25 03:42:51', '2017-09-25 03:42:51', '', 'Contact   Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2017-09-25 04:48:13', '2017-09-25 04:48:13', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=26', 0, 'page', '', 0),
(27, 1, '2017-09-25 03:42:51', '2017-09-25 03:42:51', '', 'contact us', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2017-09-25 03:42:51', '2017-09-25 03:42:51', '', 26, 'http://studiobarre-demo.com/carmel-valley/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2017-09-25 03:43:06', '2017-09-25 03:43:06', '', 'schedule', '', 'publish', 'closed', 'closed', '', 'schedule', '', '', '2017-09-25 04:42:29', '2017-09-25 04:42:29', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=28', 0, 'page', '', 0),
(29, 1, '2017-09-25 03:43:06', '2017-09-25 03:43:06', '', 'schedule', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2017-09-25 03:43:06', '2017-09-25 03:43:06', '', 28, 'http://studiobarre-demo.com/carmel-valley/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2017-09-25 03:43:22', '2017-09-25 03:43:22', '', 'Pricing', '', 'publish', 'closed', 'closed', '', 'pricing', '', '', '2017-09-25 04:44:38', '2017-09-25 04:44:38', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=30', 0, 'page', '', 0),
(31, 1, '2017-09-25 03:43:22', '2017-09-25 03:43:22', '', 'Pricing', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2017-09-25 03:43:22', '2017-09-25 03:43:22', '', 30, 'http://studiobarre-demo.com/carmel-valley/30-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2017-09-25 03:43:39', '2017-09-25 03:43:39', '', 'Promos', '', 'publish', 'closed', 'closed', '', 'promotions', '', '', '2017-09-25 05:26:19', '2017-09-25 05:26:19', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=32', 0, 'page', '', 0),
(33, 1, '2017-09-25 03:43:39', '2017-09-25 03:43:39', '', 'Promotions', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2017-09-25 03:43:39', '2017-09-25 03:43:39', '', 32, 'http://studiobarre-demo.com/carmel-valley/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2017-09-25 03:43:51', '2017-09-25 03:43:51', '', 'Promos', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2017-09-25 03:43:51', '2017-09-25 03:43:51', '', 32, 'http://studiobarre-demo.com/carmel-valley/32-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2017-09-25 03:44:08', '2017-09-25 03:44:08', '', 'Barre {Tenders}', '', 'publish', 'closed', 'closed', '', 'barre-tenders', '', '', '2017-09-25 04:55:19', '2017-09-25 04:55:19', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=35', 0, 'page', '', 0),
(36, 1, '2017-09-25 03:44:08', '2017-09-25 03:44:08', '', 'barre {tenders}', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2017-09-25 03:44:08', '2017-09-25 03:44:08', '', 35, 'http://studiobarre-demo.com/carmel-valley/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2017-09-25 03:44:24', '2017-09-25 03:44:24', '', 'Events', '', 'publish', 'closed', 'closed', '', 'events', '', '', '2017-09-25 06:00:17', '2017-09-25 06:00:17', '', 0, 'http://studiobarre-demo.com/carmel-valley/?page_id=37', 0, 'page', '', 0),
(38, 1, '2017-09-25 03:44:24', '2017-09-25 03:44:24', '', 'Events', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2017-09-25 03:44:24', '2017-09-25 03:44:24', '', 37, 'http://studiobarre-demo.com/carmel-valley/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2017-09-25 03:45:23', '2017-09-25 03:45:23', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2017-09-25 03:45:23', '2017-09-25 03:45:23', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=39', 2, 'nav_menu_item', '', 0),
(40, 1, '2017-09-25 03:45:23', '2017-09-25 03:45:23', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2017-09-25 03:45:23', '2017-09-25 03:45:23', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=40', 3, 'nav_menu_item', '', 0),
(41, 1, '2017-09-25 03:45:23', '2017-09-25 03:45:23', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2017-09-25 03:45:23', '2017-09-25 03:45:23', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2017-09-25 03:45:53', '2017-09-25 03:45:53', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2017-09-25 03:45:53', '2017-09-25 03:45:53', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=42', 3, 'nav_menu_item', '', 0),
(43, 1, '2017-09-25 03:45:53', '2017-09-25 03:45:53', ' ', '', '', 'publish', 'closed', 'closed', '', '43', '', '', '2017-09-25 03:45:53', '2017-09-25 03:45:53', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=43', 4, 'nav_menu_item', '', 0),
(44, 1, '2017-09-25 03:45:53', '2017-09-25 03:45:53', ' ', '', '', 'publish', 'closed', 'closed', '', '44', '', '', '2017-09-25 03:45:53', '2017-09-25 03:45:53', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=44', 2, 'nav_menu_item', '', 0),
(45, 1, '2017-09-25 03:45:53', '2017-09-25 03:45:53', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2017-09-25 03:45:53', '2017-09-25 03:45:53', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=45', 1, 'nav_menu_item', '', 0),
(46, 1, '2017-09-25 04:47:56', '2017-09-25 04:47:56', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2017-09-25 04:47:56', '2017-09-25 04:47:56', '', 26, 'http://studiobarre-demo.com/carmel-valley/26-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2017-09-25 04:50:08', '2017-09-25 04:50:08', '', 'Barre {Tenders}', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2017-09-25 04:50:08', '2017-09-25 04:50:08', '', 35, 'http://studiobarre-demo.com/carmel-valley/35-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2017-09-25 05:51:03', '2017-09-25 05:51:03', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test', '', 'publish', 'open', 'closed', '', 'test', '', '', '2017-09-25 05:52:22', '2017-09-25 05:52:22', '', 0, 'http://studiobarre-demo.com/carmel-valley/?post_type=events&#038;p=48', 0, 'events', '', 0),
(49, 1, '2017-09-25 05:52:00', '2017-09-25 05:52:00', '', 'Screen Shot 2017-09-20 at 7.58.57 PM', '', 'inherit', 'open', 'closed', '', 'screen-shot-2017-09-20-at-7-58-57-pm', '', '', '2017-09-25 05:52:00', '2017-09-25 05:52:00', '', 48, 'http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2017-09-25 05:54:29', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-09-25 05:54:29', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/carmel-valley/?p=50', 0, 'post', '', 0),
(51, 1, '2017-09-25 05:59:58', '2017-09-25 05:59:58', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Events', 'events', 'publish', 'closed', 'closed', '', 'group_59c89b262c30d', '', '', '2017-09-25 06:01:06', '2017-09-25 06:01:06', '', 0, 'http://studiobarre-demo.com/carmel-valley/?post_type=acf-field-group&#038;p=51', 0, 'acf-field-group', '', 0),
(52, 1, '2017-09-25 05:59:58', '2017-09-25 05:59:58', 'a:8:{s:4:"type";s:7:"message";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"message";s:71:"To create events, click "Events" on the left hand side of the dashboard";s:9:"new_lines";s:7:"wpautop";s:8:"esc_html";i:0;}', 'Events', '', 'publish', 'closed', 'closed', '', 'field_59c89b29d3a91', '', '', '2017-09-25 05:59:58', '2017-09-25 05:59:58', '', 51, 'http://studiobarre-demo.com/carmel-valley/?post_type=acf-field&p=52', 0, 'acf-field', '', 0),
(53, 1, '2017-09-25 06:13:57', '2017-09-25 06:13:57', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test 2', '', 'publish', 'open', 'closed', '', 'test-2', '', '', '2017-09-25 06:13:57', '2017-09-25 06:13:57', '', 0, 'http://studiobarre-demo.com/carmel-valley/?post_type=events&#038;p=53', 0, 'events', '', 0),
(54, 1, '2017-09-25 06:14:10', '2017-09-25 06:14:10', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test 3', '', 'publish', 'open', 'closed', '', 'test-3', '', '', '2017-09-26 05:17:21', '2017-09-26 05:17:21', '', 0, 'http://studiobarre-demo.com/carmel-valley/?post_type=events&#038;p=54', 0, 'events', '', 0) ;

#
# End of data contents of table `wp_2_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_form`
#

DROP TABLE IF EXISTS `wp_2_rg_form`;


#
# Table structure of table `wp_2_rg_form`
#

CREATE TABLE `wp_2_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_form`
#
INSERT INTO `wp_2_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Corporate Newsletter Signup', '2017-09-24 23:08:23', 1, 0) ;

#
# End of data contents of table `wp_2_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_2_rg_form_meta`;


#
# Table structure of table `wp_2_rg_form_meta`
#

CREATE TABLE `wp_2_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_form_meta`
#
INSERT INTO `wp_2_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Corporate Newsletter Signup","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"email","id":1,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""}],"version":"2.2.4.1","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"59757699129c8":{"id":"59757699129c8","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":9,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"597576991242d":{"id":"597576991242d","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_2_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_form_view`
#

DROP TABLE IF EXISTS `wp_2_rg_form_view`;


#
# Table structure of table `wp_2_rg_form_view`
#

CREATE TABLE `wp_2_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_form_view`
#
INSERT INTO `wp_2_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2017-09-24 21:26:37', '::1', 283),
(2, 1, '2017-09-26 02:42:52', '', 6),
(3, 1, '2017-09-27 03:29:35', '', 64),
(4, 1, '2017-09-28 03:33:05', '', 131),
(5, 1, '2017-09-30 18:37:09', '', 9) ;

#
# End of data contents of table `wp_2_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_2_rg_incomplete_submissions`;


#
# Table structure of table `wp_2_rg_incomplete_submissions`
#

CREATE TABLE `wp_2_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_2_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_lead`
#

DROP TABLE IF EXISTS `wp_2_rg_lead`;


#
# Table structure of table `wp_2_rg_lead`
#

CREATE TABLE `wp_2_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_lead`
#
INSERT INTO `wp_2_rg_lead` ( `id`, `form_id`, `post_id`, `date_created`, `is_starred`, `is_read`, `ip`, `source_url`, `user_agent`, `currency`, `payment_status`, `payment_date`, `payment_amount`, `payment_method`, `transaction_id`, `is_fulfilled`, `created_by`, `transaction_type`, `status`) VALUES
(1, 1, NULL, '2017-09-25 01:07:49', 0, 0, '::1', 'http://studiobarre-demo.com/carmel-valley/?ckcachecontrol=1506301057', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active') ;

#
# End of data contents of table `wp_2_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_2_rg_lead_detail`;


#
# Table structure of table `wp_2_rg_lead_detail`
#

CREATE TABLE `wp_2_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_lead_detail`
#
INSERT INTO `wp_2_rg_lead_detail` ( `id`, `lead_id`, `form_id`, `field_number`, `value`) VALUES
(1, 1, 1, '1', 'adf@adsf.com') ;

#
# End of data contents of table `wp_2_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_2_rg_lead_detail_long`;


#
# Table structure of table `wp_2_rg_lead_detail_long`
#

CREATE TABLE `wp_2_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_lead_detail_long`
#

#
# End of data contents of table `wp_2_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_2_rg_lead_meta`;


#
# Table structure of table `wp_2_rg_lead_meta`
#

CREATE TABLE `wp_2_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_lead_meta`
#

#
# End of data contents of table `wp_2_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_2_rg_lead_notes`;


#
# Table structure of table `wp_2_rg_lead_notes`
#

CREATE TABLE `wp_2_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_rg_lead_notes`
#

#
# End of data contents of table `wp_2_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_simple_history`
#

DROP TABLE IF EXISTS `wp_2_simple_history`;


#
# Table structure of table `wp_2_simple_history`
#

CREATE TABLE `wp_2_simple_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `logger` varchar(30) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `occasionsID` varchar(32) DEFAULT NULL,
  `initiator` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `loggerdate` (`logger`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_2_simple_history`
#
INSERT INTO `wp_2_simple_history` ( `id`, `date`, `logger`, `level`, `message`, `occasionsID`, `initiator`) VALUES
(1, '2017-09-25 05:45:30', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '38759f6932185b9042c632241c4236bd', 'other'),
(2, '2017-09-25 05:45:30', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1ad3dc78aa49c0ba94f3962a5078dae4', 'other'),
(3, '2017-09-25 05:45:30', 'SimpleLogger', 'info', 'Because Simple History was just recently installed, this feed does not contain much events yet. But keep the plugin activated and soon you will see detailed information about page edits, plugin updates, user logins, and much more.', '1c6ed1ff4a97400596b011813faa932f', 'wp'),
(4, '2017-09-25 05:45:30', 'SimpleLogger', 'info', 'Welcome to Simple History!\n\nThis is the main history feed. It will contain events that this plugin has logged.', '0c4babaacbe315745cbb536eaa41278c', 'wp'),
(5, '2017-09-25 05:45:31', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '38759f6932185b9042c632241c4236bd', 'wp'),
(6, '2017-09-25 05:45:31', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1ad3dc78aa49c0ba94f3962a5078dae4', 'wp'),
(7, '2017-09-25 05:49:28', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '661f44e56d0154d857c09b7e62fb0c71', 'wp_user'),
(8, '2017-09-25 05:50:52', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '04e03151791f0adfc03936c0107df83e', 'wp_user'),
(9, '2017-09-25 05:51:03', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '04e03151791f0adfc03936c0107df83e', 'wp_user'),
(10, '2017-09-25 05:52:00', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '7e7c2b4ad8e805514aaac3f371d1b50f', 'wp_user'),
(11, '2017-09-25 05:52:22', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '04e03151791f0adfc03936c0107df83e', 'wp_user'),
(12, '2017-09-25 05:58:54', 'SimplePostLogger', 'info', 'Moved {post_type} "{post_title}" to the trash', '6e42dc3a25a0657f199ea261fcde1909', 'wp_user'),
(13, '2017-09-25 05:58:54', 'SimplePostLogger', 'info', 'Moved {post_type} "{post_title}" to the trash', '6e86f8a2c8190871abce4eadad61d162', 'wp_user'),
(14, '2017-09-25 05:58:59', 'SimplePostLogger', 'info', 'Deleted {post_type} "{post_title}"', '2fe4cb402e5eda08ff5966191a0b7cf1', 'wp_user'),
(15, '2017-09-25 05:58:59', 'SimplePostLogger', 'info', 'Deleted {post_type} "{post_title}"', 'f1f27aa01dccf819ed370998cebfd204', 'wp_user'),
(16, '2017-09-25 05:59:58', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'fa4d22298cfcc3f7f31ee7b69b29e718', 'wp_user'),
(17, '2017-09-25 05:59:58', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '7bc139ef360bd61ffb27e77cce54ec40', 'wp_user'),
(18, '2017-09-25 05:59:58', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(19, '2017-09-25 06:00:17', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '7dd31dc8b2c9d4e8c06c1eb3e248d234', 'wp_user'),
(20, '2017-09-25 06:00:23', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(21, '2017-09-25 06:00:23', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(22, '2017-09-25 06:00:36', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(23, '2017-09-25 06:00:36', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(24, '2017-09-25 06:00:54', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(25, '2017-09-25 06:00:54', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(26, '2017-09-25 06:01:06', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(27, '2017-09-25 06:01:06', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0bd7e12b60c91342dbed5df3e5069705', 'wp_user'),
(28, '2017-09-25 06:13:57', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'fe4864652632f630ad58d9d59da490c8', 'wp_user'),
(29, '2017-09-25 06:14:10', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'b82169b3326f4c15ec0dab39bb7ee78f', 'wp_user'),
(30, '2017-09-26 05:16:18', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'dfeaff4e0d731ae0d36247d8134f4645', 'wp_user'),
(31, '2017-09-26 05:16:55', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'dfeaff4e0d731ae0d36247d8134f4645', 'wp_user'),
(32, '2017-09-26 05:17:21', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'dfeaff4e0d731ae0d36247d8134f4645', 'wp_user') ;

#
# End of data contents of table `wp_2_simple_history`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_simple_history_contexts`
#

DROP TABLE IF EXISTS `wp_2_simple_history_contexts`;


#
# Table structure of table `wp_2_simple_history_contexts`
#

CREATE TABLE `wp_2_simple_history_contexts` (
  `context_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `history_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` longtext,
  PRIMARY KEY (`context_id`),
  KEY `history_id` (`history_id`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=321 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_2_simple_history_contexts`
#
INSERT INTO `wp_2_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1, 1, 'plugin_name', 'Simple History'),
(2, 1, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(3, 1, 'plugin_url', 'http://simple-history.com'),
(4, 1, 'plugin_version', '2.18'),
(5, 1, 'plugin_author', 'Pär Thernström'),
(6, 1, '_message_key', 'plugin_installed'),
(7, 1, '_server_remote_addr', '::1'),
(8, 1, '_server_http_referer', 'http://garretts-macbook-pro.local:5757/carmel-valley/schedule/'),
(9, 2, 'plugin_name', 'Simple History'),
(10, 2, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(11, 2, 'plugin_url', 'http://simple-history.com'),
(12, 2, 'plugin_version', '2.18'),
(13, 2, 'plugin_author', 'Pär Thernström'),
(14, 2, 'plugin_slug', 'simple-history'),
(15, 2, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(16, 2, '_message_key', 'plugin_activated'),
(17, 2, '_server_remote_addr', '::1'),
(18, 2, '_server_http_referer', 'http://garretts-macbook-pro.local:5757/carmel-valley/schedule/'),
(19, 3, '_server_remote_addr', '::1'),
(20, 3, '_server_http_referer', 'http://garretts-macbook-pro.local:5757/carmel-valley/schedule/'),
(21, 4, '_server_remote_addr', '::1'),
(22, 4, '_server_http_referer', 'http://garretts-macbook-pro.local:5757/carmel-valley/schedule/'),
(23, 5, 'plugin_name', 'Simple History'),
(24, 5, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(25, 5, 'plugin_url', 'http://simple-history.com'),
(26, 5, 'plugin_version', '2.18'),
(27, 5, 'plugin_author', 'Pär Thernström'),
(28, 5, '_message_key', 'plugin_installed'),
(29, 5, '_wp_cron_running', 'true'),
(30, 5, '_server_remote_addr', '::1'),
(31, 5, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-cron.php?doing_wp_cron=1506318330.8433721065521240234375'),
(32, 6, 'plugin_name', 'Simple History'),
(33, 6, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(34, 6, 'plugin_url', 'http://simple-history.com'),
(35, 6, 'plugin_version', '2.18'),
(36, 6, 'plugin_author', 'Pär Thernström'),
(37, 6, 'plugin_slug', 'simple-history'),
(38, 6, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(39, 6, '_message_key', 'plugin_activated'),
(40, 6, '_wp_cron_running', 'true'),
(41, 6, '_server_remote_addr', '::1'),
(42, 6, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-cron.php?doing_wp_cron=1506318330.8433721065521240234375'),
(43, 7, 'post_id', '48'),
(44, 7, 'post_type', 'events'),
(45, 7, 'post_title', 'Test'),
(46, 7, '_message_key', 'post_created'),
(47, 7, '_user_id', '1'),
(48, 7, '_user_login', 'destroyer'),
(49, 7, '_user_email', 'garrettcullen@yahoo.com'),
(50, 7, '_server_remote_addr', '::1'),
(51, 7, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=events'),
(52, 8, 'post_id', '48'),
(53, 8, 'post_type', 'events'),
(54, 8, 'post_title', 'Test'),
(55, 8, '_message_key', 'post_updated'),
(56, 8, '_user_id', '1'),
(57, 8, '_user_login', 'destroyer'),
(58, 8, '_user_email', 'garrettcullen@yahoo.com'),
(59, 8, '_server_remote_addr', '::1'),
(60, 8, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=events'),
(61, 9, 'post_id', '48'),
(62, 9, 'post_type', 'events'),
(63, 9, 'post_title', 'Test'),
(64, 9, 'post_prev_post_name', ''),
(65, 9, 'post_new_post_name', 'test'),
(66, 9, 'post_prev_post_status', 'draft'),
(67, 9, 'post_new_post_status', 'publish'),
(68, 9, 'post_prev_post_date', '2017-09-25 05:50:52'),
(69, 9, 'post_new_post_date', '2017-09-25 05:51:03'),
(70, 9, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(71, 9, 'post_new_post_date_gmt', '2017-09-25 05:51:03'),
(72, 9, '_message_key', 'post_updated'),
(73, 9, '_user_id', '1'),
(74, 9, '_user_login', 'destroyer'),
(75, 9, '_user_email', 'garrettcullen@yahoo.com'),
(76, 9, '_server_remote_addr', '::1'),
(77, 9, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=events&wp-post-new-reload=true&wp-post-new-reload=true'),
(78, 10, 'post_type', 'attachment'),
(79, 10, 'attachment_id', '49'),
(80, 10, 'attachment_title', 'Screen Shot 2017-09-20 at 7.58.57 PM'),
(81, 10, 'attachment_filename', 'Screen-Shot-2017-09-20-at-7.58.57-PM.png'),
(82, 10, 'attachment_mime', 'image/png'),
(83, 10, 'attachment_filesize', '3231833'),
(84, 10, '_message_key', 'attachment_created'),
(85, 10, '_user_id', '1'),
(86, 10, '_user_login', 'destroyer'),
(87, 10, '_user_email', 'garrettcullen@yahoo.com'),
(88, 10, '_server_remote_addr', '::1'),
(89, 10, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=48&action=edit'),
(90, 11, 'post_id', '48'),
(91, 11, 'post_type', 'events'),
(92, 11, 'post_title', 'Test'),
(93, 11, 'post_prev_post_content', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(94, 11, 'post_new_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(95, 11, '_message_key', 'post_updated'),
(96, 11, '_user_id', '1'),
(97, 11, '_user_login', 'destroyer'),
(98, 11, '_user_email', 'garrettcullen@yahoo.com'),
(99, 11, '_server_remote_addr', '::1'),
(100, 11, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=48&action=edit') ;
INSERT INTO `wp_2_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(101, 12, 'post_id', '16'),
(102, 12, 'post_type', 'acf-field-group'),
(103, 12, 'post_title', 'Global Menu'),
(104, 12, '_message_key', 'post_trashed'),
(105, 12, '_user_id', '1'),
(106, 12, '_user_login', 'destroyer'),
(107, 12, '_user_email', 'garrettcullen@yahoo.com'),
(108, 12, '_server_remote_addr', '::1'),
(109, 12, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/edit.php?post_type=acf-field-group'),
(110, 13, 'post_id', '17'),
(111, 13, 'post_type', 'acf-field'),
(112, 13, 'post_title', 'Global Nav'),
(113, 13, '_message_key', 'post_trashed'),
(114, 13, '_user_id', '1'),
(115, 13, '_user_login', 'destroyer'),
(116, 13, '_user_email', 'garrettcullen@yahoo.com'),
(117, 13, '_server_remote_addr', '::1'),
(118, 13, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/edit.php?post_type=acf-field-group'),
(119, 14, 'post_id', '16'),
(120, 14, 'post_type', 'acf-field-group'),
(121, 14, 'post_title', 'Global Menu'),
(122, 14, '_message_key', 'post_deleted'),
(123, 14, '_user_id', '1'),
(124, 14, '_user_login', 'destroyer'),
(125, 14, '_user_email', 'garrettcullen@yahoo.com'),
(126, 14, '_server_remote_addr', '::1'),
(127, 14, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/edit.php?post_status=trash&post_type=acf-field-group'),
(128, 15, 'post_id', '17'),
(129, 15, 'post_type', 'acf-field'),
(130, 15, 'post_title', 'Global Nav'),
(131, 15, '_message_key', 'post_deleted'),
(132, 15, '_user_id', '1'),
(133, 15, '_user_login', 'destroyer'),
(134, 15, '_user_email', 'garrettcullen@yahoo.com'),
(135, 15, '_server_remote_addr', '::1'),
(136, 15, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/edit.php?post_status=trash&post_type=acf-field-group'),
(137, 16, 'post_id', '51'),
(138, 16, 'post_type', 'acf-field-group'),
(139, 16, 'post_title', 'Events'),
(140, 16, '_message_key', 'post_created'),
(141, 16, '_user_id', '1'),
(142, 16, '_user_login', 'destroyer'),
(143, 16, '_user_email', 'garrettcullen@yahoo.com'),
(144, 16, '_server_remote_addr', '::1'),
(145, 16, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(146, 17, 'post_id', '52'),
(147, 17, 'post_type', 'acf-field'),
(148, 17, 'post_title', 'Events'),
(149, 17, '_message_key', 'post_updated'),
(150, 17, '_user_id', '1'),
(151, 17, '_user_login', 'destroyer'),
(152, 17, '_user_email', 'garrettcullen@yahoo.com'),
(153, 17, '_server_remote_addr', '::1'),
(154, 17, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(155, 18, 'post_id', '51'),
(156, 18, 'post_type', 'acf-field-group'),
(157, 18, 'post_title', 'Events'),
(158, 18, 'post_prev_post_title', 'Auto Draft'),
(159, 18, 'post_new_post_title', 'Events'),
(160, 18, 'post_prev_post_name', ''),
(161, 18, 'post_new_post_name', 'group_59c89b262c30d'),
(162, 18, 'post_prev_post_content', ''),
(163, 18, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:7:"default";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(164, 18, 'post_prev_post_status', 'auto-draft'),
(165, 18, 'post_new_post_status', 'publish'),
(166, 18, 'post_prev_post_date', '2017-09-25 05:59:02'),
(167, 18, 'post_new_post_date', '2017-09-25 05:59:58'),
(168, 18, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(169, 18, 'post_new_post_date_gmt', '2017-09-25 05:59:58'),
(170, 18, 'post_prev_post_excerpt', ''),
(171, 18, 'post_new_post_excerpt', 'events'),
(172, 18, '_message_key', 'post_updated'),
(173, 18, '_user_id', '1'),
(174, 18, '_user_login', 'destroyer'),
(175, 18, '_user_email', 'garrettcullen@yahoo.com'),
(176, 18, '_server_remote_addr', '::1'),
(177, 18, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(178, 19, 'post_id', '37'),
(179, 19, 'post_type', 'page'),
(180, 19, 'post_title', 'Events'),
(181, 19, 'post_prev_page_template', 'default'),
(182, 19, 'post_new_page_template', 'page-events.php'),
(183, 19, 'post_new_page_template_name', 'Events'),
(184, 19, '_message_key', 'post_updated'),
(185, 19, '_user_id', '1'),
(186, 19, '_user_login', 'destroyer'),
(187, 19, '_user_email', 'garrettcullen@yahoo.com'),
(188, 19, '_server_remote_addr', '::1'),
(189, 19, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=37&action=edit'),
(190, 20, 'post_id', '51'),
(191, 20, 'post_type', 'acf-field-group'),
(192, 20, 'post_title', 'Events'),
(193, 20, '_message_key', 'post_updated'),
(194, 20, '_user_id', '1'),
(195, 20, '_user_login', 'destroyer'),
(196, 20, '_user_email', 'garrettcullen@yahoo.com'),
(197, 20, '_server_remote_addr', '::1'),
(198, 20, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(199, 21, 'post_id', '51'),
(200, 21, 'post_type', 'acf-field-group') ;
INSERT INTO `wp_2_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(201, 21, 'post_title', 'Events'),
(202, 21, 'post_prev_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:7:"default";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(203, 21, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(204, 21, '_message_key', 'post_updated'),
(205, 21, '_user_id', '1'),
(206, 21, '_user_login', 'destroyer'),
(207, 21, '_user_email', 'garrettcullen@yahoo.com'),
(208, 21, '_server_remote_addr', '::1'),
(209, 21, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(210, 22, 'post_id', '51'),
(211, 22, 'post_type', 'acf-field-group'),
(212, 22, 'post_title', 'Events'),
(213, 22, '_message_key', 'post_updated'),
(214, 22, '_user_id', '1'),
(215, 22, '_user_login', 'destroyer'),
(216, 22, '_user_email', 'garrettcullen@yahoo.com'),
(217, 22, '_server_remote_addr', '::1'),
(218, 22, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(219, 23, 'post_id', '51'),
(220, 23, 'post_type', 'acf-field-group'),
(221, 23, 'post_title', 'Events'),
(222, 23, 'post_prev_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(223, 23, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:7:"excerpt";i:1;s:13:"custom_fields";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}'),
(224, 23, '_message_key', 'post_updated'),
(225, 23, '_user_id', '1'),
(226, 23, '_user_login', 'destroyer'),
(227, 23, '_user_email', 'garrettcullen@yahoo.com'),
(228, 23, '_server_remote_addr', '::1'),
(229, 23, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(230, 24, 'post_id', '51'),
(231, 24, 'post_type', 'acf-field-group'),
(232, 24, 'post_title', 'Events'),
(233, 24, '_message_key', 'post_updated'),
(234, 24, '_user_id', '1'),
(235, 24, '_user_login', 'destroyer'),
(236, 24, '_user_email', 'garrettcullen@yahoo.com'),
(237, 24, '_server_remote_addr', '::1'),
(238, 24, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(239, 25, 'post_id', '51'),
(240, 25, 'post_type', 'acf-field-group'),
(241, 25, 'post_title', 'Events'),
(242, 25, 'post_prev_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:7:"excerpt";i:1;s:13:"custom_fields";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}'),
(243, 25, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:7:"excerpt";i:1;s:13:"custom_fields";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}'),
(244, 25, '_message_key', 'post_updated'),
(245, 25, '_user_id', '1'),
(246, 25, '_user_login', 'destroyer'),
(247, 25, '_user_email', 'garrettcullen@yahoo.com'),
(248, 25, '_server_remote_addr', '::1'),
(249, 25, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(250, 26, 'post_id', '51'),
(251, 26, 'post_type', 'acf-field-group'),
(252, 26, 'post_title', 'Events'),
(253, 26, '_message_key', 'post_updated'),
(254, 26, '_user_id', '1'),
(255, 26, '_user_login', 'destroyer'),
(256, 26, '_user_email', 'garrettcullen@yahoo.com'),
(257, 26, '_server_remote_addr', '::1'),
(258, 26, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(259, 27, 'post_id', '51'),
(260, 27, 'post_type', 'acf-field-group'),
(261, 27, 'post_title', 'Events'),
(262, 27, 'post_prev_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:7:"excerpt";i:1;s:13:"custom_fields";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}'),
(263, 27, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-events.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}'),
(264, 27, '_message_key', 'post_updated'),
(265, 27, '_user_id', '1'),
(266, 27, '_user_login', 'destroyer'),
(267, 27, '_user_email', 'garrettcullen@yahoo.com'),
(268, 27, '_server_remote_addr', '::1'),
(269, 27, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=51&action=edit'),
(270, 28, 'post_id', '53'),
(271, 28, 'post_type', 'events'),
(272, 28, 'post_title', 'Test 2'),
(273, 28, '_message_key', 'post_created'),
(274, 28, '_user_id', '1'),
(275, 28, '_user_login', 'destroyer'),
(276, 28, '_user_email', 'garrettcullen@yahoo.com'),
(277, 28, '_server_remote_addr', '::1'),
(278, 28, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=events&wp-post-new-reload=true&wp-post-new-reload=true'),
(279, 29, 'post_id', '54'),
(280, 29, 'post_type', 'events'),
(281, 29, 'post_title', 'Test 3'),
(282, 29, '_message_key', 'post_created'),
(283, 29, '_user_id', '1'),
(284, 29, '_user_login', 'destroyer'),
(285, 29, '_user_email', 'garrettcullen@yahoo.com'),
(286, 29, '_server_remote_addr', '::1'),
(287, 29, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post-new.php?post_type=events&wp-post-new-reload=true&wp-post-new-reload=true'),
(288, 30, 'post_id', '54'),
(289, 30, 'post_type', 'events'),
(290, 30, 'post_title', 'Test 3'),
(291, 30, 'post_prev_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(292, 30, 'post_new_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(293, 30, '_message_key', 'post_updated'),
(294, 30, '_user_id', '1'),
(295, 30, '_user_login', 'destroyer'),
(296, 30, '_user_email', 'garrettcullen@yahoo.com'),
(297, 30, '_server_remote_addr', '::1'),
(298, 30, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=54&action=edit'),
(299, 31, 'post_id', '54'),
(300, 31, 'post_type', 'events') ;
INSERT INTO `wp_2_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(301, 31, 'post_title', 'Test 3'),
(302, 31, 'post_prev_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(303, 31, 'post_new_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(304, 31, '_message_key', 'post_updated'),
(305, 31, '_user_id', '1'),
(306, 31, '_user_login', 'destroyer'),
(307, 31, '_user_email', 'garrettcullen@yahoo.com'),
(308, 31, '_server_remote_addr', '::1'),
(309, 31, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=54&action=edit'),
(310, 32, 'post_id', '54'),
(311, 32, 'post_type', 'events'),
(312, 32, 'post_title', 'Test 3'),
(313, 32, 'post_prev_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(314, 32, 'post_new_post_content', '<img class="alignleft size-medium wp-image-49" src="http://studiobarre-demo.com/carmel-valley/wp-content/uploads/sites/2/2017/09/Screen-Shot-2017-09-20-at-7.58.57-PM-300x260.png" alt="" width="300" height="260" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(315, 32, '_message_key', 'post_updated'),
(316, 32, '_user_id', '1'),
(317, 32, '_user_login', 'destroyer'),
(318, 32, '_user_email', 'garrettcullen@yahoo.com'),
(319, 32, '_server_remote_addr', '::1'),
(320, 32, '_server_http_referer', 'http://studiobarre-demo.com/carmel-valley/wp-admin/post.php?post=54&action=edit') ;

#
# End of data contents of table `wp_2_simple_history_contexts`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_term_relationships`
#

DROP TABLE IF EXISTS `wp_2_term_relationships`;


#
# Table structure of table `wp_2_term_relationships`
#

CREATE TABLE `wp_2_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_term_relationships`
#
INSERT INTO `wp_2_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(39, 3, 0),
(40, 3, 0),
(41, 3, 0),
(42, 4, 0),
(43, 4, 0),
(44, 4, 0),
(45, 4, 0) ;

#
# End of data contents of table `wp_2_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_2_term_taxonomy`;


#
# Table structure of table `wp_2_term_taxonomy`
#

CREATE TABLE `wp_2_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_term_taxonomy`
#
INSERT INTO `wp_2_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 3),
(4, 4, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `wp_2_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_termmeta`
#

DROP TABLE IF EXISTS `wp_2_termmeta`;


#
# Table structure of table `wp_2_termmeta`
#

CREATE TABLE `wp_2_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_termmeta`
#

#
# End of data contents of table `wp_2_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_terms`
#

DROP TABLE IF EXISTS `wp_2_terms`;


#
# Table structure of table `wp_2_terms`
#

CREATE TABLE `wp_2_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_terms`
#
INSERT INTO `wp_2_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(3, 'Local Menu Classes', 'local-menu-classes', 0),
(4, 'Local Menu Our Studio', 'local-menu-our-studio', 0) ;

#
# End of data contents of table `wp_2_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_2_yoast_seo_links`;


#
# Table structure of table `wp_2_yoast_seo_links`
#

CREATE TABLE `wp_2_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_yoast_seo_links`
#

#
# End of data contents of table `wp_2_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_2_yoast_seo_meta`
#

DROP TABLE IF EXISTS `wp_2_yoast_seo_meta`;


#
# Table structure of table `wp_2_yoast_seo_meta`
#

CREATE TABLE `wp_2_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_2_yoast_seo_meta`
#
INSERT INTO `wp_2_yoast_seo_meta` ( `object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(37, 0, NULL),
(48, 0, NULL),
(53, 0, NULL),
(54, 0, NULL) ;

#
# End of data contents of table `wp_2_yoast_seo_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_commentmeta`
#

DROP TABLE IF EXISTS `wp_3_commentmeta`;


#
# Table structure of table `wp_3_commentmeta`
#

CREATE TABLE `wp_3_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_commentmeta`
#

#
# End of data contents of table `wp_3_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_comments`
#

DROP TABLE IF EXISTS `wp_3_comments`;


#
# Table structure of table `wp_3_comments`
#

CREATE TABLE `wp_3_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_comments`
#
INSERT INTO `wp_3_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-09-26 03:12:18', '2017-09-26 03:12:18', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_3_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_links`
#

DROP TABLE IF EXISTS `wp_3_links`;


#
# Table structure of table `wp_3_links`
#

CREATE TABLE `wp_3_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_links`
#

#
# End of data contents of table `wp_3_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_options`
#

DROP TABLE IF EXISTS `wp_3_options`;


#
# Table structure of table `wp_3_options`
#

CREATE TABLE `wp_3_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_options`
#
INSERT INTO `wp_3_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://studiobarre-demo.com/franchising', 'yes'),
(2, 'home', 'http://studiobarre-demo.com/franchising', 'yes'),
(3, 'blogname', 'Studio Barre Franchise - Own a Studio', 'yes'),
(4, 'blogdescription', 'Just another Studio Barre Sites site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrettcullen@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'studiobarreownastudio', 'yes'),
(41, 'stylesheet', 'studiobarreownastudio', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:47:"healcode-mindbody-widget/healcode-mb-widget.php";s:24:"hc_hmw_network_uninstall";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '4', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_3_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(92, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(98, 'WPLANG', '', 'yes'),
(99, 'wpseo', 'a:25:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:1;s:7:"version";s:5:"5.4.2";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:0;s:18:"first_activated_on";b:0;}', 'yes'),
(100, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(101, 'wpseo_titles', 'a:63:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;s:29:"title-tax-attachment_category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:32:"metadesc-tax-attachment_category";s:0:"";s:31:"metakey-tax-attachment_category";s:0:"";s:35:"hideeditbox-tax-attachment_category";b:0;s:31:"noindex-tax-attachment_category";b:0;s:24:"title-tax-attachment_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:27:"metadesc-tax-attachment_tag";s:0:"";s:26:"metakey-tax-attachment_tag";s:0:"";s:30:"hideeditbox-tax-attachment_tag";b:0;s:26:"noindex-tax-attachment_tag";b:0;}', 'yes') ;
INSERT INTO `wp_3_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"43329bc305e076fdc641fe9ecc38b66f";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(103, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(104, 'wpseo_internallinks', 'a:13:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;s:29:"post_types-attachment-maintax";i:0;s:37:"taxonomy-attachment_category-ptparent";i:0;s:32:"taxonomy-attachment_tag-ptparent";i:0;}', 'yes'),
(105, 'wpseo_xml', 'a:18:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;s:45:"taxonomies-attachment_category-not_in_sitemap";b:0;s:40:"taxonomies-attachment_tag-not_in_sitemap";b:0;}', 'yes'),
(106, 'acf_version', '5.6.2', 'yes'),
(107, 'cron', 'a:5:{i:1506828026;a:1:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506828027;a:2:{s:29:"simple_history/maybe_purge_db";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506828028;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506828073;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(108, 'simple_history_db_version', '5', 'yes'),
(109, 'simple_history_show_as_page', '1', 'yes'),
(110, 'simple_history_show_on_dashboard', '1', 'yes'),
(111, 'simple_history_enable_rss_feed', '0', 'yes'),
(112, 'simple_history_rss_secret', 'mduafuvylrikuglnjang', 'yes'),
(113, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(121, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'widget_hc_insert_html_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(123, 'widget_mla-text-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(125, 'gform_enable_background_updates', '1', 'yes'),
(126, 'gf_db_version', '2.2.5', 'yes'),
(127, 'gform_pending_installation', '', 'yes'),
(128, 'rg_form_version', '2.2.5', 'yes'),
(129, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(130, 'mla_custom_field_mapping', 'a:0:{}', 'yes'),
(131, 'mla_iptc_exif_mapping', 'a:3:{s:8:"standard";a:5:{s:10:"post_title";a:5:{s:4:"name";s:5:"Title";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"post_name";a:5:{s:4:"name";s:9:"Name/Slug";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"image_alt";a:5:{s:4:"name";s:8:"ALT Text";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_excerpt";a:5:{s:4:"name";s:7:"Caption";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_content";a:5:{s:4:"name";s:11:"Description";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}}s:8:"taxonomy";a:0:{}s:6:"custom";a:0:{}}', 'yes'),
(132, 'mla_upload_mimes', 'a:4:{s:6:"custom";a:0:{}s:8:"disabled";a:53:{s:3:"aac";b:1;s:3:"ac3";b:1;s:2:"ai";b:1;s:3:"aif";b:1;s:4:"aifc";b:1;s:4:"aiff";b:1;s:2:"au";b:1;s:3:"bin";b:1;s:3:"cat";b:1;s:3:"cdf";b:1;s:3:"cgm";b:1;s:3:"clp";b:1;s:3:"crd";b:1;s:3:"dat";b:1;s:3:"dll";b:1;s:3:"dot";b:1;s:3:"dtd";b:1;s:3:"eps";b:1;s:4:"gtar";b:1;s:3:"ief";b:1;s:3:"ifb";b:1;s:3:"m13";b:1;s:3:"m14";b:1;s:3:"mml";b:1;s:3:"mny";b:1;s:5:"movie";b:1;s:3:"mp2";b:1;s:3:"mpa";b:1;s:3:"msg";b:1;s:3:"mvb";b:1;s:3:"otf";b:1;s:3:"pic";b:1;s:4:"pict";b:1;s:2:"ps";b:1;s:3:"pub";b:1;s:3:"rgb";b:1;s:3:"scd";b:1;s:3:"snd";b:1;s:3:"sql";b:1;s:3:"sst";b:1;s:3:"stl";b:1;s:3:"svg";b:1;s:3:"trm";b:1;s:3:"ttf";b:1;s:3:"w6w";b:1;s:3:"wmf";b:1;s:4:"woff";b:1;s:4:"word";b:1;s:3:"xlc";b:1;s:3:"xlm";b:1;s:3:"xml";b:1;s:3:"xsl";b:1;s:4:"xslt";b:1;}s:11:"description";a:0:{}s:9:"icon_type";a:82:{s:2:"ai";s:10:"postscript";s:4:"aifc";s:5:"audio";s:3:"asx";s:5:"video";s:2:"au";s:5:"audio";s:3:"bin";s:6:"binary";s:1:"c";s:8:"source_c";s:2:"cc";s:10:"source_cpp";s:3:"cgm";s:5:"image";s:5:"class";s:11:"source_java";s:3:"clp";s:6:"knotes";s:3:"crd";s:6:"knotes";s:3:"css";s:10:"stylesheet";s:3:"dat";s:6:"binary";s:3:"dll";s:8:"exe_wine";s:3:"dot";s:8:"document";s:4:"dotx";s:8:"document";s:3:"dtd";s:4:"code";s:3:"eps";s:10:"postscript";s:3:"exe";s:8:"exe_wine";s:4:"gtar";s:7:"archive";s:4:"gzip";s:7:"archive";s:1:"h";s:8:"source_h";s:3:"ics";s:8:"calendar";s:3:"ief";s:5:"image";s:3:"ifb";s:8:"calendar";s:2:"js";s:11:"source_java";s:3:"mdb";s:8:"database";s:3:"mid";s:5:"audio";s:4:"midi";s:5:"audio";s:3:"mml";s:8:"kformula";s:5:"movie";s:5:"video";s:3:"mpa";s:5:"audio";s:3:"mpe";s:5:"video";s:3:"msg";s:7:"message";s:3:"odb";s:8:"database";s:3:"odc";s:3:"log";s:3:"odf";s:8:"kformula";s:3:"odg";s:2:"3d";s:6:"onepkg";s:6:"knotes";s:6:"onetmp";s:6:"knotes";s:6:"onetoc";s:6:"knotes";s:7:"onetoc2";s:6:"knotes";s:3:"otf";s:4:"font";s:3:"pdf";s:3:"pdf";s:3:"pic";s:5:"image";s:4:"pict";s:5:"image";s:3:"pot";s:11:"interactive";s:4:"potm";s:11:"interactive";s:4:"potx";s:11:"interactive";s:4:"ppam";s:11:"interactive";s:2:"ps";s:10:"postscript";s:3:"psd";s:5:"image";s:3:"pub";s:8:"document";s:2:"qt";s:9:"quicktime";s:2:"ra";s:5:"audio";s:3:"rgb";s:5:"image";s:3:"rtx";s:4:"text";s:3:"snd";s:5:"audio";s:3:"sql";s:8:"database";s:3:"svg";s:9:"vectorgfx";s:3:"trm";s:11:"interactive";s:3:"ttf";s:13:"font_truetype";s:3:"w6w";s:8:"document";s:3:"wax";s:5:"audio";s:4:"webm";s:5:"video";s:2:"wm";s:5:"video";s:3:"wmf";s:9:"vectorgfx";s:3:"wmx";s:5:"video";s:4:"woff";s:4:"font";s:4:"word";s:8:"document";s:3:"wri";s:8:"document";s:3:"xla";s:11:"spreadsheet";s:4:"xlam";s:11:"spreadsheet";s:3:"xlc";s:11:"spreadsheet";s:3:"xlm";s:11:"spreadsheet";s:3:"xlt";s:11:"spreadsheet";s:4:"xltm";s:11:"spreadsheet";s:4:"xltx";s:11:"spreadsheet";s:3:"xlw";s:11:"spreadsheet";s:3:"xml";s:4:"code";s:3:"xsl";s:5:"style";s:4:"xslt";s:4:"code";}}', 'yes'),
(133, 'mla_current_version', '2.60', 'yes'),
(148, 'wpseo_sitemap_1_cache_validator', 'MBGL', 'no'),
(149, 'wpseo_sitemap_post_cache_validator', 'RZFG', 'no'),
(161, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1506396040;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(162, 'current_theme', '', 'yes'),
(163, 'theme_mods_studiobarreownastudio', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:9:"main_menu";i:2;}}', 'yes'),
(164, 'theme_switched', '', 'yes'),
(165, 'rewrite_rules', 'a:103:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:60:"attachment_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:55:"attachment_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:36:"attachment_category/([^/]+)/embed/?$";s:52:"index.php?attachment_category=$matches[1]&embed=true";s:48:"attachment_category/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?attachment_category=$matches[1]&paged=$matches[2]";s:30:"attachment_category/([^/]+)/?$";s:41:"index.php?attachment_category=$matches[1]";s:55:"attachment_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:50:"attachment_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:31:"attachment_tag/([^/]+)/embed/?$";s:47:"index.php?attachment_tag=$matches[1]&embed=true";s:43:"attachment_tag/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?attachment_tag=$matches[1]&paged=$matches[2]";s:25:"attachment_tag/([^/]+)/?$";s:36:"index.php?attachment_tag=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(166, 'mla_post_mime_types', 'a:0:{}', 'yes'),
(167, 'wpseo_sitemap_page_cache_validator', 'MBGN', 'no'),
(169, 'post_count', '1', 'yes'),
(170, 'fresh_site', '0', 'yes'),
(179, 'rg_gforms_key', '06531379cf8e19681c4045b7a998bf23', 'yes'),
(180, 'rg_gforms_enable_akismet', '0', 'yes'),
(181, 'rg_gforms_currency', 'USD', 'yes'),
(182, 'gform_enable_toolbar_menu', '1', 'yes'),
(185, 'category_children', 'a:0:{}', 'yes'),
(186, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(187, 'rg_gforms_disable_css', '1', 'yes'),
(188, 'rg_gforms_captcha_public_key', '', 'yes'),
(189, 'rg_gforms_captcha_private_key', '', 'yes'),
(190, 'rg_gforms_message', '<!--GFM-->', 'yes') ;

#
# End of data contents of table `wp_3_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_postmeta`
#

DROP TABLE IF EXISTS `wp_3_postmeta`;


#
# Table structure of table `wp_3_postmeta`
#

CREATE TABLE `wp_3_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_postmeta`
#
INSERT INTO `wp_3_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_wp_page_template', 'page-franchising.php'),
(4, 4, '_yoast_wpseo_content_score', '30'),
(5, 4, '_edit_lock', '1506567295:1'),
(6, 6, '_edit_last', '1'),
(7, 6, '_wp_page_template', 'page-franchising.php'),
(8, 6, '_yoast_wpseo_content_score', '30'),
(9, 6, '_edit_lock', '1506569991:1'),
(10, 8, '_edit_lock', '1506567446:1'),
(11, 8, '_edit_last', '1'),
(12, 8, '_wp_page_template', 'page-franchising.php'),
(13, 8, '_yoast_wpseo_content_score', '30'),
(14, 2, '_wp_trash_meta_status', 'publish'),
(15, 2, '_wp_trash_meta_time', '1506396940'),
(16, 2, '_wp_desired_post_slug', 'sample-page'),
(17, 11, '_menu_item_type', 'post_type'),
(18, 11, '_menu_item_menu_item_parent', '0'),
(19, 11, '_menu_item_object_id', '4'),
(20, 11, '_menu_item_object', 'page'),
(21, 11, '_menu_item_target', ''),
(22, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(23, 11, '_menu_item_xfn', ''),
(24, 11, '_menu_item_url', ''),
(26, 12, '_menu_item_type', 'post_type'),
(27, 12, '_menu_item_menu_item_parent', '0'),
(28, 12, '_menu_item_object_id', '4'),
(29, 12, '_menu_item_object', 'page'),
(30, 12, '_menu_item_target', ''),
(31, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(32, 12, '_menu_item_xfn', ''),
(33, 12, '_menu_item_url', ''),
(34, 12, '_menu_item_orphaned', '1506397543'),
(35, 13, '_menu_item_type', 'post_type'),
(36, 13, '_menu_item_menu_item_parent', '0'),
(37, 13, '_menu_item_object_id', '6'),
(38, 13, '_menu_item_object', 'page'),
(39, 13, '_menu_item_target', ''),
(40, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(41, 13, '_menu_item_xfn', ''),
(42, 13, '_menu_item_url', ''),
(44, 14, '_menu_item_type', 'post_type'),
(45, 14, '_menu_item_menu_item_parent', '0'),
(46, 14, '_menu_item_object_id', '8'),
(47, 14, '_menu_item_object', 'page'),
(48, 14, '_menu_item_target', ''),
(49, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(50, 14, '_menu_item_xfn', ''),
(51, 14, '_menu_item_url', ''),
(53, 15, '_menu_item_type', 'custom'),
(54, 15, '_menu_item_menu_item_parent', '0'),
(55, 15, '_menu_item_object_id', '15'),
(56, 15, '_menu_item_object', 'custom'),
(57, 15, '_menu_item_target', ''),
(58, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(59, 15, '_menu_item_xfn', ''),
(60, 15, '_menu_item_url', 'http://studiobarre-demo.com'),
(62, 16, '_menu_item_type', 'custom'),
(63, 16, '_menu_item_menu_item_parent', '0'),
(64, 16, '_menu_item_object_id', '16'),
(65, 16, '_menu_item_object', 'custom'),
(66, 16, '_menu_item_target', ''),
(67, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(68, 16, '_menu_item_xfn', ''),
(69, 16, '_menu_item_url', 'http://studiobarre-demo.com/find-your-studio/'),
(71, 17, '_menu_item_type', 'custom'),
(72, 17, '_menu_item_menu_item_parent', '0'),
(73, 17, '_menu_item_object_id', '17'),
(74, 17, '_menu_item_object', 'custom'),
(75, 17, '_menu_item_target', ''),
(76, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(77, 17, '_menu_item_xfn', ''),
(78, 17, '_menu_item_url', 'http://studiobarre-demo.com/studio-barre-mentors/'),
(80, 18, '_edit_last', '1'),
(81, 18, '_wp_page_template', 'default'),
(82, 18, '_yoast_wpseo_content_score', '30'),
(83, 18, '_edit_lock', '1506399816:1'),
(84, 25, '_wp_attached_file', '2017/09/StudioBarreFranchiseApplication.pdf'),
(85, 25, '_edit_lock', '1506403167:1'),
(86, 27, '_edit_lock', '1506566910:1'),
(87, 27, '_edit_last', '1'),
(88, 4, 'h1_titles_first_word', 'About'),
(89, 4, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(90, 4, 'h1_titles_word_in_brackets', 'Us'),
(91, 4, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(92, 30, 'h1_titles_first_word', 'About'),
(93, 30, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(94, 30, 'h1_titles_word_in_brackets', 'Us'),
(95, 30, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(96, 6, 'h1_titles_first_word', 'About'),
(97, 6, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(98, 6, 'h1_titles_word_in_brackets', 'You'),
(99, 6, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(100, 31, 'h1_titles_first_word', 'About'),
(101, 31, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(102, 31, 'h1_titles_word_in_brackets', 'You'),
(103, 31, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(104, 8, 'h1_titles_first_word', 'Next'),
(105, 8, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(106, 8, 'h1_titles_word_in_brackets', 'Steps') ;
INSERT INTO `wp_3_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(107, 8, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(108, 32, 'h1_titles_first_word', 'Next'),
(109, 32, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(110, 32, 'h1_titles_word_in_brackets', 'Steps'),
(111, 32, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(112, 33, '_edit_lock', '1506573277:1'),
(113, 33, '_edit_last', '1'),
(114, 4, 'back', ''),
(115, 4, '_back', 'field_59cc649b98212'),
(116, 4, 'next', '6'),
(117, 4, '_next', 'field_59cc64aa98213'),
(118, 36, 'h1_titles_first_word', 'About'),
(119, 36, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(120, 36, 'h1_titles_word_in_brackets', 'Us'),
(121, 36, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(122, 36, 'back', ''),
(123, 36, '_back', 'field_59cc649b98212'),
(124, 36, 'next', '6'),
(125, 36, '_next', 'field_59cc64aa98213'),
(126, 6, 'back', '4'),
(127, 6, '_back', 'field_59cc649b98212'),
(128, 6, 'next', '8'),
(129, 6, '_next', 'field_59cc64aa98213'),
(130, 37, 'h1_titles_first_word', 'About'),
(131, 37, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(132, 37, 'h1_titles_word_in_brackets', 'You'),
(133, 37, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(134, 37, 'back', '4'),
(135, 37, '_back', 'field_59cc649b98212'),
(136, 37, 'next', '8'),
(137, 37, '_next', 'field_59cc64aa98213'),
(138, 8, 'back', '6'),
(139, 8, '_back', 'field_59cc649b98212'),
(140, 8, 'next', ''),
(141, 8, '_next', 'field_59cc64aa98213'),
(142, 38, 'h1_titles_first_word', 'Next'),
(143, 38, '_h1_titles_first_word', 'field_59cc6327d5d4d'),
(144, 38, 'h1_titles_word_in_brackets', 'Steps'),
(145, 38, '_h1_titles_word_in_brackets', 'field_59cc634dd5d4e'),
(146, 38, 'back', '6'),
(147, 38, '_back', 'field_59cc649b98212'),
(148, 38, 'next', ''),
(149, 38, '_next', 'field_59cc64aa98213') ;

#
# End of data contents of table `wp_3_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_posts`
#

DROP TABLE IF EXISTS `wp_3_posts`;


#
# Table structure of table `wp_3_posts`
#

CREATE TABLE `wp_3_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_posts`
#
INSERT INTO `wp_3_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-09-26 03:12:18', '2017-09-26 03:12:18', 'Welcome to <a href="http://studiobarre-demo.com/">Studio Barre Sites</a>. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2017-09-26 03:12:18', '2017-09-26 03:12:18', '', 0, 'http://studiobarre-demo.com/franchising/?p=1', 0, 'post', '', 1),
(2, 1, '2017-09-26 03:12:18', '2017-09-26 03:12:18', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://studiobarre-demo.com/franchising/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2017-09-26 03:35:40', '2017-09-26 03:35:40', '', 0, 'http://studiobarre-demo.com/franchising/?page_id=2', 0, 'page', '', 0),
(3, 1, '2017-09-26 03:20:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-09-26 03:20:28', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/franchising/?p=3', 0, 'post', '', 0),
(4, 1, '2017-09-26 03:21:29', '2017-09-26 03:21:29', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n<br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-09-28 02:57:15', '2017-09-28 02:57:15', '', 0, 'http://studiobarre-demo.com/franchising/?page_id=4', 0, 'page', '', 0),
(5, 1, '2017-09-26 03:21:29', '2017-09-26 03:21:29', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-09-26 03:21:29', '2017-09-26 03:21:29', '', 4, 'http://studiobarre-demo.com/franchising/2017/09/26/4-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2017-09-26 03:21:43', '2017-09-26 03:21:43', 'Imagine having the privilege of transforming bodies and lives by providing a service that helps clients gain confidence and create beautiful physiques.  Imagine a business that excites you every single day and allows you to work a schedule that truly compliments your lifestyle, and a place where friendships are built and strengthened.  And imagine an opportunity that truly rewards you for your hard work with a desirable income that enables you to follow your dreams, both in and outside of the studio.\r\n<h2>ideal candidate profile</h2>\r\nAn ideal Studio Barre Franchise Candidate understands the attention a young franchise requires. This franchise model provides you with a phenomenal team of mentors along with structure and guidance on a daily basis, but it absolutely requires your own personal touch. A successful studio is one where clients directly and immediately experience results. The demand for more is organic – it occurs all on its own - and that demand (along with your clientele) grows with the right attention and perseverance. This is not just a job, this is an absolute lifestyle. Please email us at <a title="franchising@studiobarre.com" href="mailto:franchising@studiobarre.com" target="_blank">franchising@studiobarre.com</a> for an application.\r\n<h2>minimal financial requirements</h2>\r\nThe Minimum financial requirements to open your own Studio Barre including the franchise fee and beyond ranges from $100,000 to $150,025.  This includes $34,000 -$36,300 that you must pay us before you open.\r\n<h2>territory</h2>\r\nThe territory protection will be deemed upon the submission of your location.', 'About You', '', 'publish', 'closed', 'closed', '', 'about-you', '', '', '2017-09-28 03:00:04', '2017-09-28 03:00:04', '', 0, 'http://studiobarre-demo.com/franchising/?page_id=6', 0, 'page', '', 0),
(7, 1, '2017-09-26 03:21:43', '2017-09-26 03:21:43', '', 'About You', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-09-26 03:21:43', '2017-09-26 03:21:43', '', 6, 'http://studiobarre-demo.com/franchising/2017/09/26/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2017-09-26 03:21:59', '2017-09-26 03:21:59', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n 	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n 	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf" target="_blank" rel="noopener">Click here to download our application</a>.</li>\r\n 	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n 	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.', 'Next Steps', '', 'publish', 'closed', 'closed', '', 'next-steps', '', '', '2017-09-28 02:58:05', '2017-09-28 02:58:05', '', 0, 'http://studiobarre-demo.com/franchising/?page_id=8', 0, 'page', '', 0),
(9, 1, '2017-09-26 03:21:59', '2017-09-26 03:21:59', '', 'Next Steps', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-09-26 03:21:59', '2017-09-26 03:21:59', '', 8, 'http://studiobarre-demo.com/franchising/2017/09/26/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2017-09-26 03:35:40', '2017-09-26 03:35:40', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://studiobarre-demo.com/franchising/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-09-26 03:35:40', '2017-09-26 03:35:40', '', 2, 'http://studiobarre-demo.com/franchising/2017/09/26/2-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2017-09-26 03:45:57', '2017-09-26 03:45:57', ' ', '', '', 'publish', 'closed', 'closed', '', '11', '', '', '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 0, 'http://studiobarre-demo.com/franchising/?p=11', 3, 'nav_menu_item', '', 0),
(12, 1, '2017-09-26 03:45:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-09-26 03:45:43', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/franchising/?p=12', 1, 'nav_menu_item', '', 0),
(13, 1, '2017-09-26 03:45:58', '2017-09-26 03:45:58', ' ', '', '', 'publish', 'closed', 'closed', '', '13', '', '', '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 0, 'http://studiobarre-demo.com/franchising/?p=13', 4, 'nav_menu_item', '', 0),
(14, 1, '2017-09-26 03:45:58', '2017-09-26 03:45:58', ' ', '', '', 'publish', 'closed', 'closed', '', '14', '', '', '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 0, 'http://studiobarre-demo.com/franchising/?p=14', 5, 'nav_menu_item', '', 0),
(15, 1, '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', '< go back to main site', '', 'publish', 'closed', 'closed', '', 'go-back-to-main-site', '', '', '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 0, 'http://studiobarre-demo.com/franchising/?p=15', 1, 'nav_menu_item', '', 0),
(16, 1, '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 'Find your studio', '', 'publish', 'closed', 'closed', '', 'find-your-studio', '', '', '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 0, 'http://studiobarre-demo.com/franchising/?p=16', 2, 'nav_menu_item', '', 0),
(17, 1, '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 'Mentors', '', 'publish', 'closed', 'closed', '', 'mentors', '', '', '2017-09-26 03:52:33', '2017-09-26 03:52:33', '', 0, 'http://studiobarre-demo.com/franchising/?p=17', 6, 'nav_menu_item', '', 0),
(18, 1, '2017-09-26 04:25:57', '2017-09-26 04:25:57', '', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2017-09-26 04:25:57', '2017-09-26 04:25:57', '', 0, 'http://studiobarre-demo.com/franchising/?page_id=18', 0, 'page', '', 0),
(19, 1, '2017-09-26 04:25:57', '2017-09-26 04:25:57', '', 'Thank You', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-09-26 04:25:57', '2017-09-26 04:25:57', '', 18, 'http://studiobarre-demo.com/franchising/2017/09/26/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2017-09-26 04:31:11', '2017-09-26 04:31:11', '<iframe width="560" height="315" src="https://www.youtube.com/embed/aBqkl7k7-O0" frameborder="0" allowfullscreen></iframe><br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.', 'About Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-09-26 04:31:11', '2017-09-26 04:31:11', '', 4, 'http://studiobarre-demo.com/franchising/2017/09/26/4-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-09-26 04:38:14', '2017-09-26 04:38:14', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n><br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.', 'About Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-09-26 04:38:14', '2017-09-26 04:38:14', '', 4, 'http://studiobarre-demo.com/franchising/2017/09/26/4-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2017-09-26 04:39:38', '2017-09-26 04:39:38', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n<br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.', 'About Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-09-26 04:39:38', '2017-09-26 04:39:38', '', 4, 'http://studiobarre-demo.com/franchising/2017/09/26/4-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-09-26 05:07:08', '2017-09-26 05:07:08', 'Imagine having the privilege of transforming bodies and lives by providing a service that helps clients gain confidence and create beautiful physiques.  Imagine a business that excites you every single day and allows you to work a schedule that truly compliments your lifestyle, and a place where friendships are built and strengthened.  And imagine an opportunity that truly rewards you for your hard work with a desirable income that enables you to follow your dreams, both in and outside of the studio.\r\n<h2>ideal candidate profile</h2>\r\nAn ideal Studio Barre Franchise Candidate understands the attention a young franchise requires. This franchise model provides you with a phenomenal team of mentors along with structure and guidance on a daily basis, but it absolutely requires your own personal touch. A successful studio is one where clients directly and immediately experience results. The demand for more is organic – it occurs all on its own - and that demand (along with your clientele) grows with the right attention and perseverance. This is not just a job, this is an absolute lifestyle. Please email us at <a title="franchising@studiobarre.com" href="mailto:franchising@studiobarre.com" target="_blank">franchising@studiobarre.com</a> for an application.\r\n<h2>minimal financial requirements</h2>\r\nThe Minimum financial requirements to open your own Studio Barre including the franchise fee and beyond ranges from $100,000 to $150,025.  This includes $34,000 -$36,300 that you must pay us before you open.\r\n<h2>territory</h2>\r\nThe territory protection will be deemed upon the submission of your location.', 'About You', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-09-26 05:07:08', '2017-09-26 05:07:08', '', 6, 'http://studiobarre-demo.com/franchising/2017/09/26/6-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2017-09-26 05:07:55', '2017-09-26 05:07:55', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre.com/franchising/wp-content/uploads/sites/4/2014/05/StudioBarreFranchiseApplication.pdf" target="_blank">Click here to download our application</a>.</li>\r\n	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.', 'Next Steps', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-09-26 05:07:55', '2017-09-26 05:07:55', '', 8, 'http://studiobarre-demo.com/franchising/2017/09/26/8-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2017-09-26 05:09:32', '2017-09-26 05:09:32', '', 'StudioBarreFranchiseApplication', '', 'inherit', 'open', 'closed', '', 'studiobarrefranchiseapplication', '', '', '2017-09-26 05:09:32', '2017-09-26 05:09:32', '', 0, 'http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf', 0, 'attachment', 'application/pdf', 0),
(26, 1, '2017-09-26 05:09:53', '2017-09-26 05:09:53', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n 	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n 	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf" target="_blank" rel="noopener">Click here to download our application</a>.</li>\r\n 	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n 	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.', 'Next Steps', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-09-26 05:09:53', '2017-09-26 05:09:53', '', 8, 'http://studiobarre-demo.com/franchising/2017/09/26/8-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2017-09-28 02:50:12', '2017-09-28 02:50:12', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"page-franchising.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'H1 Titles', 'h1-titles', 'publish', 'closed', 'closed', '', 'group_59cc631d14e08', '', '', '2017-09-28 02:50:51', '2017-09-28 02:50:51', '', 0, 'http://studiobarre-demo.com/franchising/?post_type=acf-field-group&#038;p=27', 0, 'acf-field-group', '', 0),
(28, 1, '2017-09-28 02:50:12', '2017-09-28 02:50:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'H1 Titles First Word', 'h1_titles_first_word', 'publish', 'closed', 'closed', '', 'field_59cc6327d5d4d', '', '', '2017-09-28 02:50:12', '2017-09-28 02:50:12', '', 27, 'http://studiobarre-demo.com/franchising/?post_type=acf-field&p=28', 0, 'acf-field', '', 0),
(29, 1, '2017-09-28 02:50:12', '2017-09-28 02:50:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'H1 Titles Word In Brackets', 'h1_titles_word_in_brackets', 'publish', 'closed', 'closed', '', 'field_59cc634dd5d4e', '', '', '2017-09-28 02:50:12', '2017-09-28 02:50:12', '', 27, 'http://studiobarre-demo.com/franchising/?post_type=acf-field&p=29', 1, 'acf-field', '', 0),
(30, 1, '2017-09-28 02:51:08', '2017-09-28 02:51:08', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n<br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.', 'About Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-09-28 02:51:08', '2017-09-28 02:51:08', '', 4, 'http://studiobarre-demo.com/franchising/2017/09/28/4-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2017-09-28 02:51:27', '2017-09-28 02:51:27', 'Imagine having the privilege of transforming bodies and lives by providing a service that helps clients gain confidence and create beautiful physiques.  Imagine a business that excites you every single day and allows you to work a schedule that truly compliments your lifestyle, and a place where friendships are built and strengthened.  And imagine an opportunity that truly rewards you for your hard work with a desirable income that enables you to follow your dreams, both in and outside of the studio.\r\n<h2>ideal candidate profile</h2>\r\nAn ideal Studio Barre Franchise Candidate understands the attention a young franchise requires. This franchise model provides you with a phenomenal team of mentors along with structure and guidance on a daily basis, but it absolutely requires your own personal touch. A successful studio is one where clients directly and immediately experience results. The demand for more is organic – it occurs all on its own - and that demand (along with your clientele) grows with the right attention and perseverance. This is not just a job, this is an absolute lifestyle. Please email us at <a title="franchising@studiobarre.com" href="mailto:franchising@studiobarre.com" target="_blank">franchising@studiobarre.com</a> for an application.\r\n<h2>minimal financial requirements</h2>\r\nThe Minimum financial requirements to open your own Studio Barre including the franchise fee and beyond ranges from $100,000 to $150,025.  This includes $34,000 -$36,300 that you must pay us before you open.\r\n<h2>territory</h2>\r\nThe territory protection will be deemed upon the submission of your location.', 'About You', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-09-28 02:51:27', '2017-09-28 02:51:27', '', 6, 'http://studiobarre-demo.com/franchising/2017/09/28/6-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2017-09-28 02:51:41', '2017-09-28 02:51:41', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n 	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n 	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf" target="_blank" rel="noopener">Click here to download our application</a>.</li>\r\n 	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n 	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.', 'Next Steps', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-09-28 02:51:41', '2017-09-28 02:51:41', '', 8, 'http://studiobarre-demo.com/franchising/2017/09/28/8-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2017-09-28 02:56:02', '2017-09-28 02:56:02', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"page-franchising.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Back Buttons', 'back-buttons', 'publish', 'closed', 'closed', '', 'group_59cc6495231b4', '', '', '2017-09-28 02:56:58', '2017-09-28 02:56:58', '', 0, 'http://studiobarre-demo.com/franchising/?post_type=acf-field-group&#038;p=33', 1, 'acf-field-group', '', 0),
(34, 1, '2017-09-28 02:56:02', '2017-09-28 02:56:02', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:1;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Back', 'back', 'publish', 'closed', 'closed', '', 'field_59cc649b98212', '', '', '2017-09-28 02:56:34', '2017-09-28 02:56:34', '', 33, 'http://studiobarre-demo.com/franchising/?post_type=acf-field&#038;p=34', 0, 'acf-field', '', 0),
(35, 1, '2017-09-28 02:56:02', '2017-09-28 02:56:02', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:1;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Next', 'next', 'publish', 'closed', 'closed', '', 'field_59cc64aa98213', '', '', '2017-09-28 02:56:34', '2017-09-28 02:56:34', '', 33, 'http://studiobarre-demo.com/franchising/?post_type=acf-field&#038;p=35', 1, 'acf-field', '', 0),
(36, 1, '2017-09-28 02:57:15', '2017-09-28 02:57:15', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n<br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.', 'About Us', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-09-28 02:57:15', '2017-09-28 02:57:15', '', 4, 'http://studiobarre-demo.com/franchising/2017/09/28/4-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2017-09-28 02:57:35', '2017-09-28 02:57:35', 'Imagine having the privilege of transforming bodies and lives by providing a service that helps clients gain confidence and create beautiful physiques.  Imagine a business that excites you every single day and allows you to work a schedule that truly compliments your lifestyle, and a place where friendships are built and strengthened.  And imagine an opportunity that truly rewards you for your hard work with a desirable income that enables you to follow your dreams, both in and outside of the studio.\r\n<h2>ideal candidate profile</h2>\r\nAn ideal Studio Barre Franchise Candidate understands the attention a young franchise requires. This franchise model provides you with a phenomenal team of mentors along with structure and guidance on a daily basis, but it absolutely requires your own personal touch. A successful studio is one where clients directly and immediately experience results. The demand for more is organic – it occurs all on its own - and that demand (along with your clientele) grows with the right attention and perseverance. This is not just a job, this is an absolute lifestyle. Please email us at <a title="franchising@studiobarre.com" href="mailto:franchising@studiobarre.com" target="_blank">franchising@studiobarre.com</a> for an application.\r\n<h2>minimal financial requirements</h2>\r\nThe Minimum financial requirements to open your own Studio Barre including the franchise fee and beyond ranges from $100,000 to $150,025.  This includes $34,000 -$36,300 that you must pay us before you open.\r\n<h2>territory</h2>\r\nThe territory protection will be deemed upon the submission of your location.', 'About You', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-09-28 02:57:35', '2017-09-28 02:57:35', '', 6, 'http://studiobarre-demo.com/franchising/2017/09/28/6-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_3_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(38, 1, '2017-09-28 02:58:05', '2017-09-28 02:58:05', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n 	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n 	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf" target="_blank" rel="noopener">Click here to download our application</a>.</li>\r\n 	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n 	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.', 'Next Steps', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-09-28 02:58:05', '2017-09-28 02:58:05', '', 8, 'http://studiobarre-demo.com/franchising/2017/09/28/8-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_3_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_form`
#

DROP TABLE IF EXISTS `wp_3_rg_form`;


#
# Table structure of table `wp_3_rg_form`
#

CREATE TABLE `wp_3_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_form`
#
INSERT INTO `wp_3_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(2, 'Studio Barre - Own A Studio', '2017-09-26 03:39:32', 1, 1),
(3, 'Studio Barre - Own A Studio', '2017-09-26 04:25:16', 1, 0) ;

#
# End of data contents of table `wp_3_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_3_rg_form_meta`;


#
# Table structure of table `wp_3_rg_form_meta`
#

CREATE TABLE `wp_3_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_form_meta`
#
INSERT INTO `wp_3_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(2, '{"title":"Studio Barre - Own A Studio","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"phone","id":6,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","displayOnly":"","pageNumber":1,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"text","id":4,"label":"City","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"text","id":7,"label":"State","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"text","id":10,"label":"Zip Code","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1}],"version":"2.2.5","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","notifications":{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":94,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}}', '', '{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":94,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(3, '{"title":"Studio Barre - Own A Studio","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"phone","id":6,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","displayOnly":"","pageNumber":1,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"text","id":4,"label":"City","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"text","id":7,"label":"State","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":10,"label":"Zip Code","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.5","id":3,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","notifications":{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":94,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}}', NULL, '{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"page","message":"","url":"","pageId":18,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_3_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_form_view`
#

DROP TABLE IF EXISTS `wp_3_rg_form_view`;


#
# Table structure of table `wp_3_rg_form_view`
#

CREATE TABLE `wp_3_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_form_view`
#
INSERT INTO `wp_3_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 3, '2017-09-26 04:03:44', '', 53),
(2, 2, '2017-09-26 04:04:45', '', 16),
(3, 3, '2017-09-27 05:03:37', '', 70),
(4, 3, '2017-09-28 15:34:50', '', 6) ;

#
# End of data contents of table `wp_3_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_3_rg_incomplete_submissions`;


#
# Table structure of table `wp_3_rg_incomplete_submissions`
#

CREATE TABLE `wp_3_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_3_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_lead`
#

DROP TABLE IF EXISTS `wp_3_rg_lead`;


#
# Table structure of table `wp_3_rg_lead`
#

CREATE TABLE `wp_3_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_lead`
#

#
# End of data contents of table `wp_3_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_3_rg_lead_detail`;


#
# Table structure of table `wp_3_rg_lead_detail`
#

CREATE TABLE `wp_3_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_lead_detail`
#

#
# End of data contents of table `wp_3_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_3_rg_lead_detail_long`;


#
# Table structure of table `wp_3_rg_lead_detail_long`
#

CREATE TABLE `wp_3_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_lead_detail_long`
#

#
# End of data contents of table `wp_3_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_3_rg_lead_meta`;


#
# Table structure of table `wp_3_rg_lead_meta`
#

CREATE TABLE `wp_3_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_lead_meta`
#

#
# End of data contents of table `wp_3_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_3_rg_lead_notes`;


#
# Table structure of table `wp_3_rg_lead_notes`
#

CREATE TABLE `wp_3_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_rg_lead_notes`
#

#
# End of data contents of table `wp_3_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_simple_history`
#

DROP TABLE IF EXISTS `wp_3_simple_history`;


#
# Table structure of table `wp_3_simple_history`
#

CREATE TABLE `wp_3_simple_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `logger` varchar(30) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `occasionsID` varchar(32) DEFAULT NULL,
  `initiator` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `loggerdate` (`logger`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_3_simple_history`
#
INSERT INTO `wp_3_simple_history` ( `id`, `date`, `logger`, `level`, `message`, `occasionsID`, `initiator`) VALUES
(1, '2017-09-26 03:20:26', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '38759f6932185b9042c632241c4236bd', 'wp_user'),
(2, '2017-09-26 03:20:26', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1ad3dc78aa49c0ba94f3962a5078dae4', 'wp_user'),
(3, '2017-09-26 03:20:27', 'SimpleLogger', 'info', 'Because Simple History was just recently installed, this feed does not contain much events yet. But keep the plugin activated and soon you will see detailed information about page edits, plugin updates, user logins, and much more.', '1c6ed1ff4a97400596b011813faa932f', 'wp'),
(4, '2017-09-26 03:20:27', 'SimpleLogger', 'info', 'Welcome to Simple History!\n\nThis is the main history feed. It will contain events that this plugin has logged.', '0c4babaacbe315745cbb536eaa41278c', 'wp'),
(5, '2017-09-26 03:20:27', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '38759f6932185b9042c632241c4236bd', 'wp'),
(6, '2017-09-26 03:20:27', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1ad3dc78aa49c0ba94f3962a5078dae4', 'wp'),
(7, '2017-09-26 03:20:40', 'SimpleThemeLogger', 'info', 'Switched theme to "{theme_name}" from "{prev_theme_name}"', '24d54a3b486c945909b7c0fdb458ab71', 'wp_user'),
(8, '2017-09-26 03:21:29', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'c2121eaaa1ff6c27f7574d3917549c89', 'wp_user'),
(9, '2017-09-26 03:21:43', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '7b369997985d1b51708887901fdca476', 'wp_user'),
(10, '2017-09-26 03:21:55', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '5eecdb0467714a2ca01c19d43ee25ce5', 'wp_user'),
(11, '2017-09-26 03:21:59', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(12, '2017-09-26 03:22:14', 'SimpleOptionsLogger', 'info', 'Updated option "{option}"', '212da39e38cf013809e8805ecda8826b', 'wp_user'),
(13, '2017-09-26 03:22:14', 'SimpleOptionsLogger', 'info', 'Updated option "{option}"', 'd6d6c24403b14eae723a2c801af61546', 'wp_user'),
(14, '2017-09-26 03:35:40', 'SimplePostLogger', 'info', 'Moved {post_type} "{post_title}" to the trash', 'e269fbd6ff3952a8470cdf4df99a31fa', 'wp_user'),
(15, '2017-09-26 03:45:57', 'SimpleCategoriesLogger', 'info', 'Added term "{term_name}" in taxonomy "{term_taxonomy}"', '370179e7d466720397349ea7238a09e7', 'wp_user'),
(16, '2017-09-26 03:45:57', 'SimpleMenuLogger', 'info', 'Created menu "{menu_name}"', '0e2f1cf085f7429cc14792e3f5592724', 'wp_user'),
(17, '2017-09-26 03:46:03', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '6b60fa51188234fd559bc3451e313205', 'wp_user'),
(18, '2017-09-26 03:46:04', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user'),
(19, '2017-09-26 03:52:33', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '2e8c94ad133e45e2f44a9d8683bd6892', 'wp_user'),
(20, '2017-09-26 03:52:33', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user'),
(21, '2017-09-26 04:12:59', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(22, '2017-09-26 04:13:05', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '09a726d32a0c2716e00760f307e5efa8', 'wp_user'),
(23, '2017-09-26 04:13:09', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(24, '2017-09-26 04:13:48', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(25, '2017-09-26 04:25:57', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '0d4e48b75b72620b5306b11eb7e0c007', 'wp_user'),
(26, '2017-09-26 04:31:11', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(27, '2017-09-26 04:38:14', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(28, '2017-09-26 04:39:38', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(29, '2017-09-26 05:07:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '09a726d32a0c2716e00760f307e5efa8', 'wp_user'),
(30, '2017-09-26 05:07:55', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(31, '2017-09-26 05:09:32', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'ade94d8b70945e4de3a20ed0fd686b5d', 'wp_user'),
(32, '2017-09-26 05:09:53', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(33, '2017-09-28 02:50:12', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '10aabe81b5d86d123315350e79668997', 'wp_user'),
(34, '2017-09-28 02:50:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '1db64a13390ff3a6ff4d7b5f9e7f3307', 'wp_user'),
(35, '2017-09-28 02:50:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '1d3094be0972d351110fe1b8dd0aa5a8', 'wp_user'),
(36, '2017-09-28 02:50:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'dee4f8b032e2304333c5c39d5933c544', 'wp_user'),
(37, '2017-09-28 02:50:51', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'dee4f8b032e2304333c5c39d5933c544', 'wp_user'),
(38, '2017-09-28 02:50:51', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'dee4f8b032e2304333c5c39d5933c544', 'wp_user'),
(39, '2017-09-28 02:51:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(40, '2017-09-28 02:51:27', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '09a726d32a0c2716e00760f307e5efa8', 'wp_user'),
(41, '2017-09-28 02:51:41', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(42, '2017-09-28 02:56:02', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '95e95fab98e46735625bf3dba9fbc73a', 'wp_user'),
(43, '2017-09-28 02:56:02', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '66aeb16fb1e8f6b869de4b306bb1b9f1', 'wp_user'),
(44, '2017-09-28 02:56:02', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b0844db61f45ff6e21b184a82a758f33', 'wp_user'),
(45, '2017-09-28 02:56:02', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b2613d0ec98ff193a4e8f5993ec3e24f', 'wp_user'),
(46, '2017-09-28 02:56:34', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b2613d0ec98ff193a4e8f5993ec3e24f', 'wp_user'),
(47, '2017-09-28 02:56:34', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '66aeb16fb1e8f6b869de4b306bb1b9f1', 'wp_user'),
(48, '2017-09-28 02:56:34', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b0844db61f45ff6e21b184a82a758f33', 'wp_user'),
(49, '2017-09-28 02:56:34', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b2613d0ec98ff193a4e8f5993ec3e24f', 'wp_user'),
(50, '2017-09-28 02:56:58', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b2613d0ec98ff193a4e8f5993ec3e24f', 'wp_user'),
(51, '2017-09-28 02:56:58', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'b2613d0ec98ff193a4e8f5993ec3e24f', 'wp_user'),
(52, '2017-09-28 02:57:15', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c7e3179ed2596305f30e74e151bea2d0', 'wp_user'),
(53, '2017-09-28 02:57:35', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '09a726d32a0c2716e00760f307e5efa8', 'wp_user'),
(54, '2017-09-28 02:58:05', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(55, '2017-09-28 03:00:04', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '09a726d32a0c2716e00760f307e5efa8', 'wp_user') ;

#
# End of data contents of table `wp_3_simple_history`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_simple_history_contexts`
#

DROP TABLE IF EXISTS `wp_3_simple_history_contexts`;


#
# Table structure of table `wp_3_simple_history_contexts`
#

CREATE TABLE `wp_3_simple_history_contexts` (
  `context_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `history_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` longtext,
  PRIMARY KEY (`context_id`),
  KEY `history_id` (`history_id`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=568 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_3_simple_history_contexts`
#
INSERT INTO `wp_3_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1, 1, 'plugin_name', 'Simple History'),
(2, 1, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(3, 1, 'plugin_url', 'http://simple-history.com'),
(4, 1, 'plugin_version', '2.18'),
(5, 1, 'plugin_author', 'Pär Thernström'),
(6, 1, '_message_key', 'plugin_installed'),
(7, 1, '_user_id', '1'),
(8, 1, '_user_login', 'destroyer'),
(9, 1, '_user_email', 'garrettcullen@yahoo.com'),
(10, 1, '_server_remote_addr', '::1'),
(11, 1, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/themes.php'),
(12, 2, 'plugin_name', 'Simple History'),
(13, 2, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(14, 2, 'plugin_url', 'http://simple-history.com'),
(15, 2, 'plugin_version', '2.18'),
(16, 2, 'plugin_author', 'Pär Thernström'),
(17, 2, 'plugin_slug', 'simple-history'),
(18, 2, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(19, 2, '_message_key', 'plugin_activated'),
(20, 2, '_user_id', '1'),
(21, 2, '_user_login', 'destroyer'),
(22, 2, '_user_email', 'garrettcullen@yahoo.com'),
(23, 2, '_server_remote_addr', '::1'),
(24, 2, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/themes.php'),
(25, 3, '_user_id', '1'),
(26, 3, '_user_login', 'destroyer'),
(27, 3, '_user_email', 'garrettcullen@yahoo.com'),
(28, 3, '_server_remote_addr', '::1'),
(29, 3, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/themes.php'),
(30, 4, '_user_id', '1'),
(31, 4, '_user_login', 'destroyer'),
(32, 4, '_user_email', 'garrettcullen@yahoo.com'),
(33, 4, '_server_remote_addr', '::1'),
(34, 4, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/themes.php'),
(35, 5, 'plugin_name', 'Simple History'),
(36, 5, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(37, 5, 'plugin_url', 'http://simple-history.com'),
(38, 5, 'plugin_version', '2.18'),
(39, 5, 'plugin_author', 'Pär Thernström'),
(40, 5, '_message_key', 'plugin_installed'),
(41, 5, '_wp_cron_running', 'true'),
(42, 5, '_server_remote_addr', '::1'),
(43, 5, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-cron.php?doing_wp_cron=1506396027.1165189743041992187500'),
(44, 6, 'plugin_name', 'Simple History'),
(45, 6, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(46, 6, 'plugin_url', 'http://simple-history.com'),
(47, 6, 'plugin_version', '2.18'),
(48, 6, 'plugin_author', 'Pär Thernström'),
(49, 6, 'plugin_slug', 'simple-history'),
(50, 6, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(51, 6, '_message_key', 'plugin_activated'),
(52, 6, '_wp_cron_running', 'true'),
(53, 6, '_server_remote_addr', '::1'),
(54, 6, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-cron.php?doing_wp_cron=1506396027.1165189743041992187500'),
(55, 7, 'theme_name', ''),
(56, 7, 'theme_version', ''),
(57, 7, 'prev_theme_name', 'twentyseventeen'),
(58, 7, 'prev_theme_version', 'false'),
(59, 7, '_message_key', 'theme_switched'),
(60, 7, '_user_id', '1'),
(61, 7, '_user_login', 'destroyer'),
(62, 7, '_user_email', 'garrettcullen@yahoo.com'),
(63, 7, '_server_remote_addr', '::1'),
(64, 7, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/themes.php'),
(65, 8, 'post_id', '4'),
(66, 8, 'post_type', 'page'),
(67, 8, 'post_title', 'About Us'),
(68, 8, '_message_key', 'post_created'),
(69, 8, '_user_id', '1'),
(70, 8, '_user_login', 'destroyer'),
(71, 8, '_user_email', 'garrettcullen@yahoo.com'),
(72, 8, '_server_remote_addr', '::1'),
(73, 8, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(74, 9, 'post_id', '6'),
(75, 9, 'post_type', 'page'),
(76, 9, 'post_title', 'About You'),
(77, 9, '_message_key', 'post_created'),
(78, 9, '_user_id', '1'),
(79, 9, '_user_login', 'destroyer'),
(80, 9, '_user_email', 'garrettcullen@yahoo.com'),
(81, 9, '_server_remote_addr', '::1'),
(82, 9, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(83, 10, 'post_id', '8'),
(84, 10, 'post_type', 'page'),
(85, 10, 'post_title', 'Next Steps'),
(86, 10, '_message_key', 'post_created'),
(87, 10, '_user_id', '1'),
(88, 10, '_user_login', 'destroyer'),
(89, 10, '_user_email', 'garrettcullen@yahoo.com'),
(90, 10, '_server_remote_addr', '::1'),
(91, 10, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=page'),
(92, 11, 'post_id', '8'),
(93, 11, 'post_type', 'page'),
(94, 11, 'post_title', 'Next Steps'),
(95, 11, 'post_prev_post_name', ''),
(96, 11, 'post_new_post_name', 'next-steps'),
(97, 11, 'post_prev_post_status', 'draft'),
(98, 11, 'post_new_post_status', 'publish'),
(99, 11, 'post_prev_post_date', '2017-09-26 03:21:55'),
(100, 11, 'post_new_post_date', '2017-09-26 03:21:59') ;
INSERT INTO `wp_3_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(101, 11, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(102, 11, 'post_new_post_date_gmt', '2017-09-26 03:21:59'),
(103, 11, '_message_key', 'post_updated'),
(104, 11, '_user_id', '1'),
(105, 11, '_user_login', 'destroyer'),
(106, 11, '_user_email', 'garrettcullen@yahoo.com'),
(107, 11, '_server_remote_addr', '::1'),
(108, 11, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(109, 12, 'option', 'show_on_front'),
(110, 12, 'old_value', 'posts'),
(111, 12, 'new_value', 'page'),
(112, 12, 'option_page', 'reading'),
(113, 12, '_message_key', 'option_updated'),
(114, 12, '_user_id', '1'),
(115, 12, '_user_login', 'destroyer'),
(116, 12, '_user_email', 'garrettcullen@yahoo.com'),
(117, 12, '_server_remote_addr', '::1'),
(118, 12, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/options-reading.php'),
(119, 13, 'option', 'page_on_front'),
(120, 13, 'old_value', '0'),
(121, 13, 'new_value', '4'),
(122, 13, 'option_page', 'reading'),
(123, 13, 'new_post_title', 'About Us'),
(124, 13, '_message_key', 'option_updated'),
(125, 13, '_user_id', '1'),
(126, 13, '_user_login', 'destroyer'),
(127, 13, '_user_email', 'garrettcullen@yahoo.com'),
(128, 13, '_server_remote_addr', '::1'),
(129, 13, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/options-reading.php'),
(130, 14, 'post_id', '2'),
(131, 14, 'post_type', 'page'),
(132, 14, 'post_title', 'Sample Page'),
(133, 14, '_message_key', 'post_trashed'),
(134, 14, '_user_id', '1'),
(135, 14, '_user_login', 'destroyer'),
(136, 14, '_user_email', 'garrettcullen@yahoo.com'),
(137, 14, '_server_remote_addr', '::1'),
(138, 14, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/edit.php?post_type=page'),
(139, 15, 'term_id', '2'),
(140, 15, 'term_name', 'Top Nav'),
(141, 15, 'term_taxonomy', 'nav_menu'),
(142, 15, '_message_key', 'created_term'),
(143, 15, '_user_id', '1'),
(144, 15, '_user_login', 'destroyer'),
(145, 15, '_user_email', 'garrettcullen@yahoo.com'),
(146, 15, '_server_remote_addr', '::1'),
(147, 15, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/nav-menus.php'),
(148, 16, 'term_id', '2'),
(149, 16, 'menu_name', 'Top Nav'),
(150, 16, '_message_key', 'created_menu'),
(151, 16, '_user_id', '1'),
(152, 16, '_user_login', 'destroyer'),
(153, 16, '_user_email', 'garrettcullen@yahoo.com'),
(154, 16, '_server_remote_addr', '::1'),
(155, 16, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/nav-menus.php'),
(156, 17, 'menu_id', '2'),
(157, 17, 'menu_name', 'Top Nav'),
(158, 17, 'menu_items_added', '0'),
(159, 17, 'menu_items_removed', '0'),
(160, 17, '_message_key', 'edited_menu'),
(161, 17, '_user_id', '1'),
(162, 17, '_user_login', 'destroyer'),
(163, 17, '_user_email', 'garrettcullen@yahoo.com'),
(164, 17, '_server_remote_addr', '::1'),
(165, 17, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/nav-menus.php?menu=2'),
(166, 18, 'term_id', '2'),
(167, 18, 'from_term_name', 'Top Nav'),
(168, 18, 'from_term_taxonomy', 'nav_menu'),
(169, 18, 'from_term_slug', 'top-nav'),
(170, 18, 'from_term_description', ''),
(171, 18, 'to_term_name', 'Top Nav'),
(172, 18, 'to_term_taxonomy', 'nav_menu'),
(173, 18, 'to_term_slug', 'null'),
(174, 18, 'to_term_description', ''),
(175, 18, '_message_key', 'edited_term'),
(176, 18, '_user_id', '1'),
(177, 18, '_user_login', 'destroyer'),
(178, 18, '_user_email', 'garrettcullen@yahoo.com'),
(179, 18, '_server_remote_addr', '::1'),
(180, 18, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/nav-menus.php?menu=2'),
(181, 19, 'menu_id', '2'),
(182, 19, 'menu_name', 'Top Nav'),
(183, 19, 'menu_items_added', '3'),
(184, 19, 'menu_items_removed', '0'),
(185, 19, '_message_key', 'edited_menu'),
(186, 19, '_user_id', '1'),
(187, 19, '_user_login', 'destroyer'),
(188, 19, '_user_email', 'garrettcullen@yahoo.com'),
(189, 19, '_server_remote_addr', '::1'),
(190, 19, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/nav-menus.php?menu=2'),
(191, 20, 'term_id', '2'),
(192, 20, 'from_term_name', 'Top Nav'),
(193, 20, 'from_term_taxonomy', 'nav_menu'),
(194, 20, 'from_term_slug', 'top-nav'),
(195, 20, 'from_term_description', ''),
(196, 20, 'to_term_name', 'Top Nav'),
(197, 20, 'to_term_taxonomy', 'nav_menu'),
(198, 20, 'to_term_slug', 'null'),
(199, 20, 'to_term_description', ''),
(200, 20, '_message_key', 'edited_term') ;
INSERT INTO `wp_3_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(201, 20, '_user_id', '1'),
(202, 20, '_user_login', 'destroyer'),
(203, 20, '_user_email', 'garrettcullen@yahoo.com'),
(204, 20, '_server_remote_addr', '::1'),
(205, 20, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/nav-menus.php?menu=2'),
(206, 21, 'post_id', '4'),
(207, 21, 'post_type', 'page'),
(208, 21, 'post_title', 'About Us'),
(209, 21, '_message_key', 'post_updated'),
(210, 21, '_user_id', '1'),
(211, 21, '_user_login', 'destroyer'),
(212, 21, '_user_email', 'garrettcullen@yahoo.com'),
(213, 21, '_server_remote_addr', '::1'),
(214, 21, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/edit.php?post_type=page'),
(215, 22, 'post_id', '6'),
(216, 22, 'post_type', 'page'),
(217, 22, 'post_title', 'About You'),
(218, 22, '_message_key', 'post_updated'),
(219, 22, '_user_id', '1'),
(220, 22, '_user_login', 'destroyer'),
(221, 22, '_user_email', 'garrettcullen@yahoo.com'),
(222, 22, '_server_remote_addr', '::1'),
(223, 22, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/edit.php?post_type=page'),
(224, 23, 'post_id', '8'),
(225, 23, 'post_type', 'page'),
(226, 23, 'post_title', 'Next Steps'),
(227, 23, '_message_key', 'post_updated'),
(228, 23, '_user_id', '1'),
(229, 23, '_user_login', 'destroyer'),
(230, 23, '_user_email', 'garrettcullen@yahoo.com'),
(231, 23, '_server_remote_addr', '::1'),
(232, 23, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/edit.php?post_type=page'),
(233, 24, 'post_id', '4'),
(234, 24, 'post_type', 'page'),
(235, 24, 'post_title', 'About Us'),
(236, 24, '_message_key', 'post_updated'),
(237, 24, '_user_id', '1'),
(238, 24, '_user_login', 'destroyer'),
(239, 24, '_user_email', 'garrettcullen@yahoo.com'),
(240, 24, '_server_remote_addr', '::1'),
(241, 24, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=4&action=edit'),
(242, 25, 'post_id', '18'),
(243, 25, 'post_type', 'page'),
(244, 25, 'post_title', 'Thank You'),
(245, 25, '_message_key', 'post_created'),
(246, 25, '_user_id', '1'),
(247, 25, '_user_login', 'destroyer'),
(248, 25, '_user_email', 'garrettcullen@yahoo.com'),
(249, 25, '_server_remote_addr', '::1'),
(250, 25, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(251, 26, 'post_id', '4'),
(252, 26, 'post_type', 'page'),
(253, 26, 'post_title', 'About Us'),
(254, 26, 'post_prev_post_content', ''),
(255, 26, 'post_new_post_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/aBqkl7k7-O0" frameborder="0" allowfullscreen></iframe><br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.'),
(256, 26, '_message_key', 'post_updated'),
(257, 26, '_user_id', '1'),
(258, 26, '_user_login', 'destroyer'),
(259, 26, '_user_email', 'garrettcullen@yahoo.com'),
(260, 26, '_server_remote_addr', '::1'),
(261, 26, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=4&action=edit'),
(262, 27, 'post_id', '4'),
(263, 27, 'post_type', 'page'),
(264, 27, 'post_title', 'About Us'),
(265, 27, 'post_prev_post_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/aBqkl7k7-O0" frameborder="0" allowfullscreen></iframe><br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.'),
(266, 27, 'post_new_post_content', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n><br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.'),
(267, 27, '_message_key', 'post_updated'),
(268, 27, '_user_id', '1'),
(269, 27, '_user_login', 'destroyer'),
(270, 27, '_user_email', 'garrettcullen@yahoo.com'),
(271, 27, '_server_remote_addr', '::1'),
(272, 27, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=4&action=edit'),
(273, 28, 'post_id', '4'),
(274, 28, 'post_type', 'page'),
(275, 28, 'post_title', 'About Us'),
(276, 28, 'post_prev_post_content', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n><br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.'),
(277, 28, 'post_new_post_content', '<div class=\'embed-container\'><iframe src=\'https://www.youtube.com/embed/aBqkl7k7-O0\' frameborder=\'0\' allowfullscreen></iframe></div>\r\n<br/><br/>\r\nStudio Barre is a true representation of the partnership created when dancers and fitness professionals came together to work as a team.   This business is truly the culmination of years of professional dance experience, a strong focus on personal training, health and wellness, and a desire to create a program appealing to all fitness levels. The success of the Studio Barre program is quite simple – it creates results. Barre technique has been modified to allow all levels to participate, a fun atmosphere has been added to encourage instructors to add their own personality and personal touch to each class, and physical transformations among the clients are a common occurrence.\r\n<h2>why Studio Barre</h2>\r\nThere are few scenarios that can boast such independence as a franchise opportunity does for the owner, while ensuring that the business provides proven products, methods and experiences that have already been designed and tested.   Studio design, staffing, class format, training, music, choreography, studio atmosphere, business management – these are just a few of your responsibilities as an owner.  The beauty of becoming a member of the Studio Barre Family is that you’re not expected to create this all on your own. You have a framework, you have training, you have guidance, you have support, and you have a voice within Studio Barre.\r\n<h2>industry / market overview</h2>\r\nThe fitness industry boasted $21.8 billion in total revenue in 2012 (IHRSA). This is a sector that has shown significant growth year over year, and one which financial analysts predict will continue to do so.  Barre-based businesses have increased in number within the past 5 years, and consumers are demanding fitness professionals who are knowledgeable and create results, with a clear preference for smaller boutique studio settings that deliver personalized attention.   There will never be a shortage of people wanting to look better, feel stronger, and live healthier, happier lives in more beautiful bodies.\r\n<h2>company mission / vision</h2>\r\nAs a Studio Barre Franchisee, you are in the advantageous position of owning your own business, but not being left on your own. Your success is important to us. You are part of a family that wants to grow and pass along its vision, and as in any newer business opportunity, securing your spot on the ground floor is critical. Studio Barre has been built on a an absolute dedication to customer service, and a staff that understands and supports the need for experience, training, and a commitment to providing each and every member with the full barre experience.'),
(278, 28, '_message_key', 'post_updated'),
(279, 28, '_user_id', '1'),
(280, 28, '_user_login', 'destroyer'),
(281, 28, '_user_email', 'garrettcullen@yahoo.com'),
(282, 28, '_server_remote_addr', '::1'),
(283, 28, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=4&action=edit'),
(284, 29, 'post_id', '6'),
(285, 29, 'post_type', 'page'),
(286, 29, 'post_title', 'About You'),
(287, 29, 'post_prev_post_content', ''),
(288, 29, 'post_new_post_content', 'Imagine having the privilege of transforming bodies and lives by providing a service that helps clients gain confidence and create beautiful physiques.  Imagine a business that excites you every single day and allows you to work a schedule that truly compliments your lifestyle, and a place where friendships are built and strengthened.  And imagine an opportunity that truly rewards you for your hard work with a desirable income that enables you to follow your dreams, both in and outside of the studio.\r\n<h2>ideal candidate profile</h2>\r\nAn ideal Studio Barre Franchise Candidate understands the attention a young franchise requires. This franchise model provides you with a phenomenal team of mentors along with structure and guidance on a daily basis, but it absolutely requires your own personal touch. A successful studio is one where clients directly and immediately experience results. The demand for more is organic – it occurs all on its own - and that demand (along with your clientele) grows with the right attention and perseverance. This is not just a job, this is an absolute lifestyle. Please email us at <a title="franchising@studiobarre.com" href="mailto:franchising@studiobarre.com" target="_blank">franchising@studiobarre.com</a> for an application.\r\n<h2>minimal financial requirements</h2>\r\nThe Minimum financial requirements to open your own Studio Barre including the franchise fee and beyond ranges from $100,000 to $150,025.  This includes $34,000 -$36,300 that you must pay us before you open.\r\n<h2>territory</h2>\r\nThe territory protection will be deemed upon the submission of your location.'),
(289, 29, '_message_key', 'post_updated'),
(290, 29, '_user_id', '1'),
(291, 29, '_user_login', 'destroyer'),
(292, 29, '_user_email', 'garrettcullen@yahoo.com'),
(293, 29, '_server_remote_addr', '::1'),
(294, 29, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=6&action=edit'),
(295, 30, 'post_id', '8'),
(296, 30, 'post_type', 'page'),
(297, 30, 'post_title', 'Next Steps'),
(298, 30, 'post_prev_post_content', ''),
(299, 30, 'post_new_post_content', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre.com/franchising/wp-content/uploads/sites/4/2014/05/StudioBarreFranchiseApplication.pdf" target="_blank">Click here to download our application</a>.</li>\r\n	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.'),
(300, 30, '_message_key', 'post_updated') ;
INSERT INTO `wp_3_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(301, 30, '_user_id', '1'),
(302, 30, '_user_login', 'destroyer'),
(303, 30, '_user_email', 'garrettcullen@yahoo.com'),
(304, 30, '_server_remote_addr', '::1'),
(305, 30, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=8&action=edit'),
(306, 31, 'post_type', 'attachment'),
(307, 31, 'attachment_id', '25'),
(308, 31, 'attachment_title', 'StudioBarreFranchiseApplication'),
(309, 31, 'attachment_filename', 'StudioBarreFranchiseApplication.pdf'),
(310, 31, 'attachment_mime', 'application/pdf'),
(311, 31, 'attachment_filesize', '155592'),
(312, 31, '_message_key', 'attachment_created'),
(313, 31, '_user_id', '1'),
(314, 31, '_user_login', 'destroyer'),
(315, 31, '_user_email', 'garrettcullen@yahoo.com'),
(316, 31, '_server_remote_addr', '::1'),
(317, 31, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/media-new.php'),
(318, 32, 'post_id', '8'),
(319, 32, 'post_type', 'page'),
(320, 32, 'post_title', 'Next Steps'),
(321, 32, 'post_prev_post_content', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre.com/franchising/wp-content/uploads/sites/4/2014/05/StudioBarreFranchiseApplication.pdf" target="_blank">Click here to download our application</a>.</li>\r\n	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.'),
(322, 32, 'post_new_post_content', 'We would like to invite you to now learn more about our franchise opportunity.\r\nOur discovery process one of mutual education and evaluation designed to help you determine if the Studio Barre business model is right for YOU.\r\n\r\nDuring this process, we will give you the opportunity to get to know our business, team, franchisees and culture. Usually our discovery process takes 30-45 days and during this time, we also hope to get to know you, your partners, accomplishments and story in order to determine whether a Studio Barre franchise is right for you attain your goals.\r\n<h2>the Studio Barre discovery process</h2>\r\n<ol>\r\n 	<li><strong>Initial Inquiry:</strong> Complete the short form to the left and you will be contacted by a member of the Studio Barre Team. We will discuss an overview of the Studio Barre opportunity along with expectations from both parties for our discovery process. This overview will include initial understanding of the Studio Barre business model, industry and what makes us unique.</li>\r\n 	<li><strong>Complete Application:</strong> If you choose to proceed, we’ll ask you for a bit more information so we can get to know you. We’ll call to schedule a convenient time to discuss your background and objectives, explain more about training and support, and answer any additional questions. <a title="Application" href="http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf" target="_blank" rel="noopener">Click here to download our application</a>.</li>\r\n 	<li><strong>Disclosure:</strong> At this step in our discovery process, you\'ll be invited to speak with Lauren Gregory, Director of Operations, and receive our Franchise Disclosure Document (FDD). From here, we really dig into the details of the opportunity and continue the process to help you move forward with your due diligence.</li>\r\n 	<li><strong>Join the Team Day:</strong> When we get to this step and we’ve both determined that this looks like we are a good match, we’ll invite you to our corporate location in sunny La Costa, California! This day will be informative and exciting with a tour of the La Costa studio, meeting with Shannon Higgins and confirmation of everything discussed during our discovery process. At the conclusion of your visit, we’ll both make a decision about awarding you a franchise to join the Studio Barre team.</li>\r\n</ol>\r\nLet’s get started! Briefly tell us who you are on the form to the left and we look forward to speaking with you.'),
(323, 32, '_message_key', 'post_updated'),
(324, 32, '_user_id', '1'),
(325, 32, '_user_login', 'destroyer'),
(326, 32, '_user_email', 'garrettcullen@yahoo.com'),
(327, 32, '_server_remote_addr', '::1'),
(328, 32, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=8&action=edit'),
(329, 33, 'post_id', '27'),
(330, 33, 'post_type', 'acf-field-group'),
(331, 33, 'post_title', 'H1 Titles'),
(332, 33, '_message_key', 'post_created'),
(333, 33, '_user_id', '1'),
(334, 33, '_user_login', 'destroyer'),
(335, 33, '_user_email', 'garrettcullen@yahoo.com'),
(336, 33, '_server_remote_addr', '::1'),
(337, 33, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(338, 34, 'post_id', '28'),
(339, 34, 'post_type', 'acf-field'),
(340, 34, 'post_title', 'H1 Titles First Word'),
(341, 34, '_message_key', 'post_updated'),
(342, 34, '_user_id', '1'),
(343, 34, '_user_login', 'destroyer'),
(344, 34, '_user_email', 'garrettcullen@yahoo.com'),
(345, 34, '_server_remote_addr', '::1'),
(346, 34, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(347, 35, 'post_id', '29'),
(348, 35, 'post_type', 'acf-field'),
(349, 35, 'post_title', 'H1 Titles Word In Brackets'),
(350, 35, '_message_key', 'post_updated'),
(351, 35, '_user_id', '1'),
(352, 35, '_user_login', 'destroyer'),
(353, 35, '_user_email', 'garrettcullen@yahoo.com'),
(354, 35, '_server_remote_addr', '::1'),
(355, 35, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(356, 36, 'post_id', '27'),
(357, 36, 'post_type', 'acf-field-group'),
(358, 36, 'post_title', 'H1 Titles'),
(359, 36, 'post_prev_post_title', 'Auto Draft'),
(360, 36, 'post_new_post_title', 'H1 Titles'),
(361, 36, 'post_prev_post_name', ''),
(362, 36, 'post_new_post_name', 'group_59cc631d14e08'),
(363, 36, 'post_prev_post_content', ''),
(364, 36, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"page-franchising.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(365, 36, 'post_prev_post_status', 'auto-draft'),
(366, 36, 'post_new_post_status', 'publish'),
(367, 36, 'post_prev_post_date', '2017-09-28 02:49:00'),
(368, 36, 'post_new_post_date', '2017-09-28 02:50:12'),
(369, 36, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(370, 36, 'post_new_post_date_gmt', '2017-09-28 02:50:12'),
(371, 36, 'post_prev_post_excerpt', ''),
(372, 36, 'post_new_post_excerpt', 'h1-titles'),
(373, 36, '_message_key', 'post_updated'),
(374, 36, '_user_id', '1'),
(375, 36, '_user_login', 'destroyer'),
(376, 36, '_user_email', 'garrettcullen@yahoo.com'),
(377, 36, '_server_remote_addr', '::1'),
(378, 36, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(379, 37, 'post_id', '27'),
(380, 37, 'post_type', 'acf-field-group'),
(381, 37, 'post_title', 'H1 Titles'),
(382, 37, '_message_key', 'post_updated'),
(383, 37, '_user_id', '1'),
(384, 37, '_user_login', 'destroyer'),
(385, 37, '_user_email', 'garrettcullen@yahoo.com'),
(386, 37, '_server_remote_addr', '::1'),
(387, 37, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=27&action=edit'),
(388, 38, 'post_id', '27'),
(389, 38, 'post_type', 'acf-field-group'),
(390, 38, 'post_title', 'H1 Titles'),
(391, 38, '_message_key', 'post_updated'),
(392, 38, '_user_id', '1'),
(393, 38, '_user_login', 'destroyer'),
(394, 38, '_user_email', 'garrettcullen@yahoo.com'),
(395, 38, '_server_remote_addr', '::1'),
(396, 38, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=27&action=edit'),
(397, 39, 'post_id', '4'),
(398, 39, 'post_type', 'page'),
(399, 39, 'post_title', 'About Us'),
(400, 39, '_message_key', 'post_updated') ;
INSERT INTO `wp_3_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(401, 39, '_user_id', '1'),
(402, 39, '_user_login', 'destroyer'),
(403, 39, '_user_email', 'garrettcullen@yahoo.com'),
(404, 39, '_server_remote_addr', '::1'),
(405, 39, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=4&action=edit'),
(406, 40, 'post_id', '6'),
(407, 40, 'post_type', 'page'),
(408, 40, 'post_title', 'About You'),
(409, 40, '_message_key', 'post_updated'),
(410, 40, '_user_id', '1'),
(411, 40, '_user_login', 'destroyer'),
(412, 40, '_user_email', 'garrettcullen@yahoo.com'),
(413, 40, '_server_remote_addr', '::1'),
(414, 40, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=6&action=edit'),
(415, 41, 'post_id', '8'),
(416, 41, 'post_type', 'page'),
(417, 41, 'post_title', 'Next Steps'),
(418, 41, '_message_key', 'post_updated'),
(419, 41, '_user_id', '1'),
(420, 41, '_user_login', 'destroyer'),
(421, 41, '_user_email', 'garrettcullen@yahoo.com'),
(422, 41, '_server_remote_addr', '::1'),
(423, 41, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=8&action=edit'),
(424, 42, 'post_id', '33'),
(425, 42, 'post_type', 'acf-field-group'),
(426, 42, 'post_title', 'Back Buttons'),
(427, 42, '_message_key', 'post_created'),
(428, 42, '_user_id', '1'),
(429, 42, '_user_login', 'destroyer'),
(430, 42, '_user_email', 'garrettcullen@yahoo.com'),
(431, 42, '_server_remote_addr', '::1'),
(432, 42, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(433, 43, 'post_id', '34'),
(434, 43, 'post_type', 'acf-field'),
(435, 43, 'post_title', 'Back'),
(436, 43, '_message_key', 'post_updated'),
(437, 43, '_user_id', '1'),
(438, 43, '_user_login', 'destroyer'),
(439, 43, '_user_email', 'garrettcullen@yahoo.com'),
(440, 43, '_server_remote_addr', '::1'),
(441, 43, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(442, 44, 'post_id', '35'),
(443, 44, 'post_type', 'acf-field'),
(444, 44, 'post_title', 'Next'),
(445, 44, '_message_key', 'post_updated'),
(446, 44, '_user_id', '1'),
(447, 44, '_user_login', 'destroyer'),
(448, 44, '_user_email', 'garrettcullen@yahoo.com'),
(449, 44, '_server_remote_addr', '::1'),
(450, 44, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(451, 45, 'post_id', '33'),
(452, 45, 'post_type', 'acf-field-group'),
(453, 45, 'post_title', 'Back Buttons'),
(454, 45, 'post_prev_post_title', 'Auto Draft'),
(455, 45, 'post_new_post_title', 'Back Buttons'),
(456, 45, 'post_prev_post_name', ''),
(457, 45, 'post_new_post_name', 'group_59cc6495231b4'),
(458, 45, 'post_prev_post_content', ''),
(459, 45, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(460, 45, 'post_prev_post_status', 'auto-draft'),
(461, 45, 'post_new_post_status', 'publish'),
(462, 45, 'post_prev_menu_order', '0'),
(463, 45, 'post_new_menu_order', '1'),
(464, 45, 'post_prev_post_date', '2017-09-28 02:55:17'),
(465, 45, 'post_new_post_date', '2017-09-28 02:56:02'),
(466, 45, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(467, 45, 'post_new_post_date_gmt', '2017-09-28 02:56:02'),
(468, 45, 'post_prev_post_excerpt', ''),
(469, 45, 'post_new_post_excerpt', 'back-buttons'),
(470, 45, '_message_key', 'post_updated'),
(471, 45, '_user_id', '1'),
(472, 45, '_user_login', 'destroyer'),
(473, 45, '_user_email', 'garrettcullen@yahoo.com'),
(474, 45, '_server_remote_addr', '::1'),
(475, 45, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(476, 46, 'post_id', '33'),
(477, 46, 'post_type', 'acf-field-group'),
(478, 46, 'post_title', 'Back Buttons'),
(479, 46, '_message_key', 'post_updated'),
(480, 46, '_user_id', '1'),
(481, 46, '_user_login', 'destroyer'),
(482, 46, '_user_email', 'garrettcullen@yahoo.com'),
(483, 46, '_server_remote_addr', '::1'),
(484, 46, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=33&action=edit'),
(485, 47, 'post_id', '34'),
(486, 47, 'post_type', 'acf-field'),
(487, 47, 'post_title', 'Back'),
(488, 47, '_message_key', 'post_updated'),
(489, 47, '_user_id', '1'),
(490, 47, '_user_login', 'destroyer'),
(491, 47, '_user_email', 'garrettcullen@yahoo.com'),
(492, 47, '_server_remote_addr', '::1'),
(493, 47, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=33&action=edit'),
(494, 48, 'post_id', '35'),
(495, 48, 'post_type', 'acf-field'),
(496, 48, 'post_title', 'Next'),
(497, 48, '_message_key', 'post_updated'),
(498, 48, '_user_id', '1'),
(499, 48, '_user_login', 'destroyer'),
(500, 48, '_user_email', 'garrettcullen@yahoo.com') ;
INSERT INTO `wp_3_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(501, 48, '_server_remote_addr', '::1'),
(502, 48, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=33&action=edit'),
(503, 49, 'post_id', '33'),
(504, 49, 'post_type', 'acf-field-group'),
(505, 49, 'post_title', 'Back Buttons'),
(506, 49, '_message_key', 'post_updated'),
(507, 49, '_user_id', '1'),
(508, 49, '_user_login', 'destroyer'),
(509, 49, '_user_email', 'garrettcullen@yahoo.com'),
(510, 49, '_server_remote_addr', '::1'),
(511, 49, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=33&action=edit'),
(512, 50, 'post_id', '33'),
(513, 50, 'post_type', 'acf-field-group'),
(514, 50, 'post_title', 'Back Buttons'),
(515, 50, '_message_key', 'post_updated'),
(516, 50, '_user_id', '1'),
(517, 50, '_user_login', 'destroyer'),
(518, 50, '_user_email', 'garrettcullen@yahoo.com'),
(519, 50, '_server_remote_addr', '::1'),
(520, 50, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=33&action=edit'),
(521, 51, 'post_id', '33'),
(522, 51, 'post_type', 'acf-field-group'),
(523, 51, 'post_title', 'Back Buttons'),
(524, 51, 'post_prev_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(525, 51, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"page-franchising.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}'),
(526, 51, '_message_key', 'post_updated'),
(527, 51, '_user_id', '1'),
(528, 51, '_user_login', 'destroyer'),
(529, 51, '_user_email', 'garrettcullen@yahoo.com'),
(530, 51, '_server_remote_addr', '::1'),
(531, 51, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=33&action=edit'),
(532, 52, 'post_id', '4'),
(533, 52, 'post_type', 'page'),
(534, 52, 'post_title', 'About Us'),
(535, 52, '_message_key', 'post_updated'),
(536, 52, '_user_id', '1'),
(537, 52, '_user_login', 'destroyer'),
(538, 52, '_user_email', 'garrettcullen@yahoo.com'),
(539, 52, '_server_remote_addr', '::1'),
(540, 52, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=4&action=edit'),
(541, 53, 'post_id', '6'),
(542, 53, 'post_type', 'page'),
(543, 53, 'post_title', 'About You'),
(544, 53, '_message_key', 'post_updated'),
(545, 53, '_user_id', '1'),
(546, 53, '_user_login', 'destroyer'),
(547, 53, '_user_email', 'garrettcullen@yahoo.com'),
(548, 53, '_server_remote_addr', '::1'),
(549, 53, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=6&action=edit'),
(550, 54, 'post_id', '8'),
(551, 54, 'post_type', 'page'),
(552, 54, 'post_title', 'Next Steps'),
(553, 54, '_message_key', 'post_updated'),
(554, 54, '_user_id', '1'),
(555, 54, '_user_login', 'destroyer'),
(556, 54, '_user_email', 'garrettcullen@yahoo.com'),
(557, 54, '_server_remote_addr', '::1'),
(558, 54, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=8&action=edit'),
(559, 55, 'post_id', '6'),
(560, 55, 'post_type', 'page'),
(561, 55, 'post_title', 'About You'),
(562, 55, '_message_key', 'post_updated'),
(563, 55, '_user_id', '1'),
(564, 55, '_user_login', 'destroyer'),
(565, 55, '_user_email', 'garrettcullen@yahoo.com'),
(566, 55, '_server_remote_addr', '::1'),
(567, 55, '_server_http_referer', 'http://studiobarre-demo.com/franchising/wp-admin/post.php?post=6&action=edit') ;

#
# End of data contents of table `wp_3_simple_history_contexts`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_term_relationships`
#

DROP TABLE IF EXISTS `wp_3_term_relationships`;


#
# Table structure of table `wp_3_term_relationships`
#

CREATE TABLE `wp_3_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_term_relationships`
#
INSERT INTO `wp_3_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(11, 2, 0),
(13, 2, 0),
(14, 2, 0),
(15, 2, 0),
(16, 2, 0),
(17, 2, 0) ;

#
# End of data contents of table `wp_3_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_3_term_taxonomy`;


#
# Table structure of table `wp_3_term_taxonomy`
#

CREATE TABLE `wp_3_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_term_taxonomy`
#
INSERT INTO `wp_3_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 6) ;

#
# End of data contents of table `wp_3_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_termmeta`
#

DROP TABLE IF EXISTS `wp_3_termmeta`;


#
# Table structure of table `wp_3_termmeta`
#

CREATE TABLE `wp_3_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_termmeta`
#

#
# End of data contents of table `wp_3_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_terms`
#

DROP TABLE IF EXISTS `wp_3_terms`;


#
# Table structure of table `wp_3_terms`
#

CREATE TABLE `wp_3_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_terms`
#
INSERT INTO `wp_3_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Nav', 'top-nav', 0) ;

#
# End of data contents of table `wp_3_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_3_yoast_seo_links`;


#
# Table structure of table `wp_3_yoast_seo_links`
#

CREATE TABLE `wp_3_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_yoast_seo_links`
#
INSERT INTO `wp_3_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(7, 'http://studiobarre-demo.com/franchising/wp-content/uploads/sites/3/2017/09/StudioBarreFranchiseApplication.pdf', 8, 0, 'internal'),
(8, 'mailto:franchising@studiobarre.com', 6, 0, 'external') ;

#
# End of data contents of table `wp_3_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_3_yoast_seo_meta`
#

DROP TABLE IF EXISTS `wp_3_yoast_seo_meta`;


#
# Table structure of table `wp_3_yoast_seo_meta`
#

CREATE TABLE `wp_3_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_3_yoast_seo_meta`
#
INSERT INTO `wp_3_yoast_seo_meta` ( `object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(4, 0, NULL),
(6, 0, NULL),
(8, 1, NULL),
(18, 0, NULL) ;

#
# End of data contents of table `wp_3_yoast_seo_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_blog_versions`
#

DROP TABLE IF EXISTS `wp_blog_versions`;


#
# Table structure of table `wp_blog_versions`
#

CREATE TABLE `wp_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_blog_versions`
#

#
# End of data contents of table `wp_blog_versions`
# --------------------------------------------------------



#
# Delete any existing table `wp_blogs`
#

DROP TABLE IF EXISTS `wp_blogs`;


#
# Table structure of table `wp_blogs`
#

CREATE TABLE `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_blogs`
#
INSERT INTO `wp_blogs` ( `blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES
(1, 1, 'studiobarre-demo.com', '/', '2017-07-23 22:58:16', '2017-10-01 05:05:00', 1, 0, 0, 0, 0, 0),
(2, 1, 'studiobarre-demo.com', '/carmel-valley/', '2017-09-20 03:33:55', '2017-09-26 05:17:21', 1, 0, 0, 0, 0, 0),
(3, 1, 'studiobarre-demo.com', '/franchising/', '2017-09-26 03:12:18', '2017-09-28 03:00:04', 1, 0, 0, 0, 0, 0) ;

#
# End of data contents of table `wp_blogs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_hc_hmw_short_code`
#

DROP TABLE IF EXISTS `wp_hc_hmw_short_code`;


#
# Table structure of table `wp_hc_hmw_short_code`
#

CREATE TABLE `wp_hc_hmw_short_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `short_code` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_hc_hmw_short_code`
#

#
# End of data contents of table `wp_hc_hmw_short_code`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_lockouts`
#

DROP TABLE IF EXISTS `wp_itsec_lockouts`;


#
# Table structure of table `wp_itsec_lockouts`
#

CREATE TABLE `wp_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_lockouts`
#

#
# End of data contents of table `wp_itsec_lockouts`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_log`
#

DROP TABLE IF EXISTS `wp_itsec_log`;


#
# Table structure of table `wp_itsec_log`
#

CREATE TABLE `wp_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `log_function` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '1000-01-01 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '1000-01-01 00:00:00',
  `log_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_referrer` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_log`
#

#
# End of data contents of table `wp_itsec_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_temp`
#

DROP TABLE IF EXISTS `wp_itsec_temp`;


#
# Table structure of table `wp_itsec_temp`
#

CREATE TABLE `wp_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_temp`
#

#
# End of data contents of table `wp_itsec_temp`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=532 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://studiobarre-demo.com', 'yes'),
(2, 'home', 'http://studiobarre-demo.com', 'yes'),
(3, 'blogname', 'Studio Barre', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrettcullen@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/blog/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'studiobarrecorporate', 'yes'),
(41, 'stylesheet', 'studiobarrecorporate', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:2:{s:47:"healcode-mindbody-widget/healcode-mb-widget.php";s:24:"hc_hmw_network_uninstall";s:41:"better-wp-security/better-wp-security.php";a:2:{i:0;s:10:"ITSEC_Core";i:1;s:16:"handle_uninstall";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '18', 'yes'),
(84, 'page_on_front', '5', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:9:{i:1506836450;a:1:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506836482;a:1:{s:29:"simple_history/maybe_purge_db";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506836682;a:2:{s:16:"itsec_purge_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:17:"itsec_clear_locks";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506852666;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1506855521;a:1:{s:21:"update_network_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1506895868;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506900670;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1506918275;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(124, 'can_compress_scripts', '1', 'no'),
(133, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1500847950;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(134, 'current_theme', 'Studio Barre Corporate', 'yes'),
(135, 'theme_mods_starter', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1500850589;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(138, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(139, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(140, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(143, 'recently_activated', 'a:0:{}', 'yes'),
(152, 'theme_mods_studiobarrecorporate', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:9:"main_menu";i:2;}}', 'yes'),
(154, 'post_count', '3', 'yes'),
(158, 'WPLANG', '', 'yes'),
(159, 'new_admin_email', 'garrettcullen@yahoo.com', 'yes'),
(162, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(163, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(164, 'rg_form_version', '2.2.5', 'yes'),
(167, 'rg_gforms_key', '06531379cf8e19681c4045b7a998bf23', 'yes'),
(168, 'rg_gforms_disable_css', '1', 'yes'),
(169, 'rg_gforms_enable_html5', '0', 'yes'),
(170, 'gform_enable_noconflict', '0', 'yes'),
(171, 'rg_gforms_enable_akismet', '', 'yes'),
(172, 'rg_gforms_captcha_public_key', '', 'yes'),
(173, 'rg_gforms_captcha_private_key', '', 'yes'),
(174, 'rg_gforms_currency', 'USD', 'yes'),
(175, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(176, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(177, 'gf_is_upgrading', '0', 'yes'),
(178, 'gf_previous_db_version', '2.2.4.1', 'yes'),
(179, 'gf_db_version', '2.2.5', 'yes'),
(183, 'category_children', 'a:0:{}', 'yes'),
(226, 'acf_version', '5.6.2', 'yes'),
(227, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNeU9ETjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEEzSURJeE9qSTRPak0yIjtzOjM6InVybCI7czoyNzoiaHR0cDovL3N0dWRpb2JhcnJlLWRlbW8uY29tIjt9', 'yes'),
(228, 'hookturn_acftcp_license_key', '631dfe9835ead92c781c66a4654e1c79', 'yes'),
(231, '2057dd01900c5459c5051c796e8d92e2', 'a:2:{s:7:"timeout";i:1506587516;s:5:"value";s:6696:"{"new_version":"2.1.0","stable_version":"2.1.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2017-09-01 06:12:45","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUwNjY5OTExNDo2MzFkZmU5ODM1ZWFkOTJjNzgxYzY2YTQ2NTRlMWM3OToxNTowNmJjZjE5MzNlZTEyNDA4YTUxNDNkYTFmNzU4ZTcxOTpodHRwQC8vc3R1ZGlvYmFycmUtZGVtby5jb206MA==","download_link":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUwNjY5OTExNDo2MzFkZmU5ODM1ZWFkOTJjNzgxYzY2YTQ2NTRlMWM3OToxNTowNmJjZjE5MzNlZTEyNDA4YTUxNDNkYTFmNzU4ZTcxOTpodHRwQC8vc3R1ZGlvYmFycmUtZGVtby5jb206MA==","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.8 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.1.0\\u00a0released in July 2017<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(233, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(329, 'options_custom_menu', '1', 'no'),
(330, '_options_custom_menu', 'field_59c86cb18f09b', 'no'),
(331, 'options_custom_menu_0_menu_item', '80', 'no'),
(332, '_options_custom_menu_0_menu_item', 'field_59c86ed6662eb', 'no'),
(333, 'options_custom_menu_0_page_title', 'hello', 'no'),
(334, '_options_custom_menu_0_page_title', 'field_59c872242f109', 'no'),
(336, 'hc_hmw_limit', '20', 'yes'),
(337, 'widget_hc_insert_html_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(338, 'wpseo', 'a:25:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:1;s:7:"version";s:5:"5.4.2";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1506318050;}', 'yes'),
(339, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(340, 'wpseo_titles', 'a:53:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(341, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"2a12d86bc02983021c2c1d21bdcc4b5d";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(342, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(343, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(344, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(346, 'simple_history_db_version', '5', 'yes'),
(347, 'simple_history_show_as_page', '1', 'yes'),
(348, 'simple_history_show_on_dashboard', '1', 'yes'),
(349, 'simple_history_enable_rss_feed', '0', 'yes'),
(350, 'simple_history_rss_secret', 'msbfzrsjifngmumkddhm', 'yes'),
(353, 'simplehistory_AvailableUpdatesLogger_wp_core_version_available', '4.8.2', 'yes'),
(354, 'simplehistory_AvailableUpdatesLogger_plugin_updates_available', 'a:6:{s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";a:1:{s:15:"checked_version";s:3:"1.8";}s:29:"gravityforms/gravityforms.php";a:1:{s:15:"checked_version";s:5:"2.2.5";}s:34:"advanced-custom-fields-pro/acf.php";a:1:{s:15:"checked_version";s:5:"5.6.2";}s:41:"acf-theme-code-pro/acf_theme_code_pro.php";a:1:{s:15:"checked_version";s:5:"2.1.0";}s:19:"akismet/akismet.php";a:1:{s:15:"checked_version";s:3:"4.0";}s:24:"wordpress-seo/wp-seo.php";a:1:{s:15:"checked_version";s:5:"5.5.1";}}', 'yes'),
(355, 'widget_mla-text-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(356, 'mla_custom_field_mapping', 'a:0:{}', 'yes'),
(357, 'mla_iptc_exif_mapping', 'a:3:{s:8:"standard";a:5:{s:10:"post_title";a:5:{s:4:"name";s:5:"Title";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"post_name";a:5:{s:4:"name";s:9:"Name/Slug";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"image_alt";a:5:{s:4:"name";s:8:"ALT Text";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_excerpt";a:5:{s:4:"name";s:7:"Caption";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_content";a:5:{s:4:"name";s:11:"Description";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}}s:8:"taxonomy";a:0:{}s:6:"custom";a:0:{}}', 'yes'),
(358, 'mla_upload_mimes', 'a:4:{s:6:"custom";a:0:{}s:8:"disabled";a:53:{s:3:"aac";b:1;s:3:"ac3";b:1;s:2:"ai";b:1;s:3:"aif";b:1;s:4:"aifc";b:1;s:4:"aiff";b:1;s:2:"au";b:1;s:3:"bin";b:1;s:3:"cat";b:1;s:3:"cdf";b:1;s:3:"cgm";b:1;s:3:"clp";b:1;s:3:"crd";b:1;s:3:"dat";b:1;s:3:"dll";b:1;s:3:"dot";b:1;s:3:"dtd";b:1;s:3:"eps";b:1;s:4:"gtar";b:1;s:3:"ief";b:1;s:3:"ifb";b:1;s:3:"m13";b:1;s:3:"m14";b:1;s:3:"mml";b:1;s:3:"mny";b:1;s:5:"movie";b:1;s:3:"mp2";b:1;s:3:"mpa";b:1;s:3:"msg";b:1;s:3:"mvb";b:1;s:3:"otf";b:1;s:3:"pic";b:1;s:4:"pict";b:1;s:2:"ps";b:1;s:3:"pub";b:1;s:3:"rgb";b:1;s:3:"scd";b:1;s:3:"snd";b:1;s:3:"sql";b:1;s:3:"sst";b:1;s:3:"stl";b:1;s:3:"svg";b:1;s:3:"trm";b:1;s:3:"ttf";b:1;s:3:"w6w";b:1;s:3:"wmf";b:1;s:4:"woff";b:1;s:4:"word";b:1;s:3:"xlc";b:1;s:3:"xlm";b:1;s:3:"xml";b:1;s:3:"xsl";b:1;s:4:"xslt";b:1;}s:11:"description";a:0:{}s:9:"icon_type";a:82:{s:2:"ai";s:10:"postscript";s:4:"aifc";s:5:"audio";s:3:"asx";s:5:"video";s:2:"au";s:5:"audio";s:3:"bin";s:6:"binary";s:1:"c";s:8:"source_c";s:2:"cc";s:10:"source_cpp";s:3:"cgm";s:5:"image";s:5:"class";s:11:"source_java";s:3:"clp";s:6:"knotes";s:3:"crd";s:6:"knotes";s:3:"css";s:10:"stylesheet";s:3:"dat";s:6:"binary";s:3:"dll";s:8:"exe_wine";s:3:"dot";s:8:"document";s:4:"dotx";s:8:"document";s:3:"dtd";s:4:"code";s:3:"eps";s:10:"postscript";s:3:"exe";s:8:"exe_wine";s:4:"gtar";s:7:"archive";s:4:"gzip";s:7:"archive";s:1:"h";s:8:"source_h";s:3:"ics";s:8:"calendar";s:3:"ief";s:5:"image";s:3:"ifb";s:8:"calendar";s:2:"js";s:11:"source_java";s:3:"mdb";s:8:"database";s:3:"mid";s:5:"audio";s:4:"midi";s:5:"audio";s:3:"mml";s:8:"kformula";s:5:"movie";s:5:"video";s:3:"mpa";s:5:"audio";s:3:"mpe";s:5:"video";s:3:"msg";s:7:"message";s:3:"odb";s:8:"database";s:3:"odc";s:3:"log";s:3:"odf";s:8:"kformula";s:3:"odg";s:2:"3d";s:6:"onepkg";s:6:"knotes";s:6:"onetmp";s:6:"knotes";s:6:"onetoc";s:6:"knotes";s:7:"onetoc2";s:6:"knotes";s:3:"otf";s:4:"font";s:3:"pdf";s:3:"pdf";s:3:"pic";s:5:"image";s:4:"pict";s:5:"image";s:3:"pot";s:11:"interactive";s:4:"potm";s:11:"interactive";s:4:"potx";s:11:"interactive";s:4:"ppam";s:11:"interactive";s:2:"ps";s:10:"postscript";s:3:"psd";s:5:"image";s:3:"pub";s:8:"document";s:2:"qt";s:9:"quicktime";s:2:"ra";s:5:"audio";s:3:"rgb";s:5:"image";s:3:"rtx";s:4:"text";s:3:"snd";s:5:"audio";s:3:"sql";s:8:"database";s:3:"svg";s:9:"vectorgfx";s:3:"trm";s:11:"interactive";s:3:"ttf";s:13:"font_truetype";s:3:"w6w";s:8:"document";s:3:"wax";s:5:"audio";s:4:"webm";s:5:"video";s:2:"wm";s:5:"video";s:3:"wmf";s:9:"vectorgfx";s:3:"wmx";s:5:"video";s:4:"woff";s:4:"font";s:4:"word";s:8:"document";s:3:"wri";s:8:"document";s:3:"xla";s:11:"spreadsheet";s:4:"xlam";s:11:"spreadsheet";s:3:"xlc";s:11:"spreadsheet";s:3:"xlm";s:11:"spreadsheet";s:3:"xlt";s:11:"spreadsheet";s:4:"xltm";s:11:"spreadsheet";s:4:"xltx";s:11:"spreadsheet";s:3:"xlw";s:11:"spreadsheet";s:3:"xml";s:4:"code";s:3:"xsl";s:5:"style";s:4:"xslt";s:4:"code";}}', 'yes'),
(359, 'mla_current_version', '2.60', 'yes'),
(361, 'mucd_duplicable', 'no', 'yes'),
(368, 'rewrite_rules', 'a:103:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:52:"blog/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:47:"blog/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:28:"blog/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:40:"blog/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:22:"blog/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:49:"blog/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:44:"blog/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:25:"blog/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:37:"blog/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:19:"blog/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:50:"blog/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:45:"blog/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:26:"blog/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:38:"blog/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:20:"blog/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:65:"blog/attachment_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:60:"blog/attachment_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:41:"blog/attachment_category/([^/]+)/embed/?$";s:52:"index.php?attachment_category=$matches[1]&embed=true";s:53:"blog/attachment_category/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?attachment_category=$matches[1]&paged=$matches[2]";s:35:"blog/attachment_category/([^/]+)/?$";s:41:"index.php?attachment_category=$matches[1]";s:60:"blog/attachment_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:55:"blog/attachment_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:36:"blog/attachment_tag/([^/]+)/embed/?$";s:47:"index.php?attachment_tag=$matches[1]&embed=true";s:48:"blog/attachment_tag/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?attachment_tag=$matches[1]&paged=$matches[2]";s:30:"blog/attachment_tag/([^/]+)/?$";s:36:"index.php?attachment_tag=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:16:".*wp-signup.php$";s:21:"index.php?signup=true";s:18:".*wp-activate.php$";s:23:"index.php?activate=true";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:52:"blog/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:47:"blog/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:28:"blog/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:40:"blog/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:22:"blog/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:74:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:44:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"blog/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"blog/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"blog/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"blog/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:31:"blog/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:48:"blog/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:43:"blog/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:24:"blog/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:36:"blog/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:18:"blog/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:32:"blog/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"blog/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"blog/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blog/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blog/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"blog/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"blog/([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:25:"blog/([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:45:"blog/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:40:"blog/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:33:"blog/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:40:"blog/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:29:"blog/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:21:"blog/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"blog/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"blog/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"blog/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"blog/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"blog/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(398, 'wpseo_sitemap_1_cache_validator', '2kDgv', 'no'),
(399, 'wpseo_sitemap_51_cache_validator', '2mokJ', 'no'),
(400, 'mla_post_mime_types', 'a:0:{}', 'yes'),
(427, 'wpseo_sitemap_post_cache_validator', 'PITW', 'no'),
(465, 'wpseo_sitemap_page_cache_validator', '2kDgy', 'no'),
(506, 'wpseo_sitemap_46_cache_validator', 'uUoe', 'no'),
(526, 'wpseo_sitemap_115_cache_validator', '2epxk', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1395 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7, 5, '_edit_lock', '1506833287:1'),
(8, 5, '_edit_last', '1'),
(9, 5, '_wp_page_template', 'page-home.php'),
(13, 8, '_edit_last', '1'),
(14, 8, '_wp_page_template', 'page-locations.php'),
(15, 8, '_edit_lock', '1506570051:1'),
(16, 10, '_edit_last', '1'),
(17, 10, '_wp_page_template', 'default'),
(18, 10, '_edit_lock', '1500858553:1'),
(19, 13, '_edit_lock', '1505792784:1'),
(20, 13, '_edit_last', '1'),
(21, 13, '_wp_page_template', 'page-faqs.php'),
(22, 16, '_edit_last', '1'),
(23, 16, '_wp_page_template', 'page-press.php'),
(24, 16, '_edit_lock', '1505799285:1'),
(25, 18, '_edit_last', '1'),
(26, 18, '_wp_page_template', 'default'),
(27, 18, '_edit_lock', '1505792381:1'),
(28, 20, '_edit_lock', '1503377743:1'),
(29, 20, '_edit_last', '1'),
(30, 20, '_wp_page_template', 'page-contact.php'),
(112, 31, '_menu_item_type', 'post_type'),
(113, 31, '_menu_item_menu_item_parent', '0'),
(114, 31, '_menu_item_object_id', '20'),
(115, 31, '_menu_item_object', 'page'),
(116, 31, '_menu_item_target', ''),
(117, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(118, 31, '_menu_item_xfn', ''),
(119, 31, '_menu_item_url', ''),
(121, 32, '_menu_item_type', 'post_type'),
(122, 32, '_menu_item_menu_item_parent', '0'),
(123, 32, '_menu_item_object_id', '18'),
(124, 32, '_menu_item_object', 'page'),
(125, 32, '_menu_item_target', ''),
(126, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(127, 32, '_menu_item_xfn', ''),
(128, 32, '_menu_item_url', ''),
(130, 33, '_menu_item_type', 'post_type'),
(131, 33, '_menu_item_menu_item_parent', '0'),
(132, 33, '_menu_item_object_id', '16'),
(133, 33, '_menu_item_object', 'page'),
(134, 33, '_menu_item_target', ''),
(135, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(136, 33, '_menu_item_xfn', ''),
(137, 33, '_menu_item_url', ''),
(139, 34, '_menu_item_type', 'post_type'),
(140, 34, '_menu_item_menu_item_parent', '0'),
(141, 34, '_menu_item_object_id', '13'),
(142, 34, '_menu_item_object', 'page'),
(143, 34, '_menu_item_target', ''),
(144, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(145, 34, '_menu_item_xfn', ''),
(146, 34, '_menu_item_url', ''),
(166, 37, '_menu_item_type', 'custom'),
(167, 37, '_menu_item_menu_item_parent', '0'),
(168, 37, '_menu_item_object_id', '37'),
(169, 37, '_menu_item_object', 'custom'),
(170, 37, '_menu_item_target', ''),
(171, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(172, 37, '_menu_item_xfn', ''),
(173, 37, '_menu_item_url', '//studiobarre-demo.com/franchising'),
(175, 38, '_edit_last', '1'),
(176, 38, '_wp_page_template', 'page-about.php'),
(177, 38, '_edit_lock', '1506834036:1'),
(178, 40, '_edit_last', '1'),
(179, 40, '_wp_page_template', 'page-caseresults.php'),
(180, 40, '_edit_lock', '1503374345:1'),
(181, 42, '_edit_lock', '1506834139:1'),
(182, 42, '_edit_last', '1'),
(183, 42, '_wp_page_template', 'page-society.php'),
(184, 44, '_menu_item_type', 'post_type'),
(185, 44, '_menu_item_menu_item_parent', '48'),
(186, 44, '_menu_item_object_id', '42'),
(187, 44, '_menu_item_object', 'page'),
(188, 44, '_menu_item_target', ''),
(189, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(190, 44, '_menu_item_xfn', ''),
(191, 44, '_menu_item_url', ''),
(193, 45, '_menu_item_type', 'post_type'),
(194, 45, '_menu_item_menu_item_parent', '48'),
(195, 45, '_menu_item_object_id', '40'),
(196, 45, '_menu_item_object', 'page'),
(197, 45, '_menu_item_target', ''),
(198, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(199, 45, '_menu_item_xfn', ''),
(200, 45, '_menu_item_url', ''),
(210, 48, '_menu_item_type', 'custom'),
(211, 48, '_menu_item_menu_item_parent', '0'),
(212, 48, '_menu_item_object_id', '48'),
(213, 48, '_menu_item_object', 'custom'),
(214, 48, '_menu_item_target', ''),
(215, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(216, 48, '_menu_item_xfn', ''),
(217, 48, '_menu_item_url', ''),
(219, 49, '_menu_item_type', 'custom'),
(220, 49, '_menu_item_menu_item_parent', '0'),
(221, 49, '_menu_item_object_id', '49'),
(222, 49, '_menu_item_object', 'custom'),
(223, 49, '_menu_item_target', ''),
(224, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(225, 49, '_menu_item_xfn', ''),
(226, 49, '_menu_item_url', ''),
(228, 50, '_menu_item_type', 'custom'),
(229, 50, '_menu_item_menu_item_parent', '49'),
(230, 50, '_menu_item_object_id', '50'),
(231, 50, '_menu_item_object', 'custom'),
(232, 50, '_menu_item_target', ''),
(233, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(234, 50, '_menu_item_xfn', ''),
(235, 50, '_menu_item_url', '//studiobarre-demo.com/carmel-valley'),
(246, 52, '_menu_item_type', 'post_type'),
(247, 52, '_menu_item_menu_item_parent', '49'),
(248, 52, '_menu_item_object_id', '8'),
(249, 52, '_menu_item_object', 'page'),
(250, 52, '_menu_item_target', ''),
(251, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(252, 52, '_menu_item_xfn', ''),
(253, 52, '_menu_item_url', ''),
(254, 56, '_edit_lock', '1505792541:1'),
(255, 56, '_edit_last', '1'),
(258, 58, '_edit_lock', '1503462478:1'),
(259, 58, '_edit_last', '1'),
(262, 60, '_edit_lock', '1505791837:1'),
(263, 60, '_edit_last', '1'),
(286, 77, '_edit_last', '1'),
(287, 77, '_wp_page_template', 'default'),
(288, 77, '_edit_lock', '1505794501:1'),
(289, 77, '_wp_trash_meta_status', 'publish'),
(290, 77, '_wp_trash_meta_time', '1505794645'),
(291, 77, '_wp_desired_post_slug', 'test'),
(292, 80, '_edit_lock', '1506834098:1'),
(293, 80, '_edit_last', '1'),
(294, 80, '_wp_page_template', 'page-maven.php'),
(295, 82, '_menu_item_type', 'post_type'),
(296, 82, '_menu_item_menu_item_parent', '48'),
(297, 82, '_menu_item_object_id', '80'),
(298, 82, '_menu_item_object', 'page'),
(299, 82, '_menu_item_target', ''),
(300, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(301, 82, '_menu_item_xfn', ''),
(302, 82, '_menu_item_url', ''),
(303, 85, '_edit_lock', '1506834160:1'),
(304, 85, '_edit_last', '1'),
(305, 85, '_wp_page_template', 'page-mentor.php'),
(306, 88, '_menu_item_type', 'post_type'),
(307, 88, '_menu_item_menu_item_parent', '48'),
(308, 88, '_menu_item_object_id', '85'),
(309, 88, '_menu_item_object', 'page'),
(310, 88, '_menu_item_target', ''),
(311, 88, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(312, 88, '_menu_item_xfn', ''),
(313, 88, '_menu_item_url', ''),
(315, 89, '_edit_last', '1'),
(316, 89, '_wp_page_template', 'page-owner-resources.php'),
(317, 89, '_edit_lock', '1506206744:1'),
(318, 92, '_edit_lock', '1506286960:1'),
(319, 92, '_edit_last', '1'),
(320, 92, '_wp_page_template', 'page-owner-resources.php'),
(321, 94, '_edit_last', '1'),
(322, 94, '_wp_page_template', 'default'),
(323, 94, '_edit_lock', '1506295176:1'),
(324, 8, '_yoast_wpseo_content_score', '30'),
(325, 97, '_edit_lock', '1506833758:1'),
(326, 97, '_edit_last', '1'),
(327, 104, '_wp_attached_file', '2017/07/m1.jpg'),
(328, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:14:"2017/07/m1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"m1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"m1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(329, 105, '_wp_attached_file', '2017/07/m2.jpg'),
(330, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:14:"2017/07/m2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"m2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"m2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(331, 106, '_wp_attached_file', '2017/07/m3.jpg'),
(332, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:14:"2017/07/m3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"m3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"m3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(333, 107, '_wp_attached_file', '2017/07/m4.jpg'),
(334, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:14:"2017/07/m4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"m4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"m4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(335, 108, '_wp_attached_file', '2017/07/m5.jpg'),
(336, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:400;s:4:"file";s:14:"2017/07/m5.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"m5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:14:"m5-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(337, 109, '_wp_attached_file', '2017/07/slide-clientresults.jpg'),
(338, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:663;s:4:"file";s:31:"2017/07/slide-clientresults.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"slide-clientresults-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"slide-clientresults-300x166.jpg";s:5:"width";i:300;s:6:"height";i:166;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"slide-clientresults-768x424.jpg";s:5:"width";i:768;s:6:"height";i:424;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"slide-clientresults-1024x566.jpg";s:5:"width";i:1024;s:6:"height";i:566;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(339, 110, '_wp_attached_file', '2017/07/slide-findclass.jpg'),
(340, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:663;s:4:"file";s:27:"2017/07/slide-findclass.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"slide-findclass-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"slide-findclass-300x166.jpg";s:5:"width";i:300;s:6:"height";i:166;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"slide-findclass-768x424.jpg";s:5:"width";i:768;s:6:"height";i:424;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"slide-findclass-1024x566.jpg";s:5:"width";i:1024;s:6:"height";i:566;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(341, 111, '_wp_attached_file', '2017/07/slide-ourstory.jpg'),
(342, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:663;s:4:"file";s:26:"2017/07/slide-ourstory.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"slide-ourstory-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"slide-ourstory-300x166.jpg";s:5:"width";i:300;s:6:"height";i:166;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"slide-ourstory-768x424.jpg";s:5:"width";i:768;s:6:"height";i:424;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"slide-ourstory-1024x566.jpg";s:5:"width";i:1024;s:6:"height";i:566;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(343, 112, '_wp_attached_file', '2017/07/slide-society.jpg'),
(344, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:663;s:4:"file";s:25:"2017/07/slide-society.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"slide-society-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"slide-society-300x166.jpg";s:5:"width";i:300;s:6:"height";i:166;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"slide-society-768x424.jpg";s:5:"width";i:768;s:6:"height";i:424;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"slide-society-1024x566.jpg";s:5:"width";i:1024;s:6:"height";i:566;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(345, 113, '_wp_attached_file', '2017/07/slide-video.jpg'),
(346, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:663;s:4:"file";s:23:"2017/07/slide-video.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"slide-video-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"slide-video-300x166.jpg";s:5:"width";i:300;s:6:"height";i:166;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"slide-video-768x424.jpg";s:5:"width";i:768;s:6:"height";i:424;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"slide-video-1024x566.jpg";s:5:"width";i:1024;s:6:"height";i:566;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(347, 5, '_yoast_wpseo_content_score', '30'),
(348, 5, 'slideshow_0_video_or_linked_slide', 'Video'),
(349, 5, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(350, 5, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(351, 5, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(352, 5, 'slideshow_0_slide', '113'),
(353, 5, '_slideshow_0_slide', 'field_59d0452f16af9'),
(354, 5, 'slideshow_0_mobile_slide', '104'),
(355, 5, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(356, 5, 'slideshow', '5'),
(357, 5, '_slideshow', 'field_59d0452416af8'),
(358, 114, 'slideshow_0_video_or_linked_slide', 'Video'),
(359, 114, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(360, 114, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(361, 114, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(362, 114, 'slideshow_0_slide', '113') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(363, 114, '_slideshow_0_slide', 'field_59d0452f16af9'),
(364, 114, 'slideshow_0_mobile_slide', '104'),
(365, 114, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(366, 114, 'slideshow', '1'),
(367, 114, '_slideshow', 'field_59d0452416af8'),
(380, 5, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(381, 5, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(382, 5, 'slideshow_1_page_link', '38'),
(383, 5, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(384, 5, 'slideshow_1_slide', '111'),
(385, 5, '_slideshow_1_slide', 'field_59d0452f16af9'),
(386, 5, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(387, 5, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(388, 5, 'slideshow_2_page_link', '40'),
(389, 5, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(390, 5, 'slideshow_2_slide', '109'),
(391, 5, '_slideshow_2_slide', 'field_59d0452f16af9'),
(392, 5, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(393, 5, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(394, 5, 'slideshow_3_page_link', '42'),
(395, 5, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(396, 5, 'slideshow_3_slide', '112'),
(397, 5, '_slideshow_3_slide', 'field_59d0452f16af9'),
(398, 5, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(399, 5, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(400, 5, 'slideshow_4_page_link', '8'),
(401, 5, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(402, 5, 'slideshow_4_slide', '110'),
(403, 5, '_slideshow_4_slide', 'field_59d0452f16af9'),
(404, 116, 'slideshow_0_video_or_linked_slide', 'Video'),
(405, 116, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(406, 116, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(407, 116, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(408, 116, 'slideshow_0_slide', '113'),
(409, 116, '_slideshow_0_slide', 'field_59d0452f16af9'),
(410, 116, 'slideshow_0_mobile_slide', '104'),
(411, 116, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(412, 116, 'slideshow', '5'),
(413, 116, '_slideshow', 'field_59d0452416af8'),
(414, 116, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(415, 116, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(416, 116, 'slideshow_1_page_link', '10'),
(417, 116, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(418, 116, 'slideshow_1_slide', '111'),
(419, 116, '_slideshow_1_slide', 'field_59d0452f16af9'),
(420, 116, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(421, 116, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(422, 116, 'slideshow_2_page_link', '40'),
(423, 116, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(424, 116, 'slideshow_2_slide', '109'),
(425, 116, '_slideshow_2_slide', 'field_59d0452f16af9'),
(426, 116, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(427, 116, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(428, 116, 'slideshow_3_page_link', '42'),
(429, 116, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(430, 116, 'slideshow_3_slide', '112'),
(431, 116, '_slideshow_3_slide', 'field_59d0452f16af9'),
(432, 116, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(433, 116, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(434, 116, 'slideshow_4_page_link', '8'),
(435, 116, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(436, 116, 'slideshow_4_slide', '110'),
(437, 116, '_slideshow_4_slide', 'field_59d0452f16af9'),
(438, 5, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(439, 5, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(440, 5, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(441, 5, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(442, 5, 'mobile_slideshow_0_slide', '104'),
(443, 5, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(444, 5, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(445, 5, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(446, 5, 'mobile_slideshow_1_page_link', '38'),
(447, 5, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(448, 5, 'mobile_slideshow_1_slide', '105'),
(449, 5, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(450, 5, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(451, 5, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(452, 5, 'mobile_slideshow_2_page_link', '80'),
(453, 5, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(454, 5, 'mobile_slideshow_2_slide', '106'),
(455, 5, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(456, 5, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(457, 5, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(458, 5, 'mobile_slideshow_3_page_link', '42'),
(459, 5, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(460, 5, 'mobile_slideshow_3_slide', '107'),
(461, 5, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(462, 5, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(463, 5, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(464, 5, 'mobile_slideshow_4_page_link', '85'),
(465, 5, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(466, 5, 'mobile_slideshow_4_slide', '108'),
(467, 5, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(468, 5, 'mobile_slideshow', '5'),
(469, 5, '_mobile_slideshow', 'field_59d04bf21f0af'),
(470, 5, 'homepage_content', '<h1>studio barre is... fun, effective and sassy</h1>\r\n	\r\n	<p>studio barre classes apply the perfect combination of arm, seat, thigh and ab exercises to define and sculpt the body. the 60-minute workout digs deep physically while the music and happy barre{tenders} keep you mentally in the moment and push you toward your best.</p>'),
(471, 5, '_homepage_content', 'field_59d04c693c2d4'),
(472, 126, 'slideshow_0_video_or_linked_slide', 'Video'),
(473, 126, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(474, 126, 'slideshow_0_video_link', 'm_a8DiPf3Tk') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(475, 126, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(476, 126, 'slideshow_0_slide', '113'),
(477, 126, '_slideshow_0_slide', 'field_59d0452f16af9'),
(478, 126, 'slideshow_0_mobile_slide', '104'),
(479, 126, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(480, 126, 'slideshow', '5'),
(481, 126, '_slideshow', 'field_59d0452416af8'),
(482, 126, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(483, 126, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(484, 126, 'slideshow_1_page_link', '10'),
(485, 126, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(486, 126, 'slideshow_1_slide', '111'),
(487, 126, '_slideshow_1_slide', 'field_59d0452f16af9'),
(488, 126, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(489, 126, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(490, 126, 'slideshow_2_page_link', '40'),
(491, 126, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(492, 126, 'slideshow_2_slide', '109'),
(493, 126, '_slideshow_2_slide', 'field_59d0452f16af9'),
(494, 126, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(495, 126, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(496, 126, 'slideshow_3_page_link', '42'),
(497, 126, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(498, 126, 'slideshow_3_slide', '112'),
(499, 126, '_slideshow_3_slide', 'field_59d0452f16af9'),
(500, 126, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(501, 126, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(502, 126, 'slideshow_4_page_link', '8'),
(503, 126, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(504, 126, 'slideshow_4_slide', '110'),
(505, 126, '_slideshow_4_slide', 'field_59d0452f16af9'),
(506, 126, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(507, 126, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(508, 126, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(509, 126, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(510, 126, 'mobile_slideshow_0_slide', '104'),
(511, 126, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(512, 126, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(513, 126, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(514, 126, 'mobile_slideshow_1_page_link', '10'),
(515, 126, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(516, 126, 'mobile_slideshow_1_slide', '105'),
(517, 126, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(518, 126, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(519, 126, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(520, 126, 'mobile_slideshow_2_page_link', '80'),
(521, 126, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(522, 126, 'mobile_slideshow_2_slide', '106'),
(523, 126, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(524, 126, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(525, 126, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(526, 126, 'mobile_slideshow_3_page_link', '42'),
(527, 126, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(528, 126, 'mobile_slideshow_3_slide', '107'),
(529, 126, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(530, 126, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(531, 126, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(532, 126, 'mobile_slideshow_4_page_link', '85'),
(533, 126, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(534, 126, 'mobile_slideshow_4_slide', '108'),
(535, 126, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(536, 126, 'mobile_slideshow', '5'),
(537, 126, '_mobile_slideshow', 'field_59d04bf21f0af'),
(538, 126, 'homepage_content', ''),
(539, 126, '_homepage_content', 'field_59d04c693c2d4'),
(540, 5, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(541, 5, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(548, 127, 'slideshow_0_video_or_linked_slide', 'Video'),
(549, 127, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(550, 127, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(551, 127, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(552, 127, 'slideshow_0_slide', '113'),
(553, 127, '_slideshow_0_slide', 'field_59d0452f16af9'),
(554, 127, 'slideshow_0_mobile_slide', '104'),
(555, 127, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(556, 127, 'slideshow', '6'),
(557, 127, '_slideshow', 'field_59d0452416af8'),
(558, 127, 'slideshow_1_video_or_linked_slide', 'Video'),
(559, 127, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(560, 127, 'slideshow_1_page_link', '10'),
(561, 127, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(562, 127, 'slideshow_1_slide', '111'),
(563, 127, '_slideshow_1_slide', 'field_59d0452f16af9'),
(564, 127, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(565, 127, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(566, 127, 'slideshow_2_page_link', '10'),
(567, 127, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(568, 127, 'slideshow_2_slide', '111'),
(569, 127, '_slideshow_2_slide', 'field_59d0452f16af9'),
(570, 127, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(571, 127, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(572, 127, 'slideshow_3_page_link', '40'),
(573, 127, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(574, 127, 'slideshow_3_slide', '109'),
(575, 127, '_slideshow_3_slide', 'field_59d0452f16af9'),
(576, 127, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(577, 127, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(578, 127, 'slideshow_4_page_link', '42'),
(579, 127, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(580, 127, 'slideshow_4_slide', '112') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(581, 127, '_slideshow_4_slide', 'field_59d0452f16af9'),
(582, 127, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(583, 127, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(584, 127, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(585, 127, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(586, 127, 'mobile_slideshow_0_slide', '104'),
(587, 127, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(588, 127, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(589, 127, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(590, 127, 'mobile_slideshow_1_page_link', '10'),
(591, 127, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(592, 127, 'mobile_slideshow_1_slide', '105'),
(593, 127, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(594, 127, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(595, 127, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(596, 127, 'mobile_slideshow_2_page_link', '80'),
(597, 127, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(598, 127, 'mobile_slideshow_2_slide', '106'),
(599, 127, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(600, 127, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(601, 127, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(602, 127, 'mobile_slideshow_3_page_link', '42'),
(603, 127, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(604, 127, 'mobile_slideshow_3_slide', '107'),
(605, 127, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(606, 127, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(607, 127, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(608, 127, 'mobile_slideshow_4_page_link', '85'),
(609, 127, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(610, 127, 'mobile_slideshow_4_slide', '108'),
(611, 127, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(612, 127, 'mobile_slideshow', '5'),
(613, 127, '_mobile_slideshow', 'field_59d04bf21f0af'),
(614, 127, 'homepage_content', ''),
(615, 127, '_homepage_content', 'field_59d04c693c2d4'),
(616, 127, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(617, 127, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(618, 127, 'slideshow_5_video_or_linked_slide', 'Linked Slide'),
(619, 127, '_slideshow_5_video_or_linked_slide', 'field_59d0465923bc8'),
(620, 127, 'slideshow_5_page_link', '8'),
(621, 127, '_slideshow_5_page_link', 'field_59d0459d16afa'),
(622, 127, 'slideshow_5_slide', '110'),
(623, 127, '_slideshow_5_slide', 'field_59d0452f16af9'),
(624, 5, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(625, 5, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(626, 128, 'slideshow_0_video_or_linked_slide', 'Video'),
(627, 128, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(628, 128, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(629, 128, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(630, 128, 'slideshow_0_slide', '113'),
(631, 128, '_slideshow_0_slide', 'field_59d0452f16af9'),
(632, 128, 'slideshow_0_mobile_slide', '104'),
(633, 128, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(634, 128, 'slideshow', '6'),
(635, 128, '_slideshow', 'field_59d0452416af8'),
(636, 128, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(637, 128, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(638, 128, 'slideshow_1_page_link', '10'),
(639, 128, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(640, 128, 'slideshow_1_slide', '111'),
(641, 128, '_slideshow_1_slide', 'field_59d0452f16af9'),
(642, 128, 'slideshow_2_video_or_linked_slide', 'Video'),
(643, 128, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(644, 128, 'slideshow_2_page_link', '10'),
(645, 128, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(646, 128, 'slideshow_2_slide', '111'),
(647, 128, '_slideshow_2_slide', 'field_59d0452f16af9'),
(648, 128, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(649, 128, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(650, 128, 'slideshow_3_page_link', '40'),
(651, 128, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(652, 128, 'slideshow_3_slide', '109'),
(653, 128, '_slideshow_3_slide', 'field_59d0452f16af9'),
(654, 128, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(655, 128, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(656, 128, 'slideshow_4_page_link', '42'),
(657, 128, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(658, 128, 'slideshow_4_slide', '112'),
(659, 128, '_slideshow_4_slide', 'field_59d0452f16af9'),
(660, 128, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(661, 128, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(662, 128, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(663, 128, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(664, 128, 'mobile_slideshow_0_slide', '104'),
(665, 128, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(666, 128, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(667, 128, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(668, 128, 'mobile_slideshow_1_page_link', '10'),
(669, 128, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(670, 128, 'mobile_slideshow_1_slide', '105'),
(671, 128, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(672, 128, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(673, 128, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(674, 128, 'mobile_slideshow_2_page_link', '80'),
(675, 128, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(676, 128, 'mobile_slideshow_2_slide', '106'),
(677, 128, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(678, 128, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(679, 128, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(680, 128, 'mobile_slideshow_3_page_link', '42') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(681, 128, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(682, 128, 'mobile_slideshow_3_slide', '107'),
(683, 128, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(684, 128, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(685, 128, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(686, 128, 'mobile_slideshow_4_page_link', '85'),
(687, 128, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(688, 128, 'mobile_slideshow_4_slide', '108'),
(689, 128, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(690, 128, 'mobile_slideshow', '5'),
(691, 128, '_mobile_slideshow', 'field_59d04bf21f0af'),
(692, 128, 'homepage_content', ''),
(693, 128, '_homepage_content', 'field_59d04c693c2d4'),
(694, 128, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(695, 128, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(696, 128, 'slideshow_5_video_or_linked_slide', 'Linked Slide'),
(697, 128, '_slideshow_5_video_or_linked_slide', 'field_59d0465923bc8'),
(698, 128, 'slideshow_5_page_link', '8'),
(699, 128, '_slideshow_5_page_link', 'field_59d0459d16afa'),
(700, 128, 'slideshow_5_slide', '110'),
(701, 128, '_slideshow_5_slide', 'field_59d0452f16af9'),
(702, 128, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(703, 128, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(704, 5, 'mobile_slideshow_2_video_link', 'O_iTQuQrrmc'),
(705, 5, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(712, 129, 'slideshow_0_video_or_linked_slide', 'Video'),
(713, 129, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(714, 129, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(715, 129, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(716, 129, 'slideshow_0_slide', '113'),
(717, 129, '_slideshow_0_slide', 'field_59d0452f16af9'),
(718, 129, 'slideshow_0_mobile_slide', '104'),
(719, 129, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(720, 129, 'slideshow', '5'),
(721, 129, '_slideshow', 'field_59d0452416af8'),
(722, 129, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(723, 129, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(724, 129, 'slideshow_1_page_link', '10'),
(725, 129, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(726, 129, 'slideshow_1_slide', '111'),
(727, 129, '_slideshow_1_slide', 'field_59d0452f16af9'),
(728, 129, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(729, 129, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(730, 129, 'slideshow_2_page_link', '40'),
(731, 129, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(732, 129, 'slideshow_2_slide', '109'),
(733, 129, '_slideshow_2_slide', 'field_59d0452f16af9'),
(734, 129, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(735, 129, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(736, 129, 'slideshow_3_page_link', '42'),
(737, 129, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(738, 129, 'slideshow_3_slide', '112'),
(739, 129, '_slideshow_3_slide', 'field_59d0452f16af9'),
(740, 129, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(741, 129, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(742, 129, 'slideshow_4_page_link', '8'),
(743, 129, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(744, 129, 'slideshow_4_slide', '110'),
(745, 129, '_slideshow_4_slide', 'field_59d0452f16af9'),
(746, 129, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(747, 129, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(748, 129, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(749, 129, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(750, 129, 'mobile_slideshow_0_slide', '104'),
(751, 129, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(752, 129, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(753, 129, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(754, 129, 'mobile_slideshow_1_page_link', '10'),
(755, 129, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(756, 129, 'mobile_slideshow_1_slide', '105'),
(757, 129, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(758, 129, 'mobile_slideshow_2_video_or_linked_slide', 'Video'),
(759, 129, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(760, 129, 'mobile_slideshow_2_page_link', '80'),
(761, 129, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(762, 129, 'mobile_slideshow_2_slide', '105'),
(763, 129, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(764, 129, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(765, 129, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(766, 129, 'mobile_slideshow_3_page_link', '80'),
(767, 129, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(768, 129, 'mobile_slideshow_3_slide', '106'),
(769, 129, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(770, 129, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(771, 129, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(772, 129, 'mobile_slideshow_4_page_link', '42'),
(773, 129, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(774, 129, 'mobile_slideshow_4_slide', '107'),
(775, 129, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(776, 129, 'mobile_slideshow', '6'),
(777, 129, '_mobile_slideshow', 'field_59d04bf21f0af'),
(778, 129, 'homepage_content', ''),
(779, 129, '_homepage_content', 'field_59d04c693c2d4'),
(780, 129, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(781, 129, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(782, 129, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(783, 129, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(784, 129, 'mobile_slideshow_2_video_link', 'A75PQLV-Nck'),
(785, 129, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(786, 129, 'mobile_slideshow_5_video_or_linked_slide', 'Linked Slide') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(787, 129, '_mobile_slideshow_5_video_or_linked_slide', 'field_59d04bf21f0b0'),
(788, 129, 'mobile_slideshow_5_page_link', '85'),
(789, 129, '_mobile_slideshow_5_page_link', 'field_59d04bf21f0b1'),
(790, 129, 'mobile_slideshow_5_slide', '108'),
(791, 129, '_mobile_slideshow_5_slide', 'field_59d04bf21f0b3'),
(798, 130, 'slideshow_0_video_or_linked_slide', 'Video'),
(799, 130, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(800, 130, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(801, 130, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(802, 130, 'slideshow_0_slide', '113'),
(803, 130, '_slideshow_0_slide', 'field_59d0452f16af9'),
(804, 130, 'slideshow_0_mobile_slide', '104'),
(805, 130, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(806, 130, 'slideshow', '6'),
(807, 130, '_slideshow', 'field_59d0452416af8'),
(808, 130, 'slideshow_1_video_or_linked_slide', 'Video'),
(809, 130, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(810, 130, 'slideshow_1_page_link', '10'),
(811, 130, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(812, 130, 'slideshow_1_slide', '104'),
(813, 130, '_slideshow_1_slide', 'field_59d0452f16af9'),
(814, 130, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(815, 130, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(816, 130, 'slideshow_2_page_link', '10'),
(817, 130, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(818, 130, 'slideshow_2_slide', '111'),
(819, 130, '_slideshow_2_slide', 'field_59d0452f16af9'),
(820, 130, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(821, 130, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(822, 130, 'slideshow_3_page_link', '40'),
(823, 130, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(824, 130, 'slideshow_3_slide', '109'),
(825, 130, '_slideshow_3_slide', 'field_59d0452f16af9'),
(826, 130, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(827, 130, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(828, 130, 'slideshow_4_page_link', '42'),
(829, 130, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(830, 130, 'slideshow_4_slide', '112'),
(831, 130, '_slideshow_4_slide', 'field_59d0452f16af9'),
(832, 130, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(833, 130, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(834, 130, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(835, 130, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(836, 130, 'mobile_slideshow_0_slide', '104'),
(837, 130, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(838, 130, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(839, 130, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(840, 130, 'mobile_slideshow_1_page_link', '10'),
(841, 130, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(842, 130, 'mobile_slideshow_1_slide', '105'),
(843, 130, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(844, 130, 'mobile_slideshow_2_video_or_linked_slide', 'Video'),
(845, 130, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(846, 130, 'mobile_slideshow_2_page_link', '80'),
(847, 130, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(848, 130, 'mobile_slideshow_2_slide', '105'),
(849, 130, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(850, 130, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(851, 130, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(852, 130, 'mobile_slideshow_3_page_link', '80'),
(853, 130, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(854, 130, 'mobile_slideshow_3_slide', '106'),
(855, 130, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(856, 130, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(857, 130, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(858, 130, 'mobile_slideshow_4_page_link', '42'),
(859, 130, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(860, 130, 'mobile_slideshow_4_slide', '107'),
(861, 130, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(862, 130, 'mobile_slideshow', '6'),
(863, 130, '_mobile_slideshow', 'field_59d04bf21f0af'),
(864, 130, 'homepage_content', ''),
(865, 130, '_homepage_content', 'field_59d04c693c2d4'),
(866, 130, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(867, 130, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(868, 130, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(869, 130, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(870, 130, 'mobile_slideshow_2_video_link', 'A75PQLV-Nck'),
(871, 130, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(872, 130, 'mobile_slideshow_5_video_or_linked_slide', 'Linked Slide'),
(873, 130, '_mobile_slideshow_5_video_or_linked_slide', 'field_59d04bf21f0b0'),
(874, 130, 'mobile_slideshow_5_page_link', '85'),
(875, 130, '_mobile_slideshow_5_page_link', 'field_59d04bf21f0b1'),
(876, 130, 'mobile_slideshow_5_slide', '108'),
(877, 130, '_mobile_slideshow_5_slide', 'field_59d04bf21f0b3'),
(878, 130, 'slideshow_5_video_or_linked_slide', 'Linked Slide'),
(879, 130, '_slideshow_5_video_or_linked_slide', 'field_59d0465923bc8'),
(880, 130, 'slideshow_5_page_link', '8'),
(881, 130, '_slideshow_5_page_link', 'field_59d0459d16afa'),
(882, 130, 'slideshow_5_slide', '110'),
(883, 130, '_slideshow_5_slide', 'field_59d0452f16af9'),
(884, 131, 'slideshow_0_video_or_linked_slide', 'Video'),
(885, 131, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(886, 131, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(887, 131, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(888, 131, 'slideshow_0_slide', '113'),
(889, 131, '_slideshow_0_slide', 'field_59d0452f16af9'),
(890, 131, 'slideshow_0_mobile_slide', '104'),
(891, 131, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(892, 131, 'slideshow', '6') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(893, 131, '_slideshow', 'field_59d0452416af8'),
(894, 131, 'slideshow_1_video_or_linked_slide', 'Video'),
(895, 131, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(896, 131, 'slideshow_1_page_link', '10'),
(897, 131, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(898, 131, 'slideshow_1_slide', '113'),
(899, 131, '_slideshow_1_slide', 'field_59d0452f16af9'),
(900, 131, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(901, 131, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(902, 131, 'slideshow_2_page_link', '10'),
(903, 131, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(904, 131, 'slideshow_2_slide', '111'),
(905, 131, '_slideshow_2_slide', 'field_59d0452f16af9'),
(906, 131, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(907, 131, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(908, 131, 'slideshow_3_page_link', '40'),
(909, 131, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(910, 131, 'slideshow_3_slide', '109'),
(911, 131, '_slideshow_3_slide', 'field_59d0452f16af9'),
(912, 131, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(913, 131, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(914, 131, 'slideshow_4_page_link', '42'),
(915, 131, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(916, 131, 'slideshow_4_slide', '112'),
(917, 131, '_slideshow_4_slide', 'field_59d0452f16af9'),
(918, 131, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(919, 131, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(920, 131, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(921, 131, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(922, 131, 'mobile_slideshow_0_slide', '104'),
(923, 131, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(924, 131, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(925, 131, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(926, 131, 'mobile_slideshow_1_page_link', '10'),
(927, 131, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(928, 131, 'mobile_slideshow_1_slide', '105'),
(929, 131, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(930, 131, 'mobile_slideshow_2_video_or_linked_slide', 'Video'),
(931, 131, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(932, 131, 'mobile_slideshow_2_page_link', '80'),
(933, 131, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(934, 131, 'mobile_slideshow_2_slide', '105'),
(935, 131, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(936, 131, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(937, 131, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(938, 131, 'mobile_slideshow_3_page_link', '80'),
(939, 131, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(940, 131, 'mobile_slideshow_3_slide', '106'),
(941, 131, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(942, 131, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(943, 131, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(944, 131, 'mobile_slideshow_4_page_link', '42'),
(945, 131, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(946, 131, 'mobile_slideshow_4_slide', '107'),
(947, 131, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(948, 131, 'mobile_slideshow', '6'),
(949, 131, '_mobile_slideshow', 'field_59d04bf21f0af'),
(950, 131, 'homepage_content', ''),
(951, 131, '_homepage_content', 'field_59d04c693c2d4'),
(952, 131, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(953, 131, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(954, 131, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(955, 131, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(956, 131, 'mobile_slideshow_2_video_link', 'A75PQLV-Nck'),
(957, 131, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(958, 131, 'mobile_slideshow_5_video_or_linked_slide', 'Linked Slide'),
(959, 131, '_mobile_slideshow_5_video_or_linked_slide', 'field_59d04bf21f0b0'),
(960, 131, 'mobile_slideshow_5_page_link', '85'),
(961, 131, '_mobile_slideshow_5_page_link', 'field_59d04bf21f0b1'),
(962, 131, 'mobile_slideshow_5_slide', '108'),
(963, 131, '_mobile_slideshow_5_slide', 'field_59d04bf21f0b3'),
(964, 131, 'slideshow_5_video_or_linked_slide', 'Linked Slide'),
(965, 131, '_slideshow_5_video_or_linked_slide', 'field_59d0465923bc8'),
(966, 131, 'slideshow_5_page_link', '8'),
(967, 131, '_slideshow_5_page_link', 'field_59d0459d16afa'),
(968, 131, 'slideshow_5_slide', '110'),
(969, 131, '_slideshow_5_slide', 'field_59d0452f16af9'),
(970, 132, 'slideshow_0_video_or_linked_slide', 'Video'),
(971, 132, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(972, 132, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(973, 132, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(974, 132, 'slideshow_0_slide', '113'),
(975, 132, '_slideshow_0_slide', 'field_59d0452f16af9'),
(976, 132, 'slideshow_0_mobile_slide', '104'),
(977, 132, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(978, 132, 'slideshow', '6'),
(979, 132, '_slideshow', 'field_59d0452416af8'),
(980, 132, 'slideshow_1_video_or_linked_slide', 'Video'),
(981, 132, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(982, 132, 'slideshow_1_page_link', '10'),
(983, 132, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(984, 132, 'slideshow_1_slide', '113'),
(985, 132, '_slideshow_1_slide', 'field_59d0452f16af9'),
(986, 132, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(987, 132, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(988, 132, 'slideshow_2_page_link', '10'),
(989, 132, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(990, 132, 'slideshow_2_slide', '111'),
(991, 132, '_slideshow_2_slide', 'field_59d0452f16af9'),
(992, 132, 'slideshow_3_video_or_linked_slide', 'Linked Slide') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(993, 132, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(994, 132, 'slideshow_3_page_link', '40'),
(995, 132, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(996, 132, 'slideshow_3_slide', '109'),
(997, 132, '_slideshow_3_slide', 'field_59d0452f16af9'),
(998, 132, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(999, 132, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(1000, 132, 'slideshow_4_page_link', '42'),
(1001, 132, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(1002, 132, 'slideshow_4_slide', '112'),
(1003, 132, '_slideshow_4_slide', 'field_59d0452f16af9'),
(1004, 132, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(1005, 132, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1006, 132, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1007, 132, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(1008, 132, 'mobile_slideshow_0_slide', '104'),
(1009, 132, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(1010, 132, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1011, 132, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1012, 132, 'mobile_slideshow_1_page_link', '10'),
(1013, 132, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(1014, 132, 'mobile_slideshow_1_slide', '105'),
(1015, 132, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(1016, 132, 'mobile_slideshow_2_video_or_linked_slide', 'Video'),
(1017, 132, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1018, 132, 'mobile_slideshow_2_page_link', '80'),
(1019, 132, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(1020, 132, 'mobile_slideshow_2_slide', '105'),
(1021, 132, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(1022, 132, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1023, 132, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1024, 132, 'mobile_slideshow_3_page_link', '80'),
(1025, 132, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(1026, 132, 'mobile_slideshow_3_slide', '106'),
(1027, 132, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(1028, 132, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1029, 132, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1030, 132, 'mobile_slideshow_4_page_link', '42'),
(1031, 132, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(1032, 132, 'mobile_slideshow_4_slide', '107'),
(1033, 132, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(1034, 132, 'mobile_slideshow', '6'),
(1035, 132, '_mobile_slideshow', 'field_59d04bf21f0af'),
(1036, 132, 'homepage_content', ''),
(1037, 132, '_homepage_content', 'field_59d04c693c2d4'),
(1038, 132, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(1039, 132, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(1040, 132, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(1041, 132, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(1042, 132, 'mobile_slideshow_2_video_link', 'O_iTQuQrrmc'),
(1043, 132, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(1044, 132, 'mobile_slideshow_5_video_or_linked_slide', 'Linked Slide'),
(1045, 132, '_mobile_slideshow_5_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1046, 132, 'mobile_slideshow_5_page_link', '85'),
(1047, 132, '_mobile_slideshow_5_page_link', 'field_59d04bf21f0b1'),
(1048, 132, 'mobile_slideshow_5_slide', '108'),
(1049, 132, '_mobile_slideshow_5_slide', 'field_59d04bf21f0b3'),
(1050, 132, 'slideshow_5_video_or_linked_slide', 'Linked Slide'),
(1051, 132, '_slideshow_5_video_or_linked_slide', 'field_59d0465923bc8'),
(1052, 132, 'slideshow_5_page_link', '8'),
(1053, 132, '_slideshow_5_page_link', 'field_59d0459d16afa'),
(1054, 132, 'slideshow_5_slide', '110'),
(1055, 132, '_slideshow_5_slide', 'field_59d0452f16af9'),
(1056, 133, 'slideshow_0_video_or_linked_slide', 'Video'),
(1057, 133, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(1058, 133, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1059, 133, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(1060, 133, 'slideshow_0_slide', '113'),
(1061, 133, '_slideshow_0_slide', 'field_59d0452f16af9'),
(1062, 133, 'slideshow_0_mobile_slide', '104'),
(1063, 133, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(1064, 133, 'slideshow', '5'),
(1065, 133, '_slideshow', 'field_59d0452416af8'),
(1066, 133, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1067, 133, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(1068, 133, 'slideshow_1_page_link', '10'),
(1069, 133, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(1070, 133, 'slideshow_1_slide', '111'),
(1071, 133, '_slideshow_1_slide', 'field_59d0452f16af9'),
(1072, 133, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1073, 133, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(1074, 133, 'slideshow_2_page_link', '40'),
(1075, 133, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(1076, 133, 'slideshow_2_slide', '109'),
(1077, 133, '_slideshow_2_slide', 'field_59d0452f16af9'),
(1078, 133, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1079, 133, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(1080, 133, 'slideshow_3_page_link', '42'),
(1081, 133, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(1082, 133, 'slideshow_3_slide', '112'),
(1083, 133, '_slideshow_3_slide', 'field_59d0452f16af9'),
(1084, 133, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1085, 133, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(1086, 133, 'slideshow_4_page_link', '8'),
(1087, 133, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(1088, 133, 'slideshow_4_slide', '110'),
(1089, 133, '_slideshow_4_slide', 'field_59d0452f16af9'),
(1090, 133, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(1091, 133, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1092, 133, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1093, 133, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(1094, 133, 'mobile_slideshow_0_slide', '104'),
(1095, 133, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(1096, 133, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1097, 133, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1098, 133, 'mobile_slideshow_1_page_link', '10'),
(1099, 133, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(1100, 133, 'mobile_slideshow_1_slide', '105'),
(1101, 133, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(1102, 133, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1103, 133, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1104, 133, 'mobile_slideshow_2_page_link', '80'),
(1105, 133, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(1106, 133, 'mobile_slideshow_2_slide', '106'),
(1107, 133, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(1108, 133, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1109, 133, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1110, 133, 'mobile_slideshow_3_page_link', '42'),
(1111, 133, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(1112, 133, 'mobile_slideshow_3_slide', '107'),
(1113, 133, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(1114, 133, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1115, 133, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1116, 133, 'mobile_slideshow_4_page_link', '85'),
(1117, 133, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(1118, 133, 'mobile_slideshow_4_slide', '108'),
(1119, 133, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(1120, 133, 'mobile_slideshow', '5'),
(1121, 133, '_mobile_slideshow', 'field_59d04bf21f0af'),
(1122, 133, 'homepage_content', ''),
(1123, 133, '_homepage_content', 'field_59d04c693c2d4'),
(1124, 133, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(1125, 133, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(1126, 133, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(1127, 133, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(1128, 133, 'mobile_slideshow_2_video_link', 'O_iTQuQrrmc'),
(1129, 133, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(1130, 10, '_wp_trash_meta_status', 'publish'),
(1131, 10, '_wp_trash_meta_time', '1506832854'),
(1132, 10, '_wp_desired_post_slug', 'about-us'),
(1133, 134, '_menu_item_type', 'post_type'),
(1134, 134, '_menu_item_menu_item_parent', '48'),
(1135, 134, '_menu_item_object_id', '38'),
(1136, 134, '_menu_item_object', 'page'),
(1137, 134, '_menu_item_target', ''),
(1138, 134, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1139, 134, '_menu_item_xfn', ''),
(1140, 134, '_menu_item_url', ''),
(1142, 135, 'slideshow_0_video_or_linked_slide', 'Video'),
(1143, 135, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(1144, 135, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1145, 135, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(1146, 135, 'slideshow_0_slide', '113'),
(1147, 135, '_slideshow_0_slide', 'field_59d0452f16af9'),
(1148, 135, 'slideshow_0_mobile_slide', '104'),
(1149, 135, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(1150, 135, 'slideshow', '5'),
(1151, 135, '_slideshow', 'field_59d0452416af8'),
(1152, 135, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1153, 135, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(1154, 135, 'slideshow_1_page_link', '38'),
(1155, 135, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(1156, 135, 'slideshow_1_slide', '111'),
(1157, 135, '_slideshow_1_slide', 'field_59d0452f16af9'),
(1158, 135, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1159, 135, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(1160, 135, 'slideshow_2_page_link', '40'),
(1161, 135, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(1162, 135, 'slideshow_2_slide', '109'),
(1163, 135, '_slideshow_2_slide', 'field_59d0452f16af9'),
(1164, 135, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1165, 135, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(1166, 135, 'slideshow_3_page_link', '42'),
(1167, 135, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(1168, 135, 'slideshow_3_slide', '112'),
(1169, 135, '_slideshow_3_slide', 'field_59d0452f16af9'),
(1170, 135, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1171, 135, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(1172, 135, 'slideshow_4_page_link', '8'),
(1173, 135, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(1174, 135, 'slideshow_4_slide', '110'),
(1175, 135, '_slideshow_4_slide', 'field_59d0452f16af9'),
(1176, 135, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(1177, 135, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1178, 135, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1179, 135, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(1180, 135, 'mobile_slideshow_0_slide', '104'),
(1181, 135, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(1182, 135, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1183, 135, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1184, 135, 'mobile_slideshow_1_page_link', ''),
(1185, 135, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(1186, 135, 'mobile_slideshow_1_slide', '105'),
(1187, 135, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(1188, 135, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1189, 135, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1190, 135, 'mobile_slideshow_2_page_link', '80'),
(1191, 135, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(1192, 135, 'mobile_slideshow_2_slide', '106'),
(1193, 135, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1194, 135, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1195, 135, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1196, 135, 'mobile_slideshow_3_page_link', '42'),
(1197, 135, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(1198, 135, 'mobile_slideshow_3_slide', '107'),
(1199, 135, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(1200, 135, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1201, 135, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1202, 135, 'mobile_slideshow_4_page_link', '85'),
(1203, 135, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(1204, 135, 'mobile_slideshow_4_slide', '108'),
(1205, 135, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(1206, 135, 'mobile_slideshow', '5'),
(1207, 135, '_mobile_slideshow', 'field_59d04bf21f0af'),
(1208, 135, 'homepage_content', ''),
(1209, 135, '_homepage_content', 'field_59d04c693c2d4'),
(1210, 135, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(1211, 135, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(1212, 135, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(1213, 135, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(1214, 135, 'mobile_slideshow_2_video_link', 'O_iTQuQrrmc'),
(1215, 135, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(1216, 136, 'slideshow_0_video_or_linked_slide', 'Video'),
(1217, 136, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(1218, 136, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1219, 136, '_slideshow_0_video_link', 'field_59d0460423bc7'),
(1220, 136, 'slideshow_0_slide', '113'),
(1221, 136, '_slideshow_0_slide', 'field_59d0452f16af9'),
(1222, 136, 'slideshow_0_mobile_slide', '104'),
(1223, 136, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(1224, 136, 'slideshow', '5'),
(1225, 136, '_slideshow', 'field_59d0452416af8'),
(1226, 136, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1227, 136, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(1228, 136, 'slideshow_1_page_link', '38'),
(1229, 136, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(1230, 136, 'slideshow_1_slide', '111'),
(1231, 136, '_slideshow_1_slide', 'field_59d0452f16af9'),
(1232, 136, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1233, 136, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(1234, 136, 'slideshow_2_page_link', '40'),
(1235, 136, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(1236, 136, 'slideshow_2_slide', '109'),
(1237, 136, '_slideshow_2_slide', 'field_59d0452f16af9'),
(1238, 136, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1239, 136, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(1240, 136, 'slideshow_3_page_link', '42'),
(1241, 136, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(1242, 136, 'slideshow_3_slide', '112'),
(1243, 136, '_slideshow_3_slide', 'field_59d0452f16af9'),
(1244, 136, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1245, 136, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(1246, 136, 'slideshow_4_page_link', '8'),
(1247, 136, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(1248, 136, 'slideshow_4_slide', '110'),
(1249, 136, '_slideshow_4_slide', 'field_59d0452f16af9'),
(1250, 136, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(1251, 136, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1252, 136, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1253, 136, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(1254, 136, 'mobile_slideshow_0_slide', '104'),
(1255, 136, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(1256, 136, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1257, 136, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1258, 136, 'mobile_slideshow_1_page_link', '38'),
(1259, 136, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(1260, 136, 'mobile_slideshow_1_slide', '105'),
(1261, 136, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(1262, 136, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1263, 136, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1264, 136, 'mobile_slideshow_2_page_link', '80'),
(1265, 136, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(1266, 136, 'mobile_slideshow_2_slide', '106'),
(1267, 136, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(1268, 136, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1269, 136, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1270, 136, 'mobile_slideshow_3_page_link', '42'),
(1271, 136, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(1272, 136, 'mobile_slideshow_3_slide', '107'),
(1273, 136, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(1274, 136, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1275, 136, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1276, 136, 'mobile_slideshow_4_page_link', '85'),
(1277, 136, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(1278, 136, 'mobile_slideshow_4_slide', '108'),
(1279, 136, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(1280, 136, 'mobile_slideshow', '5'),
(1281, 136, '_mobile_slideshow', 'field_59d04bf21f0af'),
(1282, 136, 'homepage_content', ''),
(1283, 136, '_homepage_content', 'field_59d04c693c2d4'),
(1284, 136, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(1285, 136, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(1286, 136, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(1287, 136, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(1288, 136, 'mobile_slideshow_2_video_link', 'O_iTQuQrrmc'),
(1289, 136, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(1290, 137, 'slideshow_0_video_or_linked_slide', 'Video'),
(1291, 137, '_slideshow_0_video_or_linked_slide', 'field_59d0465923bc8'),
(1292, 137, 'slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1293, 137, '_slideshow_0_video_link', 'field_59d0460423bc7') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1294, 137, 'slideshow_0_slide', '113'),
(1295, 137, '_slideshow_0_slide', 'field_59d0452f16af9'),
(1296, 137, 'slideshow_0_mobile_slide', '104'),
(1297, 137, '_slideshow_0_mobile_slide', 'field_59d04742298e9'),
(1298, 137, 'slideshow', '5'),
(1299, 137, '_slideshow', 'field_59d0452416af8'),
(1300, 137, 'slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1301, 137, '_slideshow_1_video_or_linked_slide', 'field_59d0465923bc8'),
(1302, 137, 'slideshow_1_page_link', '38'),
(1303, 137, '_slideshow_1_page_link', 'field_59d0459d16afa'),
(1304, 137, 'slideshow_1_slide', '111'),
(1305, 137, '_slideshow_1_slide', 'field_59d0452f16af9'),
(1306, 137, 'slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1307, 137, '_slideshow_2_video_or_linked_slide', 'field_59d0465923bc8'),
(1308, 137, 'slideshow_2_page_link', '40'),
(1309, 137, '_slideshow_2_page_link', 'field_59d0459d16afa'),
(1310, 137, 'slideshow_2_slide', '109'),
(1311, 137, '_slideshow_2_slide', 'field_59d0452f16af9'),
(1312, 137, 'slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1313, 137, '_slideshow_3_video_or_linked_slide', 'field_59d0465923bc8'),
(1314, 137, 'slideshow_3_page_link', '42'),
(1315, 137, '_slideshow_3_page_link', 'field_59d0459d16afa'),
(1316, 137, 'slideshow_3_slide', '112'),
(1317, 137, '_slideshow_3_slide', 'field_59d0452f16af9'),
(1318, 137, 'slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1319, 137, '_slideshow_4_video_or_linked_slide', 'field_59d0465923bc8'),
(1320, 137, 'slideshow_4_page_link', '8'),
(1321, 137, '_slideshow_4_page_link', 'field_59d0459d16afa'),
(1322, 137, 'slideshow_4_slide', '110'),
(1323, 137, '_slideshow_4_slide', 'field_59d0452f16af9'),
(1324, 137, 'mobile_slideshow_0_video_or_linked_slide', 'Video'),
(1325, 137, '_mobile_slideshow_0_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1326, 137, 'mobile_slideshow_0_video_link', 'm_a8DiPf3Tk'),
(1327, 137, '_mobile_slideshow_0_video_link', 'field_59d04bf21f0b2'),
(1328, 137, 'mobile_slideshow_0_slide', '104'),
(1329, 137, '_mobile_slideshow_0_slide', 'field_59d04bf21f0b3'),
(1330, 137, 'mobile_slideshow_1_video_or_linked_slide', 'Linked Slide'),
(1331, 137, '_mobile_slideshow_1_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1332, 137, 'mobile_slideshow_1_page_link', '38'),
(1333, 137, '_mobile_slideshow_1_page_link', 'field_59d04bf21f0b1'),
(1334, 137, 'mobile_slideshow_1_slide', '105'),
(1335, 137, '_mobile_slideshow_1_slide', 'field_59d04bf21f0b3'),
(1336, 137, 'mobile_slideshow_2_video_or_linked_slide', 'Linked Slide'),
(1337, 137, '_mobile_slideshow_2_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1338, 137, 'mobile_slideshow_2_page_link', '80'),
(1339, 137, '_mobile_slideshow_2_page_link', 'field_59d04bf21f0b1'),
(1340, 137, 'mobile_slideshow_2_slide', '106'),
(1341, 137, '_mobile_slideshow_2_slide', 'field_59d04bf21f0b3'),
(1342, 137, 'mobile_slideshow_3_video_or_linked_slide', 'Linked Slide'),
(1343, 137, '_mobile_slideshow_3_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1344, 137, 'mobile_slideshow_3_page_link', '42'),
(1345, 137, '_mobile_slideshow_3_page_link', 'field_59d04bf21f0b1'),
(1346, 137, 'mobile_slideshow_3_slide', '107'),
(1347, 137, '_mobile_slideshow_3_slide', 'field_59d04bf21f0b3'),
(1348, 137, 'mobile_slideshow_4_video_or_linked_slide', 'Linked Slide'),
(1349, 137, '_mobile_slideshow_4_video_or_linked_slide', 'field_59d04bf21f0b0'),
(1350, 137, 'mobile_slideshow_4_page_link', '85'),
(1351, 137, '_mobile_slideshow_4_page_link', 'field_59d04bf21f0b1'),
(1352, 137, 'mobile_slideshow_4_slide', '108'),
(1353, 137, '_mobile_slideshow_4_slide', 'field_59d04bf21f0b3'),
(1354, 137, 'mobile_slideshow', '5'),
(1355, 137, '_mobile_slideshow', 'field_59d04bf21f0af'),
(1356, 137, 'homepage_content', '<h1>studio barre is... fun, effective and sassy</h1>\r\n	\r\n	<p>studio barre classes apply the perfect combination of arm, seat, thigh and ab exercises to define and sculpt the body. the 60-minute workout digs deep physically while the music and happy barre{tenders} keep you mentally in the moment and push you toward your best.</p>'),
(1357, 137, '_homepage_content', 'field_59d04c693c2d4'),
(1358, 137, 'slideshow_1_video_link', 'A75PQLV-Nck'),
(1359, 137, '_slideshow_1_video_link', 'field_59d0460423bc7'),
(1360, 137, 'slideshow_2_video_link', 'A75PQLV-Nck'),
(1361, 137, '_slideshow_2_video_link', 'field_59d0460423bc7'),
(1362, 137, 'mobile_slideshow_2_video_link', 'O_iTQuQrrmc'),
(1363, 137, '_mobile_slideshow_2_video_link', 'field_59d04bf21f0b2'),
(1364, 38, '_yoast_wpseo_content_score', '90'),
(1365, 139, '_edit_lock', '1506833880:1'),
(1366, 140, '_edit_lock', '1506834591:1'),
(1367, 140, '_edit_last', '1'),
(1368, 142, '_wp_attached_file', '2017/07/banner-ourstory.jpg'),
(1369, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:885;s:6:"height";i:448;s:4:"file";s:27:"2017/07/banner-ourstory.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"banner-ourstory-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"banner-ourstory-300x152.jpg";s:5:"width";i:300;s:6:"height";i:152;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"banner-ourstory-768x389.jpg";s:5:"width";i:768;s:6:"height";i:389;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1370, 38, 'inner_banners', '142'),
(1371, 38, '_inner_banners', 'field_59d075f99a456'),
(1372, 143, 'inner_banners', '142'),
(1373, 143, '_inner_banners', 'field_59d075f99a456'),
(1374, 144, '_wp_attached_file', '2017/09/banner-maven.jpg'),
(1375, 144, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:885;s:6:"height";i:448;s:4:"file";s:24:"2017/09/banner-maven.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"banner-maven-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"banner-maven-300x152.jpg";s:5:"width";i:300;s:6:"height";i:152;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"banner-maven-768x389.jpg";s:5:"width";i:768;s:6:"height";i:389;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1376, 145, '_wp_attached_file', '2017/09/banner-mentor.jpg'),
(1377, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:885;s:6:"height";i:448;s:4:"file";s:25:"2017/09/banner-mentor.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"banner-mentor-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"banner-mentor-300x152.jpg";s:5:"width";i:300;s:6:"height";i:152;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"banner-mentor-768x389.jpg";s:5:"width";i:768;s:6:"height";i:389;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1378, 146, '_wp_attached_file', '2017/09/banner-society.jpg'),
(1379, 146, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:885;s:6:"height";i:448;s:4:"file";s:26:"2017/09/banner-society.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"banner-society-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"banner-society-300x152.jpg";s:5:"width";i:300;s:6:"height";i:152;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"banner-society-768x389.jpg";s:5:"width";i:768;s:6:"height";i:389;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1380, 80, '_yoast_wpseo_content_score', '30'),
(1381, 80, 'inner_banners', '144'),
(1382, 80, '_inner_banners', 'field_59d075f99a456'),
(1383, 147, 'inner_banners', '144'),
(1384, 147, '_inner_banners', 'field_59d075f99a456'),
(1385, 42, '_yoast_wpseo_content_score', '30'),
(1386, 42, 'inner_banners', '146'),
(1387, 42, '_inner_banners', 'field_59d075f99a456'),
(1388, 148, 'inner_banners', '146'),
(1389, 148, '_inner_banners', 'field_59d075f99a456'),
(1390, 85, '_yoast_wpseo_content_score', '30'),
(1391, 85, 'inner_banners', '145'),
(1392, 85, '_inner_banners', 'field_59d075f99a456'),
(1393, 149, 'inner_banners', '145') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1394, 149, '_inner_banners', 'field_59d075f99a456') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(5, 1, '2017-07-23 23:31:30', '2017-07-23 23:31:30', '', 'Welcome To Studio Barre', '', 'publish', 'closed', 'closed', '', 'welcome-to-studio-barre', '', '', '2017-10-01 04:47:09', '2017-10-01 04:47:09', '', 0, 'http://studiobarre-demo.com/?page_id=5', 0, 'page', '', 0),
(6, 1, '2017-07-23 23:31:30', '2017-07-23 23:31:30', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-07-23 23:31:30', '2017-07-23 23:31:30', '', 5, 'http://studiobarre-demo.com/blog/2017/07/23/5-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 'Find Your Studio', '', 'publish', 'closed', 'closed', '', 'find-your-studio', '', '', '2017-09-28 03:43:11', '2017-09-28 03:43:11', '', 0, 'http://studiobarre-demo.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 'Find Your Studio', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-07-24 01:11:23', '2017-07-24 01:11:23', '', 8, 'http://studiobarre-demo.com/blog/2017/07/24/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 'About Us', '', 'trash', 'closed', 'closed', '', 'about-us__trashed', '', '', '2017-10-01 04:40:54', '2017-10-01 04:40:54', '', 0, 'http://studiobarre-demo.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-07-24 01:11:34', '2017-07-24 01:11:34', '', 10, 'http://studiobarre-demo.com/blog/2017/07/24/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-07-24 01:11:37', '2017-07-24 01:11:37', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2017-07-24 01:11:37', '2017-07-24 01:11:37', '', 10, 'http://studiobarre-demo.com/blog/2017/07/24/10-autosave-v1/', 0, 'revision', '', 0),
(13, 1, '2017-07-24 01:12:00', '2017-07-24 01:12:00', '', 'Questions?', '', 'publish', 'closed', 'closed', '', 'q-a', '', '', '2017-09-19 03:48:45', '2017-09-19 03:48:45', '', 0, 'http://studiobarre-demo.com/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-07-24 01:12:00', '2017-07-24 01:12:00', '', 'Q + A', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-07-24 01:12:00', '2017-07-24 01:12:00', '', 13, 'http://studiobarre-demo.com/blog/2017/07/24/13-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2017-07-24 01:12:09', '2017-07-24 01:12:09', '', 'Press', '', 'publish', 'closed', 'closed', '', 'press', '', '', '2017-09-19 04:22:01', '2017-09-19 04:22:01', '', 0, 'http://studiobarre-demo.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2017-07-24 01:12:09', '2017-07-24 01:12:09', '', 'Press', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-07-24 01:12:09', '2017-07-24 01:12:09', '', 16, 'http://studiobarre-demo.com/blog/2017/07/24/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 0, 'http://studiobarre-demo.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-07-24 01:12:18', '2017-07-24 01:12:18', '', 18, 'http://studiobarre-demo.com/blog/2017/07/24/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2017-07-24 01:12:40', '2017-07-24 01:12:40', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-08-22 04:57:58', '2017-08-22 04:57:58', '', 0, 'http://studiobarre-demo.com/?page_id=20', 0, 'page', '', 0),
(21, 1, '2017-07-24 01:12:40', '2017-07-24 01:12:40', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2017-07-24 01:12:40', '2017-07-24 01:12:40', '', 20, 'http://studiobarre-demo.com/blog/2017/07/24/20-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=31', 14, 'nav_menu_item', '', 0),
(32, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=32', 12, 'nav_menu_item', '', 0),
(33, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', ' ', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=33', 11, 'nav_menu_item', '', 0),
(34, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', '', 'Q + A', '', 'publish', 'closed', 'closed', '', '34', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=34', 10, 'nav_menu_item', '', 0),
(37, 1, '2017-07-24 01:14:16', '2017-07-24 01:14:16', '', 'Own a Studio', '', 'publish', 'closed', 'closed', '', 'own-a-studio', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=37', 13, 'nav_menu_item', '', 0),
(38, 1, '2017-07-24 01:41:37', '2017-07-24 01:41:37', '<h2 class="white">Stronger, Leaner, More Confident</h2>\r\n				\r\n				\r\n				<h2>What is Studio Barre?</h2>\r\n				\r\n				<p>Studio Barre {strength. defined.} is a specialized barre workout class that focuses on building core strength, improving posture and developing long and lean muscles, like those of a dancer.</p>\r\n				\r\n				<p>Former professional dancer and fitness expert Shannon Higgins founded Studio Barre in 2012. Our mission is to give every client a results-oriented, full-body sculpting workout that is fun, effective and sassy. Walk into any Studio Barre for a community-loving barre class and walk out stronger, leaner and more confident.</p>\r\n				\r\n				<h2>Get Stronger</h2>\r\n				\r\n				<p>Studio Barre applies the perfect combination of arm, seat, thigh and ab exercises to define and sculpt the body. The 60-minute workout digs deep physically while the music and happy barre{tenders} keep you mentally in the moment and push you toward your best.</p>\r\n				\r\n				<h2>Get Leaner</h2>\r\n				\r\n				<p>Come to class once and feel a difference; come to class 3-4 times per week for a month and you will see a difference! Showing up to the barre consistently and regularly will create lean, long and strong muscles we all love. Our clients are proof that Studio Barre works.</p>\r\n				\r\n				<h2>Gain More Confidence</h2>\r\n				\r\n				<p>We help you build strong shoulders, core and back to literally raise you up. Stand taller and present a more confident stature. As you gain more strength, meet your goals and make new friends, your inner confidence matches your exterior. When you feel good, you look good… happy!</p>', 'About Us', '', 'publish', 'closed', 'closed', '', 'our-story', '', '', '2017-10-01 05:02:10', '2017-10-01 05:02:10', '', 0, 'http://studiobarre-demo.com/?page_id=38', 0, 'page', '', 0),
(39, 1, '2017-07-24 01:41:37', '2017-07-24 01:41:37', '', 'Our Story', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2017-07-24 01:41:37', '2017-07-24 01:41:37', '', 38, 'http://studiobarre-demo.com/blog/2017/07/24/38-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2017-07-24 01:41:51', '2017-07-24 01:41:51', '', 'Client Results', '', 'publish', 'closed', 'closed', '', 'client-results', '', '', '2017-08-22 04:01:24', '2017-08-22 04:01:24', '', 0, 'http://studiobarre-demo.com/?page_id=40', 0, 'page', '', 0),
(41, 1, '2017-07-24 01:41:51', '2017-07-24 01:41:51', '', 'Client Results', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2017-07-24 01:41:51', '2017-07-24 01:41:51', '', 40, 'http://studiobarre-demo.com/blog/2017/07/24/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2017-07-24 01:42:15', '2017-07-24 01:42:15', '', 'The Society', '', 'publish', 'closed', 'closed', '', 'studio-barre-society', '', '', '2017-10-01 05:04:40', '2017-10-01 05:04:40', '', 0, 'http://studiobarre-demo.com/?page_id=42', 0, 'page', '', 0),
(43, 1, '2017-07-24 01:42:15', '2017-07-24 01:42:15', '', 'Studio Barre Society', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-07-24 01:42:15', '2017-07-24 01:42:15', '', 42, 'http://studiobarre-demo.com/blog/2017/07/24/42-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2017-07-24 01:42:55', '2017-07-24 01:42:55', '', 'Studio Barre Society', '', 'publish', 'closed', 'closed', '', '44', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=44', 8, 'nav_menu_item', '', 0),
(45, 1, '2017-07-24 01:42:55', '2017-07-24 01:42:55', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=45', 6, 'nav_menu_item', '', 0),
(48, 1, '2017-08-07 02:00:15', '2017-08-07 02:00:15', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=48', 4, 'nav_menu_item', '', 0),
(49, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', '', 'Find Your Studio', '', 'publish', 'closed', 'closed', '', 'find-your-studio', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', '', 'Carmel Valley, CA', '', 'publish', 'closed', 'closed', '', 'location-1', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=50', 2, 'nav_menu_item', '', 0),
(52, 1, '2017-08-07 02:45:23', '2017-08-07 02:45:23', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=52', 3, 'nav_menu_item', '', 0),
(54, 1, '2017-08-22 03:43:11', '2017-08-22 03:43:11', '', 'The Society', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-08-22 03:43:11', '2017-08-22 03:43:11', '', 42, 'http://studiobarre-demo.com/blog/2017/08/22/42-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2017-08-22 03:46:26', '2017-08-22 03:46:26', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2017-08-22 03:46:26', '2017-08-22 03:46:26', '', 38, 'http://studiobarre-demo.com/blog/2017/08/22/38-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2017-08-28 04:30:02', '2017-08-28 04:30:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'publish', 'open', 'open', '', 'post-one', '', '', '2017-09-19 03:42:21', '2017-09-19 03:42:21', '', 0, 'http://studiobarre-demo.com/?p=56', 0, 'post', '', 0),
(57, 1, '2017-08-23 04:30:02', '2017-08-23 04:30:02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-08-23 04:30:02', '2017-08-23 04:30:02', '', 56, 'http://studiobarre-demo.com/blog/2017/08/23/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2017-08-23 04:30:17', '2017-08-23 04:30:17', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Three', '', 'publish', 'open', 'open', '', 'post-three', '', '', '2017-08-23 04:30:17', '2017-08-23 04:30:17', '', 0, 'http://studiobarre-demo.com/?p=58', 0, 'post', '', 0),
(59, 1, '2017-08-23 04:30:17', '2017-08-23 04:30:17', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Three', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-08-23 04:30:17', '2017-08-23 04:30:17', '', 58, 'http://studiobarre-demo.com/blog/2017/08/23/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-07-03 04:30:32', '2017-07-03 04:30:32', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Two', '', 'publish', 'open', 'open', '', 'post-two', '', '', '2017-09-19 03:30:37', '2017-09-19 03:30:37', '', 0, 'http://studiobarre-demo.com/?p=60', 0, 'post', '', 0),
(61, 1, '2017-08-23 04:30:32', '2017-08-23 04:30:32', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post Two', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2017-08-23 04:30:32', '2017-08-23 04:30:32', '', 60, 'http://studiobarre-demo.com/blog/2017/08/23/60-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2017-09-19 03:35:20', '2017-09-19 03:35:20', '<img class="alignleft size-medium wp-image-63" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:35:20', '2017-09-19 03:35:20', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2017-09-19 03:36:12', '2017-09-19 03:36:12', '<img class="alignleft size-medium wp-image-63" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:36:12', '2017-09-19 03:36:12', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2017-09-19 03:36:33', '2017-09-19 03:36:33', '<img class="size-medium wp-image-63 aligncenter" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:36:33', '2017-09-19 03:36:33', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2017-09-19 03:37:03', '2017-09-19 03:37:03', '<img class="size-medium wp-image-63 alignright" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:37:03', '2017-09-19 03:37:03', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2017-09-19 03:37:28', '2017-09-19 03:37:28', '<img class="alignright wp-image-63 size-full" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM.png" alt="" width="908" height="1128" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:37:28', '2017-09-19 03:37:28', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2017-09-19 03:38:25', '2017-09-19 03:38:25', '<img class="alignright wp-image-63 size-large" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-824x1024.png" alt="" width="824" height="1024" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:38:25', '2017-09-19 03:38:25', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2017-09-19 03:38:41', '2017-09-19 03:38:41', '<img class="alignright wp-image-63 size-medium" src="http://studiobarre-demo.com/wp-content/uploads/2017/08/Screen-Shot-2017-09-18-at-8.33.40-PM-241x300.png" alt="" width="241" height="300" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:38:41', '2017-09-19 03:38:41', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2017-09-19 03:42:21', '2017-09-19 03:42:21', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Post One', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-09-19 03:42:21', '2017-09-19 03:42:21', '', 56, 'http://studiobarre-demo.com/blog/56-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2017-09-19 03:48:24', '2017-09-19 03:48:24', '', 'FAQs', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-09-19 03:48:24', '2017-09-19 03:48:24', '', 13, 'http://studiobarre-demo.com/blog/13-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2017-09-19 03:48:45', '2017-09-19 03:48:45', '', 'Questions?', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-09-19 03:48:45', '2017-09-19 03:48:45', '', 13, 'http://studiobarre-demo.com/blog/13-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2017-09-19 04:07:36', '2017-09-19 04:07:36', 'afa s f sfv sfv sf vs fdv sfv sf vs fdv sdfv sdf vsd fv sdfvs f', 'Press', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-09-19 04:07:36', '2017-09-19 04:07:36', '', 16, 'http://studiobarre-demo.com/blog/16-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-09-19 04:15:02', '2017-09-19 04:15:02', '', 'Press', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2017-09-19 04:15:02', '2017-09-19 04:15:02', '', 16, 'http://studiobarre-demo.com/blog/16-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2017-09-19 04:15:51', '2017-09-19 04:15:51', 'ads ads v sv sv sf', 'test', '', 'trash', 'closed', 'closed', '', 'test__trashed', '', '', '2017-09-19 04:17:25', '2017-09-19 04:17:25', '', 0, 'http://studiobarre-demo.com/?page_id=77', 0, 'page', '', 0),
(78, 1, '2017-09-19 04:15:51', '2017-09-19 04:15:51', '', 'test', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-09-19 04:15:51', '2017-09-19 04:15:51', '', 77, 'http://studiobarre-demo.com/blog/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2017-09-19 04:17:16', '2017-09-19 04:17:16', 'ads ads v sv sv sf', 'test', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-09-19 04:17:16', '2017-09-19 04:17:16', '', 77, 'http://studiobarre-demo.com/blog/77-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2017-09-20 03:48:27', '2017-09-20 03:48:27', '', 'Barre Mavens', '', 'publish', 'closed', 'closed', '', 'become-a-maven', '', '', '2017-10-01 05:03:31', '2017-10-01 05:03:31', '', 0, 'http://studiobarre-demo.com/?page_id=80', 0, 'page', '', 0),
(81, 1, '2017-09-20 03:48:27', '2017-09-20 03:48:27', '', 'Become a Maven', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2017-09-20 03:48:27', '2017-09-20 03:48:27', '', 80, 'http://studiobarre-demo.com/blog/80-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2017-09-20 03:51:24', '2017-09-20 03:51:24', '', 'Become a Barre Maven', '', 'publish', 'closed', 'closed', '', '82', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=82', 7, 'nav_menu_item', '', 0),
(83, 1, '2017-09-20 04:19:38', '2017-09-20 04:19:38', '', 'Barre Maven', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2017-09-20 04:19:38', '2017-09-20 04:19:38', '', 80, 'http://studiobarre-demo.com/blog/80-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2017-09-21 05:22:59', '2017-09-21 05:22:59', '', 'Barre Mavens', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2017-09-21 05:22:59', '2017-09-21 05:22:59', '', 80, 'http://studiobarre-demo.com/blog/80-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2017-09-23 22:02:49', '2017-09-23 22:02:49', '', 'Mentors', '', 'publish', 'closed', 'closed', '', 'studio-barre-mentors', '', '', '2017-10-01 05:05:00', '2017-10-01 05:05:00', '', 0, 'http://studiobarre-demo.com/?page_id=85', 0, 'page', '', 0),
(86, 1, '2017-09-23 22:02:49', '2017-09-23 22:02:49', '', 'Studio Barre Mentors', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2017-09-23 22:02:49', '2017-09-23 22:02:49', '', 85, 'http://studiobarre-demo.com/blog/85-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2017-09-23 22:03:28', '2017-09-23 22:03:28', '', 'Mentors', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2017-09-23 22:03:28', '2017-09-23 22:03:28', '', 85, 'http://studiobarre-demo.com/blog/85-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2017-09-23 22:04:06', '2017-09-23 22:04:06', '', 'Studio Barre Mentors', '', 'publish', 'closed', 'closed', '', 'studio-barre-mentors', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=88', 9, 'nav_menu_item', '', 0),
(89, 1, '2017-09-23 22:38:14', '2017-09-23 22:38:14', 'asdv ad vad v', 'Owner Resources', '', 'publish', 'closed', 'closed', 'test', 'owner-resources', '', '', '2017-09-23 22:48:05', '2017-09-23 22:48:05', '', 0, 'http://studiobarre-demo.com/?page_id=89', 0, 'page', '', 0),
(90, 1, '2017-09-23 22:38:14', '2017-09-23 22:38:14', '', 'Owner Resources', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2017-09-23 22:38:14', '2017-09-23 22:38:14', '', 89, 'http://studiobarre-demo.com/blog/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2017-09-23 22:47:52', '2017-09-23 22:47:52', 'asdv ad vad v', 'Owner Resources', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2017-09-23 22:47:52', '2017-09-23 22:47:52', '', 89, 'http://studiobarre-demo.com/blog/89-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2017-09-24 20:54:40', '2017-09-24 20:54:40', '', 'Teacher Resources', '', 'publish', 'closed', 'closed', 'ShakeTuck', 'teachers', '', '', '2017-09-24 20:55:45', '2017-09-24 20:55:45', '', 0, 'http://studiobarre-demo.com/?page_id=92', 0, 'page', '', 0),
(93, 1, '2017-09-24 20:54:40', '2017-09-24 20:54:40', '', 'Teacher Resources', '', 'inherit', 'closed', 'closed', '', '92-revision-v1', '', '', '2017-09-24 20:54:40', '2017-09-24 20:54:40', '', 92, 'http://studiobarre-demo.com/blog/92-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2017-09-24 23:21:45', '2017-09-24 23:21:45', '', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2017-09-24 23:21:45', '2017-09-24 23:21:45', '', 0, 'http://studiobarre-demo.com/?page_id=94', 0, 'page', '', 0),
(95, 1, '2017-09-24 23:21:45', '2017-09-24 23:21:45', '', 'Thank You', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2017-09-24 23:21:45', '2017-09-24 23:21:45', '', 94, 'http://studiobarre-demo.com/blog/94-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2017-09-27 03:11:52', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-09-27 03:11:52', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/?p=96', 0, 'post', '', 0),
(97, 1, '2017-10-01 01:32:40', '2017-10-01 01:32:40', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Home Page', 'home-page', 'publish', 'closed', 'closed', '', 'group_59d0451f7af36', '', '', '2017-10-01 04:58:18', '2017-10-01 04:58:18', '', 0, 'http://studiobarre-demo.com/?post_type=acf-field-group&#038;p=97', 0, 'acf-field-group', '', 0),
(98, 1, '2017-10-01 01:32:40', '2017-10-01 01:32:40', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:9:"Add Slide";}', 'Slideshow', 'slideshow', 'publish', 'closed', 'closed', '', 'field_59d0452416af8', '', '', '2017-10-01 02:01:10', '2017-10-01 02:01:10', '', 97, 'http://studiobarre-demo.com/?post_type=acf-field&#038;p=98', 1, 'acf-field', '', 0),
(99, 1, '2017-10-01 01:32:40', '2017-10-01 01:32:40', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:53:"Image needs to be 1200px wide by 663px high and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:1199;s:10:"min_height";i:662;s:8:"min_size";s:0:"";s:9:"max_width";i:1201;s:10:"max_height";i:664;s:8:"max_size";i:250;s:10:"mime_types";s:3:"jpg";}', 'Desktop Slide', 'slide', 'publish', 'closed', 'closed', '', 'field_59d0452f16af9', '', '', '2017-10-01 01:39:07', '2017-10-01 01:39:07', '', 98, 'http://studiobarre-demo.com/?post_type=acf-field&#038;p=99', 3, 'acf-field', '', 0),
(100, 1, '2017-10-01 01:32:40', '2017-10-01 01:32:40', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:2:{i:0;s:4:"page";i:1;s:4:"post";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:0;s:8:"multiple";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_59d0465923bc8";s:8:"operator";s:2:"==";s:5:"value";s:12:"Linked Slide";}}}}', 'Page Link', 'page_link', 'publish', 'closed', 'closed', '', 'field_59d0459d16afa', '', '', '2017-10-01 01:51:46', '2017-10-01 01:51:46', '', 98, 'http://studiobarre-demo.com/?post_type=acf-field&#038;p=100', 1, 'acf-field', '', 0),
(101, 1, '2017-10-01 01:36:28', '2017-10-01 01:36:28', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:70:"Enter the Youtube video id found in the youtube url (i.e. m_a8DiPf3Tk)";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:11:"m_a8DiPf3Tk";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_59d0465923bc8";s:8:"operator";s:2:"==";s:5:"value";s:5:"Video";}}}}', 'Video Link', 'video_link', 'publish', 'closed', 'closed', '', 'field_59d0460423bc7', '', '', '2017-10-01 01:37:12', '2017-10-01 01:37:12', '', 98, 'http://studiobarre-demo.com/?post_type=acf-field&#038;p=101', 2, 'acf-field', '', 0),
(102, 1, '2017-10-01 01:36:28', '2017-10-01 01:36:28', 'a:13:{s:4:"type";s:6:"select";s:12:"instructions";s:45:"Will this slide be a video or a linked slide?";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:12:"Linked Slide";s:12:"Linked Slide";s:5:"Video";s:5:"Video";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:13:"return_format";s:5:"value";s:11:"placeholder";s:0:"";}', 'Video or Linked Slide?', 'video_or_linked_slide', 'publish', 'closed', 'closed', '', 'field_59d0465923bc8', '', '', '2017-10-01 04:55:27', '2017-10-01 04:55:27', '', 98, 'http://studiobarre-demo.com/?post_type=acf-field&#038;p=102', 0, 'acf-field', '', 0),
(104, 1, '2017-10-01 01:49:54', '2017-10-01 01:49:54', '', 'm1', '', 'inherit', 'open', 'closed', '', 'm1', '', '', '2017-10-01 01:49:54', '2017-10-01 01:49:54', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/m1.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(105, 1, '2017-10-01 01:49:55', '2017-10-01 01:49:55', '', 'm2', '', 'inherit', 'open', 'closed', '', 'm2', '', '', '2017-10-01 01:49:55', '2017-10-01 01:49:55', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/m2.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 1, '2017-10-01 01:49:56', '2017-10-01 01:49:56', '', 'm3', '', 'inherit', 'open', 'closed', '', 'm3', '', '', '2017-10-01 01:49:56', '2017-10-01 01:49:56', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/m3.jpg', 0, 'attachment', 'image/jpeg', 0),
(107, 1, '2017-10-01 01:49:57', '2017-10-01 01:49:57', '', 'm4', '', 'inherit', 'open', 'closed', '', 'm4', '', '', '2017-10-01 01:49:57', '2017-10-01 01:49:57', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/m4.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2017-10-01 01:49:58', '2017-10-01 01:49:58', '', 'm5', '', 'inherit', 'open', 'closed', '', 'm5', '', '', '2017-10-01 01:49:58', '2017-10-01 01:49:58', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/m5.jpg', 0, 'attachment', 'image/jpeg', 0),
(109, 1, '2017-10-01 01:50:31', '2017-10-01 01:50:31', '', 'slide-clientresults', '', 'inherit', 'open', 'closed', '', 'slide-clientresults', '', '', '2017-10-01 01:50:31', '2017-10-01 01:50:31', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/slide-clientresults.jpg', 0, 'attachment', 'image/jpeg', 0),
(110, 1, '2017-10-01 01:50:33', '2017-10-01 01:50:33', '', 'slide-findclass', '', 'inherit', 'open', 'closed', '', 'slide-findclass', '', '', '2017-10-01 01:50:33', '2017-10-01 01:50:33', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/slide-findclass.jpg', 0, 'attachment', 'image/jpeg', 0),
(111, 1, '2017-10-01 01:50:34', '2017-10-01 01:50:34', '', 'slide-ourstory', '', 'inherit', 'open', 'closed', '', 'slide-ourstory', '', '', '2017-10-01 01:50:34', '2017-10-01 01:50:34', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/slide-ourstory.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2017-10-01 01:50:35', '2017-10-01 01:50:35', '', 'slide-society', '', 'inherit', 'open', 'closed', '', 'slide-society', '', '', '2017-10-01 01:50:35', '2017-10-01 01:50:35', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/slide-society.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 1, '2017-10-01 01:50:37', '2017-10-01 01:50:37', '', 'slide-video', '', 'inherit', 'open', 'closed', '', 'slide-video', '', '', '2017-10-01 01:50:37', '2017-10-01 01:50:37', '', 5, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/slide-video.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2017-10-01 01:50:58', '2017-10-01 01:50:58', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 01:50:58', '2017-10-01 01:50:58', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2017-10-01 01:59:02', '2017-10-01 01:59:02', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 01:59:02', '2017-10-01 01:59:02', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2017-10-01 02:00:08', '2017-10-01 02:00:08', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:9:"Add Slide";}', 'Mobile Sections', 'mobile_slideshow', 'publish', 'closed', 'closed', '', 'field_59d04bf21f0af', '', '', '2017-10-01 02:01:10', '2017-10-01 02:01:10', '', 97, 'http://studiobarre-demo.com/?post_type=acf-field&#038;p=117', 3, 'acf-field', '', 0),
(118, 1, '2017-10-01 02:00:08', '2017-10-01 02:00:08', 'a:13:{s:4:"type";s:6:"select";s:12:"instructions";s:45:"Will this slide be a video or a linked slide?";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:12:"Linked Slide";s:12:"Linked Slide";s:5:"Video";s:5:"Video";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:13:"return_format";s:5:"value";s:11:"placeholder";s:0:"";}', 'Video or Linked Slide?', 'video_or_linked_slide', 'publish', 'closed', 'closed', '', 'field_59d04bf21f0b0', '', '', '2017-10-01 02:00:08', '2017-10-01 02:00:08', '', 117, 'http://studiobarre-demo.com/?post_type=acf-field&p=118', 0, 'acf-field', '', 0),
(119, 1, '2017-10-01 02:00:08', '2017-10-01 02:00:08', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:2:{i:0;s:4:"page";i:1;s:4:"post";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:0;s:8:"multiple";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_59d04bf21f0b0";s:8:"operator";s:2:"==";s:5:"value";s:12:"Linked Slide";}}}}', 'Page Link', 'page_link', 'publish', 'closed', 'closed', '', 'field_59d04bf21f0b1', '', '', '2017-10-01 02:00:08', '2017-10-01 02:00:08', '', 117, 'http://studiobarre-demo.com/?post_type=acf-field&p=119', 1, 'acf-field', '', 0),
(120, 1, '2017-10-01 02:00:08', '2017-10-01 02:00:08', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:70:"Enter the Youtube video id found in the youtube url (i.e. m_a8DiPf3Tk)";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:11:"m_a8DiPf3Tk";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_59d04bf21f0b0";s:8:"operator";s:2:"==";s:5:"value";s:5:"Video";}}}}', 'Video Link', 'video_link', 'publish', 'closed', 'closed', '', 'field_59d04bf21f0b2', '', '', '2017-10-01 02:00:08', '2017-10-01 02:00:08', '', 117, 'http://studiobarre-demo.com/?post_type=acf-field&p=120', 2, 'acf-field', '', 0),
(121, 1, '2017-10-01 02:00:08', '2017-10-01 02:00:08', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:44:"Image should be 590px wide by590px and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:250;s:10:"mime_types";s:3:"jpg";}', 'Mobile Slide', 'slide', 'publish', 'closed', 'closed', '', 'field_59d04bf21f0b3', '', '', '2017-10-01 02:00:08', '2017-10-01 02:00:08', '', 117, 'http://studiobarre-demo.com/?post_type=acf-field&p=121', 3, 'acf-field', '', 0),
(122, 1, '2017-10-01 02:01:10', '2017-10-01 02:01:10', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Desktop Slideshow', 'desktop_slideshow', 'publish', 'closed', 'closed', '', 'field_59d04c2b9263e', '', '', '2017-10-01 02:01:10', '2017-10-01 02:01:10', '', 97, 'http://studiobarre-demo.com/?post_type=acf-field&p=122', 0, 'acf-field', '', 0),
(123, 1, '2017-10-01 02:01:10', '2017-10-01 02:01:10', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Mobile Sections', '_copy', 'publish', 'closed', 'closed', '', 'field_59d04c419263f', '', '', '2017-10-01 02:01:10', '2017-10-01 02:01:10', '', 97, 'http://studiobarre-demo.com/?post_type=acf-field&p=123', 2, 'acf-field', '', 0),
(124, 1, '2017-10-01 02:02:07', '2017-10-01 02:02:07', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Homepage Content', '', 'publish', 'closed', 'closed', '', 'field_59d04c8a3c2d5', '', '', '2017-10-01 02:02:07', '2017-10-01 02:02:07', '', 97, 'http://studiobarre-demo.com/?post_type=acf-field&p=124', 4, 'acf-field', '', 0),
(125, 1, '2017-10-01 02:02:07', '2017-10-01 02:02:07', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;s:5:"delay";i:0;}', 'Homepage Content', 'homepage_content', 'publish', 'closed', 'closed', '', 'field_59d04c693c2d4', '', '', '2017-10-01 02:02:07', '2017-10-01 02:02:07', '', 97, 'http://studiobarre-demo.com/?post_type=acf-field&p=125', 5, 'acf-field', '', 0),
(126, 1, '2017-10-01 02:05:48', '2017-10-01 02:05:48', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 02:05:48', '2017-10-01 02:05:48', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(127, 1, '2017-10-01 02:26:49', '2017-10-01 02:26:49', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 02:26:49', '2017-10-01 02:26:49', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2017-10-01 02:52:57', '2017-10-01 02:52:57', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 02:52:57', '2017-10-01 02:52:57', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2017-10-01 04:22:49', '2017-10-01 04:22:49', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:22:49', '2017-10-01 04:22:49', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2017-10-01 04:26:34', '2017-10-01 04:26:34', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:26:34', '2017-10-01 04:26:34', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(131, 1, '2017-10-01 04:27:18', '2017-10-01 04:27:18', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:27:18', '2017-10-01 04:27:18', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2017-10-01 04:38:26', '2017-10-01 04:38:26', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:38:26', '2017-10-01 04:38:26', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(133, 1, '2017-10-01 04:40:15', '2017-10-01 04:40:15', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:40:15', '2017-10-01 04:40:15', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2017-10-01 04:41:27', '2017-10-01 04:41:27', '', 'Our Story', '', 'publish', 'closed', 'closed', '', 'our-story-2', '', '', '2017-10-01 05:07:33', '2017-10-01 05:07:33', '', 0, 'http://studiobarre-demo.com/?p=134', 5, 'nav_menu_item', '', 0),
(135, 1, '2017-10-01 04:41:51', '2017-10-01 04:41:51', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:41:51', '2017-10-01 04:41:51', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2017-10-01 04:42:02', '2017-10-01 04:42:02', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:42:02', '2017-10-01 04:42:02', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2017-10-01 04:47:09', '2017-10-01 04:47:09', '', 'Welcome To Studio Barre', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2017-10-01 04:47:09', '2017-10-01 04:47:09', '', 5, 'http://studiobarre-demo.com/blog/5-revision-v1/', 0, 'revision', '', 0),
(138, 1, '2017-10-01 04:52:28', '2017-10-01 04:52:28', '<h2 class="white">Stronger, Leaner, More Confident</h2>\r\n				\r\n				\r\n				<h2>What is Studio Barre?</h2>\r\n				\r\n				<p>Studio Barre {strength. defined.} is a specialized barre workout class that focuses on building core strength, improving posture and developing long and lean muscles, like those of a dancer.</p>\r\n				\r\n				<p>Former professional dancer and fitness expert Shannon Higgins founded Studio Barre in 2012. Our mission is to give every client a results-oriented, full-body sculpting workout that is fun, effective and sassy. Walk into any Studio Barre for a community-loving barre class and walk out stronger, leaner and more confident.</p>\r\n				\r\n				<h2>Get Stronger</h2>\r\n				\r\n				<p>Studio Barre applies the perfect combination of arm, seat, thigh and ab exercises to define and sculpt the body. The 60-minute workout digs deep physically while the music and happy barre{tenders} keep you mentally in the moment and push you toward your best.</p>\r\n				\r\n				<h2>Get Leaner</h2>\r\n				\r\n				<p>Come to class once and feel a difference; come to class 3-4 times per week for a month and you will see a difference! Showing up to the barre consistently and regularly will create lean, long and strong muscles we all love. Our clients are proof that Studio Barre works.</p>\r\n				\r\n				<h2>Gain More Confidence</h2>\r\n				\r\n				<p>We help you build strong shoulders, core and back to literally raise you up. Stand taller and present a more confident stature. As you gain more strength, meet your goals and make new friends, your inner confidence matches your exterior. When you feel good, you look good… happy!</p>', 'About Us', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2017-10-01 04:52:28', '2017-10-01 04:52:28', '', 38, 'http://studiobarre-demo.com/blog/38-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2017-10-01 04:57:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-10-01 04:57:58', '0000-00-00 00:00:00', '', 0, 'http://studiobarre-demo.com/?post_type=acf-field-group&p=139', 0, 'acf-field-group', '', 0),
(140, 1, '2017-10-01 05:00:54', '2017-10-01 05:00:54', 'a:7:{s:8:"location";a:4:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-about.php";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-maven.php";}}i:2;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:16:"page-society.php";}}i:3;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-mentor.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:7:"excerpt";i:1;s:14:"featured_image";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}', 'Inner Banners', 'inner-banners', 'publish', 'closed', 'closed', '', 'group_59d075ee3fe75', '', '', '2017-10-01 05:00:55', '2017-10-01 05:00:55', '', 0, 'http://studiobarre-demo.com/?post_type=acf-field-group&#038;p=140', 0, 'acf-field-group', '', 0),
(141, 1, '2017-10-01 05:00:55', '2017-10-01 05:00:55', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:52:"Images need to be 885px wide by 448px high and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:884;s:10:"min_height";i:447;s:8:"min_size";s:0:"";s:9:"max_width";i:886;s:10:"max_height";i:449;s:8:"max_size";i:250;s:10:"mime_types";s:3:"jpg";}', 'Inner Banners', 'inner_banners', 'publish', 'closed', 'closed', '', 'field_59d075f99a456', '', '', '2017-10-01 05:00:55', '2017-10-01 05:00:55', '', 140, 'http://studiobarre-demo.com/?post_type=acf-field&p=141', 0, 'acf-field', '', 0),
(142, 1, '2017-10-01 05:02:03', '2017-10-01 05:02:03', '', 'banner-ourstory', '', 'inherit', 'open', 'closed', '', 'banner-ourstory', '', '', '2017-10-01 05:02:03', '2017-10-01 05:02:03', '', 38, 'http://studiobarre-demo.com/wp-content/uploads/2017/07/banner-ourstory.jpg', 0, 'attachment', 'image/jpeg', 0),
(143, 1, '2017-10-01 05:02:10', '2017-10-01 05:02:10', '<h2 class="white">Stronger, Leaner, More Confident</h2>\r\n				\r\n				\r\n				<h2>What is Studio Barre?</h2>\r\n				\r\n				<p>Studio Barre {strength. defined.} is a specialized barre workout class that focuses on building core strength, improving posture and developing long and lean muscles, like those of a dancer.</p>\r\n				\r\n				<p>Former professional dancer and fitness expert Shannon Higgins founded Studio Barre in 2012. Our mission is to give every client a results-oriented, full-body sculpting workout that is fun, effective and sassy. Walk into any Studio Barre for a community-loving barre class and walk out stronger, leaner and more confident.</p>\r\n				\r\n				<h2>Get Stronger</h2>\r\n				\r\n				<p>Studio Barre applies the perfect combination of arm, seat, thigh and ab exercises to define and sculpt the body. The 60-minute workout digs deep physically while the music and happy barre{tenders} keep you mentally in the moment and push you toward your best.</p>\r\n				\r\n				<h2>Get Leaner</h2>\r\n				\r\n				<p>Come to class once and feel a difference; come to class 3-4 times per week for a month and you will see a difference! Showing up to the barre consistently and regularly will create lean, long and strong muscles we all love. Our clients are proof that Studio Barre works.</p>\r\n				\r\n				<h2>Gain More Confidence</h2>\r\n				\r\n				<p>We help you build strong shoulders, core and back to literally raise you up. Stand taller and present a more confident stature. As you gain more strength, meet your goals and make new friends, your inner confidence matches your exterior. When you feel good, you look good… happy!</p>', 'About Us', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2017-10-01 05:02:10', '2017-10-01 05:02:10', '', 38, 'http://studiobarre-demo.com/blog/38-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2017-10-01 05:03:22', '2017-10-01 05:03:22', '', 'banner-maven', '', 'inherit', 'open', 'closed', '', 'banner-maven', '', '', '2017-10-01 05:03:22', '2017-10-01 05:03:22', '', 80, 'http://studiobarre-demo.com/wp-content/uploads/2017/09/banner-maven.jpg', 0, 'attachment', 'image/jpeg', 0),
(145, 1, '2017-10-01 05:03:23', '2017-10-01 05:03:23', '', 'banner-mentor', '', 'inherit', 'open', 'closed', '', 'banner-mentor', '', '', '2017-10-01 05:03:23', '2017-10-01 05:03:23', '', 80, 'http://studiobarre-demo.com/wp-content/uploads/2017/09/banner-mentor.jpg', 0, 'attachment', 'image/jpeg', 0),
(146, 1, '2017-10-01 05:03:24', '2017-10-01 05:03:24', '', 'banner-society', '', 'inherit', 'open', 'closed', '', 'banner-society', '', '', '2017-10-01 05:03:24', '2017-10-01 05:03:24', '', 80, 'http://studiobarre-demo.com/wp-content/uploads/2017/09/banner-society.jpg', 0, 'attachment', 'image/jpeg', 0),
(147, 1, '2017-10-01 05:03:31', '2017-10-01 05:03:31', '', 'Barre Mavens', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2017-10-01 05:03:31', '2017-10-01 05:03:31', '', 80, 'http://studiobarre-demo.com/blog/80-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2017-10-01 05:04:40', '2017-10-01 05:04:40', '', 'The Society', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-10-01 05:04:40', '2017-10-01 05:04:40', '', 42, 'http://studiobarre-demo.com/blog/42-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2017-10-01 05:05:00', '2017-10-01 05:05:00', '', 'Mentors', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2017-10-01 05:05:00', '2017-10-01 05:05:00', '', 85, 'http://studiobarre-demo.com/blog/85-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_registration_log`
#

DROP TABLE IF EXISTS `wp_registration_log`;


#
# Table structure of table `wp_registration_log`
#

CREATE TABLE `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `IP` varchar(30) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_registration_log`
#
INSERT INTO `wp_registration_log` ( `ID`, `email`, `IP`, `blog_id`, `date_registered`) VALUES
(1, 'garrettcullen@yahoo.com', '1', 2, '2017-09-20 03:33:55'),
(2, 'garrettcullen@yahoo.com', '1', 3, '2017-09-26 03:12:18') ;

#
# End of data contents of table `wp_registration_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Corporate Newsletter Signup', '2017-07-24 04:24:57', 1, 0),
(2, 'Contact Us Form', '2017-08-22 04:54:11', 1, 0),
(3, 'Become a Maven', '2017-09-20 03:55:19', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Corporate Newsletter Signup","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"email","id":1,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.4.1","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"597576991242d":{"id":"597576991242d","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"59757699129c8":{"id":"59757699129c8","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"59757699129c8":{"id":"59757699129c8","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":94,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"597576991242d":{"id":"597576991242d","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(2, '{"title":"Contact Us Form","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":6,"label":"Phone","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","pageNumber":1,"displayOnly":""},{"type":"text","id":4,"label":"Which Studio\\/Location are you inquiring about?","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Comment","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.4.1","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"599bb8f316542":{"id":"599bb8f316542","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":94,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"599bb8f315fd3":{"id":"599bb8f315fd3","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(3, '{"title":"Become a Maven","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"Name (First and Last)","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Studio Barre Location","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":3,"label":"Social Media Handles","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":4,"label":"Tell Us Why You Love Studio Barre","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.4.1","id":3,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"59c1e6a75d9d6":{"id":"59c1e6a75d9d6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"59c1e6a75e031":{"id":"59c1e6a75e031","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"59c1e6a75e031":{"id":"59c1e6a75e031","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":94,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"59c1e6a75d9d6":{"id":"59c1e6a75d9d6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2017-07-24 04:26:39', '::1', 63),
(2, 1, '2017-08-06 20:34:41', '::1', 214),
(3, 1, '2017-08-08 04:34:19', '::1', 52),
(4, 1, '2017-08-22 03:16:51', '::1', 129),
(5, 2, '2017-08-22 05:07:34', '::1', 29),
(6, 1, '2017-08-23 03:44:58', '::1', 58),
(7, 1, '2017-09-19 03:03:22', '::1', 97),
(8, 1, '2017-09-20 03:14:47', '::1', 138),
(9, 2, '2017-09-20 04:15:20', '::1', 4),
(10, 3, '2017-09-20 04:27:19', '::1', 138),
(11, 1, '2017-09-21 03:15:03', '::1', 185),
(12, 3, '2017-09-21 04:27:23', '::1', 150),
(13, 2, '2017-09-21 06:06:26', '::1', 2),
(14, 1, '2017-09-22 03:16:26', '::1', 145),
(15, 3, '2017-09-22 04:30:04', '::1', 17),
(16, 3, '2017-09-23 17:29:33', '::1', 388),
(17, 1, '2017-09-23 17:29:33', '::1', 431),
(18, 2, '2017-09-23 19:32:43', '::1', 7),
(19, 1, '2017-09-24 20:26:26', '::1', 93),
(20, 2, '2017-09-24 20:38:29', '::1', 2),
(21, 3, '2017-09-25 00:31:27', '::1', 1),
(22, 1, '2017-09-26 02:49:35', '', 44),
(23, 3, '2017-09-26 02:50:51', '', 4),
(24, 2, '2017-09-26 02:53:47', '', 2),
(25, 1, '2017-09-27 03:09:50', '', 25),
(26, 1, '2017-09-28 03:30:56', '', 120),
(27, 3, '2017-09-28 04:08:22', '', 14),
(28, 2, '2017-09-28 13:48:32', '', 1),
(29, 1, '2017-09-30 18:36:55', '', 396),
(30, 3, '2017-10-01 02:22:48', '', 12) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_signups`
#

DROP TABLE IF EXISTS `wp_signups`;


#
# Table structure of table `wp_signups`
#

CREATE TABLE `wp_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `meta` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_signups`
#

#
# End of data contents of table `wp_signups`
# --------------------------------------------------------



#
# Delete any existing table `wp_simple_history`
#

DROP TABLE IF EXISTS `wp_simple_history`;


#
# Table structure of table `wp_simple_history`
#

CREATE TABLE `wp_simple_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `logger` varchar(30) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `occasionsID` varchar(32) DEFAULT NULL,
  `initiator` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `loggerdate` (`logger`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_simple_history`
#
INSERT INTO `wp_simple_history` ( `id`, `date`, `logger`, `level`, `message`, `occasionsID`, `initiator`) VALUES
(1, '2017-09-25 05:41:22', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '38759f6932185b9042c632241c4236bd', 'wp_user'),
(2, '2017-09-25 05:41:22', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1ad3dc78aa49c0ba94f3962a5078dae4', 'wp_user'),
(3, '2017-09-25 05:41:22', 'SimpleLogger', 'info', 'Because Simple History was just recently installed, this feed does not contain much events yet. But keep the plugin activated and soon you will see detailed information about page edits, plugin updates, user logins, and much more.', '1c6ed1ff4a97400596b011813faa932f', 'wp'),
(4, '2017-09-25 05:41:22', 'SimpleLogger', 'info', 'Welcome to Simple History!\n\nThis is the main history feed. It will contain events that this plugin has logged.', '0c4babaacbe315745cbb536eaa41278c', 'wp'),
(5, '2017-09-25 05:41:22', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '38759f6932185b9042c632241c4236bd', 'wp'),
(6, '2017-09-25 05:41:22', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1ad3dc78aa49c0ba94f3962a5078dae4', 'wp'),
(7, '2017-09-25 05:42:11', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', 'a1c5b46f18521a4d0e2dc171b802d6c8', 'wp_user'),
(8, '2017-09-25 05:42:11', 'AvailableUpdatesLogger', 'notice', 'Found an update to WordPress.', 'c9f1ea59833b705e3e0ca72170048a8a', 'wp'),
(9, '2017-09-25 05:42:12', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '2f92485afee26682f8b211bf1b52cbb4', 'wp'),
(10, '2017-09-25 05:42:12', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', 'dcaedae22a7a540b6815a1f2994a8963', 'wp'),
(11, '2017-09-25 05:42:12', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '289fdf9b23d220725e921f4e9db51209', 'wp'),
(12, '2017-09-25 05:42:12', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', 'd8ac2cdc8daf4558d2e30db443d3d947', 'wp'),
(13, '2017-09-25 05:42:12', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '5f0f65e950eb237e65aff8134b66812c', 'wp'),
(14, '2017-09-25 05:42:16', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '142a4f161ffd256acc42391b5e733655', 'wp_user'),
(15, '2017-09-25 05:43:46', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '46ee584d97bc915a945d0ffa0b56a49a', 'wp_user'),
(16, '2017-09-25 05:43:52', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '5ee5aabf470f6a9bd54be9a618e7f5e1', 'wp_user'),
(17, '2017-09-25 05:44:03', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '81bc795a9adbdf07e25ba362531401e5', 'wp_user'),
(18, '2017-09-25 05:44:07', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '57ce967d4d5323b69f4975051afaf022', 'wp_user'),
(19, '2017-09-25 05:44:14', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '258eede40bac0d8ee72ad7a1bd09a94b', 'wp_user'),
(20, '2017-09-25 05:44:22', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '2dc1bb446e3948d898c232b8e390f92f', 'wp_user'),
(21, '2017-09-25 05:44:37', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', 'ad1c4168c10fb425f5e47ebd2fb967a3', 'wp_user'),
(22, '2017-09-25 05:44:42', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1aebf2b55b308db16c6bd72fc0c797f0', 'wp_user'),
(23, '2017-09-25 05:44:54', 'SimplePluginLogger', 'info', 'Deactivated plugin "{plugin_name}"', '0944233235b7c78c7afd8db533cbf46d', 'wp_user'),
(24, '2017-09-26 02:45:24', 'SimpleUserLogger', 'info', 'Logged in', '45cbae66ecb78dc603ea33cd7ae694d6', 'wp_user'),
(25, '2017-09-26 03:32:54', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '6b60fa51188234fd559bc3451e313205', 'wp_user'),
(26, '2017-09-26 03:32:54', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user'),
(27, '2017-09-26 05:11:38', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '7f74c59dad544e251628ca4ac5cbce11', 'wp_user'),
(28, '2017-09-26 05:11:38', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user'),
(29, '2017-09-27 03:09:52', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '11a6b77b5d8218f9bda6317de317f28a', 'wp'),
(30, '2017-09-28 02:48:07', 'SimpleUserLogger', 'info', 'Logged in', '8e8b2264f860c047e613c180764b2d0b', 'wp_user'),
(31, '2017-09-28 03:43:11', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '44d6cc324655b1ae262d9a49ab8d3cae', 'wp_user'),
(32, '2017-09-28 05:31:58', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', 'e6a345a4cbaee934d276679f84987811', 'wp_user'),
(33, '2017-09-28 05:32:01', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '1c3c5174fec230aad8a44a88cfca2c72', 'wp_user'),
(34, '2017-09-28 13:46:16', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '788c9f5e320f7027638716b84f67f35a', 'wp'),
(35, '2017-09-30 18:26:26', 'SimpleUserLogger', 'info', 'Logged in', '8e8b2264f860c047e613c180764b2d0b', 'wp_user'),
(36, '2017-10-01 01:32:40', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '3f9c9583df363dc16ea2b55eef12c6d4', 'wp_user'),
(37, '2017-10-01 01:32:40', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '4477180f963d9188c386b56e6af6bea1', 'wp_user'),
(38, '2017-10-01 01:32:40', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '87fd8c7c33691d5abb28614b41cce92b', 'wp_user'),
(39, '2017-10-01 01:32:40', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'd07440c8c79fa08c15341d309751dd81', 'wp_user'),
(40, '2017-10-01 01:32:40', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(41, '2017-10-01 01:36:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(42, '2017-10-01 01:36:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0980d6a7cc797ec4e9a5872ca3d159b6', 'wp_user'),
(43, '2017-10-01 01:36:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'bd1b7bc3f6aae7d5e2fbbf00e33208c5', 'wp_user'),
(44, '2017-10-01 01:36:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(45, '2017-10-01 01:37:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(46, '2017-10-01 01:37:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'bd1b7bc3f6aae7d5e2fbbf00e33208c5', 'wp_user'),
(47, '2017-10-01 01:37:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'd07440c8c79fa08c15341d309751dd81', 'wp_user'),
(48, '2017-10-01 01:37:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '0980d6a7cc797ec4e9a5872ca3d159b6', 'wp_user'),
(49, '2017-10-01 01:37:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '87fd8c7c33691d5abb28614b41cce92b', 'wp_user'),
(50, '2017-10-01 01:37:12', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(51, '2017-10-01 01:39:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(52, '2017-10-01 01:39:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '87fd8c7c33691d5abb28614b41cce92b', 'wp_user'),
(53, '2017-10-01 01:39:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(54, '2017-10-01 01:41:30', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(55, '2017-10-01 01:41:30', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '836942553b3f21e81513fbef2aa412d5', 'wp_user'),
(56, '2017-10-01 01:41:30', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(57, '2017-10-01 01:48:26', 'SimpleMediaLogger', 'info', 'Deleted {post_type} "{attachment_title}" ("{attachment_filename}")', 'e1ad07d99a87595215c000ac1a6a6f92', 'wp_user'),
(58, '2017-10-01 01:49:54', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'ee241b32aee854284e5500787d76fce0', 'wp_user'),
(59, '2017-10-01 01:49:55', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '2cf6ebcaff4fcaa43921b15a08222a16', 'wp_user'),
(60, '2017-10-01 01:49:56', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '385b867024563adc204708c49da6e40b', 'wp_user'),
(61, '2017-10-01 01:49:57', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '7206a16026334d35e8bbbfc04451dc9f', 'wp_user'),
(62, '2017-10-01 01:49:58', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '4ef8a1a45b193097a633822d9a11d0c0', 'wp_user'),
(63, '2017-10-01 01:50:32', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '9b2c9433f9acf430971f278958d4e6c4', 'wp_user'),
(64, '2017-10-01 01:50:33', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '9e567bada0e739130240df3206d9822d', 'wp_user'),
(65, '2017-10-01 01:50:34', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'efdb1fad623d033933cae56b67e114c3', 'wp_user'),
(66, '2017-10-01 01:50:35', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'e2f3d27fae9d2e9d450b64ff1f551512', 'wp_user'),
(67, '2017-10-01 01:50:37', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '8757625e7652cfd9fd3d646191476e40', 'wp_user'),
(68, '2017-10-01 01:50:58', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(69, '2017-10-01 01:51:46', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(70, '2017-10-01 01:51:46', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'bd1b7bc3f6aae7d5e2fbbf00e33208c5', 'wp_user'),
(71, '2017-10-01 01:51:46', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'd07440c8c79fa08c15341d309751dd81', 'wp_user'),
(72, '2017-10-01 01:51:46', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(73, '2017-10-01 01:52:27', 'SimplePostLogger', 'info', 'Moved {post_type} "{post_title}" to the trash', 'd42b2147b15e515f9fbb5606ceb94ae2', 'wp_user'),
(74, '2017-10-01 01:53:07', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '2750c65d8d58744d7c5670c32ae9b815', 'wp_user'),
(75, '2017-10-01 01:53:07', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user'),
(76, '2017-10-01 01:58:55', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(77, '2017-10-01 01:58:55', 'SimplePostLogger', 'info', 'Deleted {post_type} "{post_title}"', '1aba5ffcd77fa567660cfa2c129a7cda', 'wp_user'),
(78, '2017-10-01 01:58:55', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(79, '2017-10-01 01:59:02', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(80, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(81, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '40db3c6ac9d1cdaf60a6c53e93d7c36f', 'wp_user'),
(82, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6ce82e313fb8a55c7c384ef66789fd51', 'wp_user'),
(83, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'adcc92bbbff38b73e1ceee2c987fafc8', 'wp_user'),
(84, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'ddfef4dec4b025bb04a5cd19c097be10', 'wp_user'),
(85, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c76c4340a4475c50fc77ebba2193f1c8', 'wp_user'),
(86, '2017-10-01 02:00:08', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(87, '2017-10-01 02:01:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(88, '2017-10-01 02:01:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'c2b0ce21971184664adedc20bb9c3d37', 'wp_user'),
(89, '2017-10-01 02:01:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '4477180f963d9188c386b56e6af6bea1', 'wp_user'),
(90, '2017-10-01 02:01:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'acd25b4a7bd18fd6538025ead5d45d0f', 'wp_user'),
(91, '2017-10-01 02:01:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '40db3c6ac9d1cdaf60a6c53e93d7c36f', 'wp_user'),
(92, '2017-10-01 02:01:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(93, '2017-10-01 02:02:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(94, '2017-10-01 02:02:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '55bf060fceaca04422da5854eac0f5bf', 'wp_user'),
(95, '2017-10-01 02:02:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'f7466f5018e49fc0cb14c43da50d7d6b', 'wp_user'),
(96, '2017-10-01 02:02:07', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(97, '2017-10-01 02:05:48', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(98, '2017-10-01 02:26:49', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(99, '2017-10-01 02:52:57', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(100, '2017-10-01 04:22:49', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user') ;
INSERT INTO `wp_simple_history` ( `id`, `date`, `logger`, `level`, `message`, `occasionsID`, `initiator`) VALUES
(101, '2017-10-01 04:26:34', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(102, '2017-10-01 04:27:18', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(103, '2017-10-01 04:38:26', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(104, '2017-10-01 04:40:15', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(105, '2017-10-01 04:40:44', 'SimplePostLogger', 'info', 'Restored {post_type} "{post_title}" from trash', 'deab5a634669af177e639d6c58cd8c51', 'wp_user'),
(106, '2017-10-01 04:40:44', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9a385f036af3eb8d163507736afd6461', 'wp_user'),
(107, '2017-10-01 04:40:54', 'SimplePostLogger', 'info', 'Moved {post_type} "{post_title}" to the trash', '940ebe34dee8098c87bfeab86c31ab05', 'wp_user'),
(108, '2017-10-01 04:41:27', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '2750c65d8d58744d7c5670c32ae9b815', 'wp_user'),
(109, '2017-10-01 04:41:27', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user'),
(110, '2017-10-01 04:41:51', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(111, '2017-10-01 04:42:02', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(112, '2017-10-01 04:47:09', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9d6d35886878d39d0da3c395dff05e08', 'wp_user'),
(113, '2017-10-01 04:52:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9a385f036af3eb8d163507736afd6461', 'wp_user'),
(114, '2017-10-01 04:55:27', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(115, '2017-10-01 04:55:27', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'bd1b7bc3f6aae7d5e2fbbf00e33208c5', 'wp_user'),
(116, '2017-10-01 04:55:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(117, '2017-10-01 04:58:18', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(118, '2017-10-01 04:58:18', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a8c4fedfd15829bf653f3246b6969357', 'wp_user'),
(119, '2017-10-01 05:00:55', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '54f5c6104ed2ad3668cb5916c8f4a463', 'wp_user'),
(120, '2017-10-01 05:00:55', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '8bafdbe8fe14b05a7853c63bfbdf5989', 'wp_user'),
(121, '2017-10-01 05:00:55', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '8faadc9db746bbda2fbc1dfe970db427', 'wp_user'),
(122, '2017-10-01 05:02:03', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'ff4a2db78f7d0e2d0464e9a98c3e7357', 'wp_user'),
(123, '2017-10-01 05:02:10', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '9a385f036af3eb8d163507736afd6461', 'wp_user'),
(124, '2017-10-01 05:03:22', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'eca4f8b09a8f5e184fab798341cafd3c', 'wp_user'),
(125, '2017-10-01 05:03:23', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'b86702fd182456da27cd5771b689c6a6', 'wp_user'),
(126, '2017-10-01 05:03:24', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '732b8b32691e32977bf1a99c07b59869', 'wp_user'),
(127, '2017-10-01 05:03:31', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '78016c31b4b16a2d052c0ee53e64730c', 'wp_user'),
(128, '2017-10-01 05:04:40', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'e7d7e7a0cba1ab50848316f5ec41b799', 'wp_user'),
(129, '2017-10-01 05:05:00', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '13488aa93a8e1526192d06eb114d7e7d', 'wp_user'),
(130, '2017-10-01 05:07:33', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '6b60fa51188234fd559bc3451e313205', 'wp_user'),
(131, '2017-10-01 05:07:33', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '86bfc4c75650b6a585784366223571a7', 'wp_user') ;

#
# End of data contents of table `wp_simple_history`
# --------------------------------------------------------



#
# Delete any existing table `wp_simple_history_contexts`
#

DROP TABLE IF EXISTS `wp_simple_history_contexts`;


#
# Table structure of table `wp_simple_history_contexts`
#

CREATE TABLE `wp_simple_history_contexts` (
  `context_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `history_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` longtext,
  PRIMARY KEY (`context_id`),
  KEY `history_id` (`history_id`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=1386 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_simple_history_contexts`
#
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1, 1, 'plugin_name', 'Simple History'),
(2, 1, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(3, 1, 'plugin_url', 'http://simple-history.com'),
(4, 1, 'plugin_version', '2.18'),
(5, 1, 'plugin_author', 'Pär Thernström'),
(6, 1, '_message_key', 'plugin_installed'),
(7, 1, '_user_id', '1'),
(8, 1, '_user_login', 'destroyer'),
(9, 1, '_user_email', 'garrettcullen@yahoo.com'),
(10, 1, '_server_remote_addr', '::1'),
(11, 1, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=simple+history&tab=search&type=term'),
(12, 2, 'plugin_name', 'Simple History'),
(13, 2, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(14, 2, 'plugin_url', 'http://simple-history.com'),
(15, 2, 'plugin_version', '2.18'),
(16, 2, 'plugin_author', 'Pär Thernström'),
(17, 2, 'plugin_slug', 'simple-history'),
(18, 2, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(19, 2, '_message_key', 'plugin_activated'),
(20, 2, '_user_id', '1'),
(21, 2, '_user_login', 'destroyer'),
(22, 2, '_user_email', 'garrettcullen@yahoo.com'),
(23, 2, '_server_remote_addr', '::1'),
(24, 2, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=simple+history&tab=search&type=term'),
(25, 3, '_user_id', '1'),
(26, 3, '_user_login', 'destroyer'),
(27, 3, '_user_email', 'garrettcullen@yahoo.com'),
(28, 3, '_server_remote_addr', '::1'),
(29, 3, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=simple+history&tab=search&type=term'),
(30, 4, '_user_id', '1'),
(31, 4, '_user_login', 'destroyer'),
(32, 4, '_user_email', 'garrettcullen@yahoo.com'),
(33, 4, '_server_remote_addr', '::1'),
(34, 4, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=simple+history&tab=search&type=term'),
(35, 5, 'plugin_name', 'Simple History'),
(36, 5, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(37, 5, 'plugin_url', 'http://simple-history.com'),
(38, 5, 'plugin_version', '2.18'),
(39, 5, 'plugin_author', 'Pär Thernström'),
(40, 5, '_message_key', 'plugin_installed'),
(41, 5, '_wp_cron_running', 'true'),
(42, 5, '_server_remote_addr', '::1'),
(43, 5, '_server_http_referer', 'http://studiobarre-demo.com/wp-cron.php?doing_wp_cron=1506318082.3260231018066406250000'),
(44, 6, 'plugin_name', 'Simple History'),
(45, 6, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(46, 6, 'plugin_url', 'http://simple-history.com'),
(47, 6, 'plugin_version', '2.18'),
(48, 6, 'plugin_author', 'Pär Thernström'),
(49, 6, 'plugin_slug', 'simple-history'),
(50, 6, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(51, 6, '_message_key', 'plugin_activated'),
(52, 6, '_wp_cron_running', 'true'),
(53, 6, '_server_remote_addr', '::1'),
(54, 6, '_server_http_referer', 'http://studiobarre-demo.com/wp-cron.php?doing_wp_cron=1506318082.3260231018066406250000'),
(55, 7, 'plugin_slug', 'media-library-assistant'),
(56, 7, 'plugin_name', 'Media Library Assistant'),
(57, 7, 'plugin_version', '2.60'),
(58, 7, 'plugin_author', 'David Lingren, Fair Trade Judaica'),
(59, 7, 'plugin_last_updated', ''),
(60, 7, 'plugin_requires', ''),
(61, 7, 'plugin_tested', ''),
(62, 7, 'plugin_rating', ''),
(63, 7, 'plugin_num_ratings', ''),
(64, 7, 'plugin_downloaded', ''),
(65, 7, 'plugin_added', ''),
(66, 7, 'plugin_source_files', '["css","examples","images","includes","index.php","js","languages","license.txt","mla-uninstall.php","phpDocs","readme.txt","tests","tpls","wpml-config.xml"]'),
(67, 7, 'plugin_install_source', 'unknown'),
(68, 7, 'plugin_description', 'Enhances the Media Library; powerful [mla_gallery] [mla_tag_cloud] [mla_term_list], taxonomy support, IPTC/EXIF/XMP/PDF processing, bulk/quick edit. <cite>By <a href="http://fairtradejudaica.org/our-story/staff/">David Lingren, Fair Trade Judaica</a>.</cite>'),
(69, 7, 'plugin_url', 'http://fairtradejudaica.org/media-library-assistant-a-wordpress-plugin/'),
(70, 7, '_message_key', 'plugin_installed'),
(71, 7, '_user_id', '1'),
(72, 7, '_user_login', 'destroyer'),
(73, 7, '_user_email', 'garrettcullen@yahoo.com'),
(74, 7, '_server_remote_addr', '::1'),
(75, 7, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(76, 8, 'wp_core_current_version', '4.8.1'),
(77, 8, 'wp_core_new_version', '4.8.2'),
(78, 8, '_message_key', 'core_update_available'),
(79, 8, '_user_id', '1'),
(80, 8, '_user_login', 'destroyer'),
(81, 8, '_user_email', 'garrettcullen@yahoo.com'),
(82, 8, '_server_remote_addr', '::1'),
(83, 8, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(84, 9, 'plugin_name', 'WP Migrate DB Pro'),
(85, 9, 'plugin_current_version', '1.7.2'),
(86, 9, 'plugin_new_version', '1.8'),
(87, 9, '_message_key', 'plugin_update_available'),
(88, 9, '_user_id', '1'),
(89, 9, '_user_login', 'destroyer'),
(90, 9, '_user_email', 'garrettcullen@yahoo.com'),
(91, 9, '_server_remote_addr', '::1'),
(92, 9, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(93, 10, 'plugin_name', 'Gravity Forms'),
(94, 10, 'plugin_current_version', '2.2.4.1'),
(95, 10, 'plugin_new_version', '2.2.5'),
(96, 10, '_message_key', 'plugin_update_available'),
(97, 10, '_user_id', '1'),
(98, 10, '_user_login', 'destroyer'),
(99, 10, '_user_email', 'garrettcullen@yahoo.com'),
(100, 10, '_server_remote_addr', '::1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(101, 10, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(102, 11, 'plugin_name', 'Advanced Custom Fields PRO'),
(103, 11, 'plugin_current_version', '5.6.1'),
(104, 11, 'plugin_new_version', '5.6.2'),
(105, 11, '_message_key', 'plugin_update_available'),
(106, 11, '_user_id', '1'),
(107, 11, '_user_login', 'destroyer'),
(108, 11, '_user_email', 'garrettcullen@yahoo.com'),
(109, 11, '_server_remote_addr', '::1'),
(110, 11, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(111, 12, 'plugin_name', 'Advanced Custom Fields: Theme Code Pro'),
(112, 12, 'plugin_current_version', '1.2.0'),
(113, 12, 'plugin_new_version', '2.1.0'),
(114, 12, '_message_key', 'plugin_update_available'),
(115, 12, '_user_id', '1'),
(116, 12, '_user_login', 'destroyer'),
(117, 12, '_user_email', 'garrettcullen@yahoo.com'),
(118, 12, '_server_remote_addr', '::1'),
(119, 12, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(120, 13, 'plugin_name', 'Akismet Anti-Spam'),
(121, 13, 'plugin_current_version', '3.3.4'),
(122, 13, 'plugin_new_version', '4.0'),
(123, 13, '_message_key', 'plugin_update_available'),
(124, 13, '_user_id', '1'),
(125, 13, '_user_login', 'destroyer'),
(126, 13, '_user_email', 'garrettcullen@yahoo.com'),
(127, 13, '_server_remote_addr', '::1'),
(128, 13, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(129, 14, 'plugin_name', 'Media Library Assistant'),
(130, 14, 'plugin_slug', 'media-library-assistant'),
(131, 14, 'plugin_title', '<a href="http://fairtradejudaica.org/media-library-assistant-a-wordpress-plugin/">Media Library Assistant</a>'),
(132, 14, 'plugin_description', 'Enhances the Media Library; powerful [mla_gallery] [mla_tag_cloud] [mla_term_list], taxonomy support, IPTC/EXIF/XMP/PDF processing, bulk/quick edit. <cite>By <a href="http://fairtradejudaica.org/our-story/staff/">David Lingren, Fair Trade Judaica</a>.</cite>'),
(133, 14, 'plugin_author', '<a href="http://fairtradejudaica.org/our-story/staff/">David Lingren, Fair Trade Judaica</a>'),
(134, 14, 'plugin_version', '2.60'),
(135, 14, 'plugin_url', 'http://fairtradejudaica.org/media-library-assistant-a-wordpress-plugin/'),
(136, 14, '_message_key', 'plugin_activated'),
(137, 14, '_user_id', '1'),
(138, 14, '_user_login', 'destroyer'),
(139, 14, '_user_email', 'garrettcullen@yahoo.com'),
(140, 14, '_server_remote_addr', '::1'),
(141, 14, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=Media+Library+Assistant&tab=search&type=term'),
(142, 15, 'plugin_slug', 'multisite-clone-duplicator'),
(143, 15, 'plugin_name', 'MultiSite Clone Duplicator'),
(144, 15, 'plugin_version', '1.4.1'),
(145, 15, 'plugin_author', 'Julien OGER, Pierre DARGHAM, David DAUGREILH, GLOBALIS media systems'),
(146, 15, 'plugin_last_updated', ''),
(147, 15, 'plugin_requires', ''),
(148, 15, 'plugin_tested', ''),
(149, 15, 'plugin_rating', ''),
(150, 15, 'plugin_num_ratings', ''),
(151, 15, 'plugin_downloaded', ''),
(152, 15, 'plugin_added', ''),
(153, 15, 'plugin_source_files', '["css","include","js","language","lib","logs","multisite-clone-duplicator.php","README.md","readme.txt","screenshot-1.png","screenshot-2.png","screenshot-3.png","screenshot-4.png","screenshot-5.png","template","wp-cli"]'),
(154, 15, 'plugin_install_source', 'unknown'),
(155, 15, 'plugin_description', 'Clones an existing site into a new one in a multisite installation : copies all the posts, settings and files <cite>By <a href="https://github.com/pierre-dargham/multisite-clone-duplicator">Julien OGER, Pierre DARGHAM, David DAUGREILH, GLOBALIS media systems</a>.</cite>'),
(156, 15, 'plugin_url', 'http://wordpress.org/plugins/multisite-clone-duplicator/'),
(157, 15, '_message_key', 'plugin_installed'),
(158, 15, '_user_id', '1'),
(159, 15, '_user_login', 'destroyer'),
(160, 15, '_user_email', 'garrettcullen@yahoo.com'),
(161, 15, '_server_remote_addr', '::1'),
(162, 15, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=MultiSite+Clone+Duplicator&tab=search&type=term'),
(163, 16, 'plugin_name', 'MultiSite Clone Duplicator'),
(164, 16, 'plugin_slug', 'multisite-clone-duplicator'),
(165, 16, 'plugin_title', '<a href="http://wordpress.org/plugins/multisite-clone-duplicator/">MultiSite Clone Duplicator</a>'),
(166, 16, 'plugin_description', 'Clones an existing site into a new one in a multisite installation : copies all the posts, settings and files <cite>By <a href="https://github.com/pierre-dargham/multisite-clone-duplicator">Julien OGER, Pierre DARGHAM, David DAUGREILH, GLOBALIS media systems</a>.</cite>'),
(167, 16, 'plugin_author', '<a href="https://github.com/pierre-dargham/multisite-clone-duplicator">Julien OGER, Pierre DARGHAM, David DAUGREILH, GLOBALIS media systems</a>'),
(168, 16, 'plugin_version', '1.4.1'),
(169, 16, 'plugin_url', 'http://wordpress.org/plugins/multisite-clone-duplicator/'),
(170, 16, '_message_key', 'plugin_activated'),
(171, 16, '_user_id', '1'),
(172, 16, '_user_login', 'destroyer'),
(173, 16, '_user_email', 'garrettcullen@yahoo.com'),
(174, 16, '_server_remote_addr', '::1'),
(175, 16, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=MultiSite+Clone+Duplicator&tab=search&type=term'),
(176, 17, 'plugin_slug', 'advanced-custom-fields-pro'),
(177, 17, 'plugin_name', 'Advanced Custom Fields PRO'),
(178, 17, 'plugin_title', '<a href="https://www.advancedcustomfields.com/">Advanced Custom Fields PRO</a>'),
(179, 17, 'plugin_description', 'Customise WordPress with powerful, professional and intuitive fields. <cite>By <a href="http://www.elliotcondon.com/">Elliot Condon</a>.</cite>'),
(180, 17, 'plugin_author', '<a href="http://www.elliotcondon.com/">Elliot Condon</a>'),
(181, 17, 'plugin_version', '5.6.2'),
(182, 17, 'plugin_url', 'https://www.advancedcustomfields.com/'),
(183, 17, 'plugin_prev_version', '5.6.1'),
(184, 17, '_message_key', 'plugin_bulk_updated'),
(185, 17, '_user_id', '1'),
(186, 17, '_user_login', 'destroyer'),
(187, 17, '_user_email', 'garrettcullen@yahoo.com'),
(188, 17, '_server_remote_addr', '::1'),
(189, 17, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugins.php?plugin_status=all&paged=1&s'),
(190, 18, 'plugin_slug', 'akismet'),
(191, 18, 'plugin_name', 'Akismet Anti-Spam'),
(192, 18, 'plugin_title', '<a href="https://akismet.com/">Akismet Anti-Spam</a>'),
(193, 18, 'plugin_description', 'Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key. <cite>By <a href="https://automattic.com/wordpress-plugins/">Automattic</a>.</cite>'),
(194, 18, 'plugin_author', '<a href="https://automattic.com/wordpress-plugins/">Automattic</a>'),
(195, 18, 'plugin_version', '4.0'),
(196, 18, 'plugin_url', 'https://akismet.com/'),
(197, 18, 'plugin_prev_version', '3.3.4'),
(198, 18, '_message_key', 'plugin_bulk_updated'),
(199, 18, '_user_id', '1'),
(200, 18, '_user_login', 'destroyer') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(201, 18, '_user_email', 'garrettcullen@yahoo.com'),
(202, 18, '_server_remote_addr', '::1'),
(203, 18, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugins.php?plugin_status=all&paged=1&s'),
(204, 19, 'plugin_slug', 'gravityforms'),
(205, 19, 'plugin_name', 'Gravity Forms'),
(206, 19, 'plugin_title', '<a href="http://www.gravityforms.com">Gravity Forms</a>'),
(207, 19, 'plugin_description', 'Easily create web forms and manage form entries within the WordPress admin. <cite>By <a href="http://www.rocketgenius.com">rocketgenius</a>.</cite>'),
(208, 19, 'plugin_author', '<a href="http://www.rocketgenius.com">rocketgenius</a>'),
(209, 19, 'plugin_version', '2.2.5'),
(210, 19, 'plugin_url', 'http://www.gravityforms.com'),
(211, 19, 'plugin_update_info_plugin', 'gravityforms/gravityforms.php'),
(212, 19, 'plugin_update_info_package', 'http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1506457453&Signature=H9Zhz4yRt75eEGrr3ATgKeYJRTI%3D'),
(213, 19, 'plugin_prev_version', '2.2.4.1'),
(214, 19, '_message_key', 'plugin_bulk_updated'),
(215, 19, '_user_id', '1'),
(216, 19, '_user_login', 'destroyer'),
(217, 19, '_user_email', 'garrettcullen@yahoo.com'),
(218, 19, '_server_remote_addr', '::1'),
(219, 19, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugins.php?plugin_status=all&paged=1&s'),
(220, 20, 'plugin_slug', 'wp-migrate-db-pro'),
(221, 20, 'plugin_name', 'WP Migrate DB Pro'),
(222, 20, 'plugin_title', '<a href="http://deliciousbrains.com/wp-migrate-db-pro/">WP Migrate DB Pro</a>'),
(223, 20, 'plugin_description', 'Export, push, and pull to migrate your WordPress databases. <cite>By <a href="http://deliciousbrains.com">Delicious Brains</a>.</cite>'),
(224, 20, 'plugin_author', '<a href="http://deliciousbrains.com">Delicious Brains</a>'),
(225, 20, 'plugin_version', '1.8'),
(226, 20, 'plugin_url', 'http://deliciousbrains.com/wp-migrate-db-pro/'),
(227, 20, 'plugin_update_info_plugin', 'wp-migrate-db-pro/wp-migrate-db-pro.php'),
(228, 20, 'plugin_update_info_package', 'https://api.deliciousbrains.com/?wc-api=delicious-brains&request=download&licence_key=59dc13dd-1ccf-46fe-b573-fe88cf5e873a&slug=wp-migrate-db-pro&site_url=http://studiobarre-demo.com'),
(229, 20, 'plugin_prev_version', '1.7.2'),
(230, 20, '_message_key', 'plugin_bulk_updated'),
(231, 20, '_user_id', '1'),
(232, 20, '_user_login', 'destroyer'),
(233, 20, '_user_email', 'garrettcullen@yahoo.com'),
(234, 20, '_server_remote_addr', '::1'),
(235, 20, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugins.php?plugin_status=all&paged=1&s'),
(236, 21, 'plugin_slug', 'better-wp-security'),
(237, 21, 'plugin_name', 'iThemes Security'),
(238, 21, 'plugin_version', '6.6.1'),
(239, 21, 'plugin_author', 'iThemes'),
(240, 21, 'plugin_last_updated', ''),
(241, 21, 'plugin_requires', ''),
(242, 21, 'plugin_tested', ''),
(243, 21, 'plugin_rating', ''),
(244, 21, 'plugin_num_ratings', ''),
(245, 21, 'plugin_downloaded', ''),
(246, 21, 'plugin_added', ''),
(247, 21, 'plugin_source_files', '["better-wp-security.php","core","history.txt","index.php","lib","readme.txt"]'),
(248, 21, 'plugin_install_source', 'unknown'),
(249, 21, 'plugin_description', 'Take the guesswork out of WordPress security. iThemes Security offers 30+ ways to lock down WordPress in an easy-to-use WordPress security plugin. <cite>By <a href="https://ithemes.com">iThemes</a>.</cite>'),
(250, 21, 'plugin_url', 'https://ithemes.com/security'),
(251, 21, '_message_key', 'plugin_installed'),
(252, 21, '_user_id', '1'),
(253, 21, '_user_login', 'destroyer'),
(254, 21, '_user_email', 'garrettcullen@yahoo.com'),
(255, 21, '_server_remote_addr', '::1'),
(256, 21, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=ithemes&tab=search&type=term'),
(257, 22, 'plugin_name', 'iThemes Security'),
(258, 22, 'plugin_slug', 'better-wp-security'),
(259, 22, 'plugin_title', '<a href="https://ithemes.com/security">iThemes Security</a>'),
(260, 22, 'plugin_description', 'Take the guesswork out of WordPress security. iThemes Security offers 30+ ways to lock down WordPress in an easy-to-use WordPress security plugin. <cite>By <a href="https://ithemes.com">iThemes</a>.</cite>'),
(261, 22, 'plugin_author', '<a href="https://ithemes.com">iThemes</a>'),
(262, 22, 'plugin_version', '6.6.1'),
(263, 22, 'plugin_url', 'https://ithemes.com/security'),
(264, 22, '_message_key', 'plugin_activated'),
(265, 22, '_user_id', '1'),
(266, 22, '_user_login', 'destroyer'),
(267, 22, '_user_email', 'garrettcullen@yahoo.com'),
(268, 22, '_server_remote_addr', '::1'),
(269, 22, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugin-install.php?s=ithemes&tab=search&type=term'),
(270, 23, 'plugin_name', 'iThemes Security'),
(271, 23, 'plugin_slug', 'better-wp-security'),
(272, 23, 'plugin_title', '<a href="https://ithemes.com/security">iThemes Security</a>'),
(273, 23, 'plugin_description', 'Take the guesswork out of WordPress security. iThemes Security offers 30+ ways to lock down WordPress in an easy-to-use WordPress security plugin. <cite>By <a href="https://ithemes.com">iThemes</a>.</cite>'),
(274, 23, 'plugin_author', '<a href="https://ithemes.com">iThemes</a>'),
(275, 23, 'plugin_version', '6.6.1'),
(276, 23, 'plugin_url', 'https://ithemes.com/security'),
(277, 23, '_message_key', 'plugin_deactivated'),
(278, 23, '_user_id', '1'),
(279, 23, '_user_login', 'destroyer'),
(280, 23, '_user_email', 'garrettcullen@yahoo.com'),
(281, 23, '_server_remote_addr', '::1'),
(282, 23, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/plugins.php?plugin_status=all&paged=1&s'),
(283, 24, 'user_id', '1'),
(284, 24, 'user_email', 'garrettcullen@yahoo.com'),
(285, 24, 'user_login', 'destroyer'),
(286, 24, '_user_id', '1'),
(287, 24, '_user_login', 'destroyer'),
(288, 24, '_user_email', 'garrettcullen@yahoo.com'),
(289, 24, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'),
(290, 24, '_message_key', 'user_logged_in'),
(291, 24, '_server_remote_addr', '::1'),
(292, 24, '_server_http_referer', 'http://studiobarre-demo.com/wp-login.php?redirect_to=http%3A%2F%2Fstudiobarre-demo.com%2Fwp-admin%2F&reauth=1'),
(293, 25, 'menu_id', '2'),
(294, 25, 'menu_name', 'Top Nav'),
(295, 25, 'menu_items_added', '0'),
(296, 25, 'menu_items_removed', '0'),
(297, 25, '_message_key', 'edited_menu'),
(298, 25, '_user_id', '1'),
(299, 25, '_user_login', 'destroyer'),
(300, 25, '_user_email', 'garrettcullen@yahoo.com') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(301, 25, '_server_remote_addr', '::1'),
(302, 25, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(303, 26, 'term_id', '2'),
(304, 26, 'from_term_name', 'Top Nav'),
(305, 26, 'from_term_taxonomy', 'nav_menu'),
(306, 26, 'from_term_slug', 'top-nav'),
(307, 26, 'from_term_description', ''),
(308, 26, 'to_term_name', 'Top Nav'),
(309, 26, 'to_term_taxonomy', 'nav_menu'),
(310, 26, 'to_term_slug', 'null'),
(311, 26, 'to_term_description', ''),
(312, 26, '_message_key', 'edited_term'),
(313, 26, '_user_id', '1'),
(314, 26, '_user_login', 'destroyer'),
(315, 26, '_user_email', 'garrettcullen@yahoo.com'),
(316, 26, '_server_remote_addr', '::1'),
(317, 26, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(318, 27, 'menu_id', '2'),
(319, 27, 'menu_name', 'Top Nav'),
(320, 27, 'menu_items_added', '0'),
(321, 27, 'menu_items_removed', '1'),
(322, 27, '_message_key', 'edited_menu'),
(323, 27, '_user_id', '1'),
(324, 27, '_user_login', 'destroyer'),
(325, 27, '_user_email', 'garrettcullen@yahoo.com'),
(326, 27, '_server_remote_addr', '::1'),
(327, 27, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(328, 28, 'term_id', '2'),
(329, 28, 'from_term_name', 'Top Nav'),
(330, 28, 'from_term_taxonomy', 'nav_menu'),
(331, 28, 'from_term_slug', 'top-nav'),
(332, 28, 'from_term_description', ''),
(333, 28, 'to_term_name', 'Top Nav'),
(334, 28, 'to_term_taxonomy', 'nav_menu'),
(335, 28, 'to_term_slug', 'null'),
(336, 28, 'to_term_description', ''),
(337, 28, '_message_key', 'edited_term'),
(338, 28, '_user_id', '1'),
(339, 28, '_user_login', 'destroyer'),
(340, 28, '_user_email', 'garrettcullen@yahoo.com'),
(341, 28, '_server_remote_addr', '::1'),
(342, 28, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(343, 29, 'plugin_name', 'Yoast SEO'),
(344, 29, 'plugin_current_version', '5.4.2'),
(345, 29, 'plugin_new_version', '5.5'),
(346, 29, '_message_key', 'plugin_update_available'),
(347, 29, '_server_remote_addr', '::1'),
(348, 29, '_server_http_referer', 'http://studiobarre-demo.com/wp-cron.php?doing_wp_cron=1506481789.4699869155883789062500'),
(349, 30, 'user_id', '1'),
(350, 30, 'user_email', 'garrettcullen@yahoo.com'),
(351, 30, 'user_login', 'destroyer'),
(352, 30, '_user_id', '1'),
(353, 30, '_user_login', 'destroyer'),
(354, 30, '_user_email', 'garrettcullen@yahoo.com'),
(355, 30, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'),
(356, 30, '_message_key', 'user_logged_in'),
(357, 30, '_server_remote_addr', '::1'),
(358, 30, '_server_http_referer', 'http://studiobarre-demo.com/wp-login.php?redirect_to=http%3A%2F%2Fstudiobarre-demo.com%2Fwp-admin%2F&reauth=1'),
(359, 31, 'post_id', '8'),
(360, 31, 'post_type', 'page'),
(361, 31, 'post_title', 'Find Your Studio'),
(362, 31, 'post_prev_page_template', 'default'),
(363, 31, 'post_new_page_template', 'page-locations.php'),
(364, 31, 'post_new_page_template_name', 'Locations'),
(365, 31, '_message_key', 'post_updated'),
(366, 31, '_user_id', '1'),
(367, 31, '_user_login', 'destroyer'),
(368, 31, '_user_email', 'garrettcullen@yahoo.com'),
(369, 31, '_server_remote_addr', '::1'),
(370, 31, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=8&action=edit'),
(371, 32, 'plugin_slug', 'wp-migrate-db-pro-media-files'),
(372, 32, 'plugin_name', 'WP Migrate DB Pro Media Files'),
(373, 32, 'plugin_version', '1.4.8'),
(374, 32, 'plugin_author', 'Delicious Brains'),
(375, 32, 'plugin_last_updated', ''),
(376, 32, 'plugin_requires', ''),
(377, 32, 'plugin_tested', '4.8.2'),
(378, 32, 'plugin_rating', ''),
(379, 32, 'plugin_num_ratings', ''),
(380, 32, 'plugin_downloaded', ''),
(381, 32, 'plugin_added', ''),
(382, 32, 'plugin_source_files', '["asset","class","languages","template","version.php","wp-migrate-db-pro-media-files.php"]'),
(383, 32, 'plugin_install_source', 'web'),
(384, 32, 'plugin_description', 'An extension to WP Migrate DB Pro, allows the migration of media files. <cite>By <a href="http://deliciousbrains.com">Delicious Brains</a>.</cite>'),
(385, 32, 'plugin_url', 'http://deliciousbrains.com/wp-migrate-db-pro/'),
(386, 32, '_message_key', 'plugin_installed'),
(387, 32, '_user_id', '1'),
(388, 32, '_user_login', 'destroyer'),
(389, 32, '_user_email', 'garrettcullen@yahoo.com'),
(390, 32, '_server_remote_addr', '::1'),
(391, 32, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/settings.php?page=wp-migrate-db-pro'),
(392, 33, 'plugin_name', 'WP Migrate DB Pro Media Files'),
(393, 33, 'plugin_slug', 'wp-migrate-db-pro-media-files'),
(394, 33, 'plugin_title', '<a href="http://deliciousbrains.com/wp-migrate-db-pro/">WP Migrate DB Pro Media Files</a>'),
(395, 33, 'plugin_description', 'An extension to WP Migrate DB Pro, allows the migration of media files. <cite>By <a href="http://deliciousbrains.com">Delicious Brains</a>.</cite>'),
(396, 33, 'plugin_author', '<a href="http://deliciousbrains.com">Delicious Brains</a>'),
(397, 33, 'plugin_version', '1.4.8'),
(398, 33, 'plugin_url', 'http://deliciousbrains.com/wp-migrate-db-pro/'),
(399, 33, '_message_key', 'plugin_activated'),
(400, 33, '_user_id', '1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(401, 33, '_user_login', 'destroyer'),
(402, 33, '_user_email', 'garrettcullen@yahoo.com'),
(403, 33, '_server_remote_addr', '::1'),
(404, 33, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/network/update.php?action=install-plugin&plugin=wp-migrate-db-pro-media-files&_wpnonce=7b81df4791'),
(405, 34, 'plugin_name', 'Yoast SEO'),
(406, 34, 'plugin_current_version', '5.4.2'),
(407, 34, 'plugin_new_version', '5.5.1'),
(408, 34, '_message_key', 'plugin_update_available'),
(409, 34, '_server_remote_addr', '::1'),
(410, 34, '_server_http_referer', 'http://studiobarre-demo.com/wp-cron.php?doing_wp_cron=1506606374.0210990905761718750000'),
(411, 35, 'user_id', '1'),
(412, 35, 'user_email', 'garrettcullen@yahoo.com'),
(413, 35, 'user_login', 'destroyer'),
(414, 35, '_user_id', '1'),
(415, 35, '_user_login', 'destroyer'),
(416, 35, '_user_email', 'garrettcullen@yahoo.com'),
(417, 35, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'),
(418, 35, '_message_key', 'user_logged_in'),
(419, 35, '_server_remote_addr', '::1'),
(420, 35, '_server_http_referer', 'http://studiobarre-demo.com/wp-login.php?redirect_to=http%3A%2F%2Fstudiobarre-demo.com%2Fwp-admin%2F&reauth=1'),
(421, 36, 'post_id', '97'),
(422, 36, 'post_type', 'acf-field-group'),
(423, 36, 'post_title', 'Slideshow'),
(424, 36, '_message_key', 'post_created'),
(425, 36, '_user_id', '1'),
(426, 36, '_user_login', 'destroyer'),
(427, 36, '_user_email', 'garrettcullen@yahoo.com'),
(428, 36, '_server_remote_addr', '::1'),
(429, 36, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(430, 37, 'post_id', '98'),
(431, 37, 'post_type', 'acf-field'),
(432, 37, 'post_title', 'Slideshow'),
(433, 37, '_message_key', 'post_updated'),
(434, 37, '_user_id', '1'),
(435, 37, '_user_login', 'destroyer'),
(436, 37, '_user_email', 'garrettcullen@yahoo.com'),
(437, 37, '_server_remote_addr', '::1'),
(438, 37, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(439, 38, 'post_id', '99'),
(440, 38, 'post_type', 'acf-field'),
(441, 38, 'post_title', 'Slide'),
(442, 38, '_message_key', 'post_updated'),
(443, 38, '_user_id', '1'),
(444, 38, '_user_login', 'destroyer'),
(445, 38, '_user_email', 'garrettcullen@yahoo.com'),
(446, 38, '_server_remote_addr', '::1'),
(447, 38, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(448, 39, 'post_id', '100'),
(449, 39, 'post_type', 'acf-field'),
(450, 39, 'post_title', 'Page Link'),
(451, 39, '_message_key', 'post_updated'),
(452, 39, '_user_id', '1'),
(453, 39, '_user_login', 'destroyer'),
(454, 39, '_user_email', 'garrettcullen@yahoo.com'),
(455, 39, '_server_remote_addr', '::1'),
(456, 39, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(457, 40, 'post_id', '97'),
(458, 40, 'post_type', 'acf-field-group'),
(459, 40, 'post_title', 'Slideshow'),
(460, 40, 'post_prev_post_title', 'Auto Draft'),
(461, 40, 'post_new_post_title', 'Slideshow'),
(462, 40, 'post_prev_post_name', ''),
(463, 40, 'post_new_post_name', 'group_59d0451f7af36'),
(464, 40, 'post_prev_post_content', ''),
(465, 40, 'post_new_post_content', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}'),
(466, 40, 'post_prev_post_status', 'auto-draft'),
(467, 40, 'post_new_post_status', 'publish'),
(468, 40, 'post_prev_post_date', '2017-10-01 01:30:07'),
(469, 40, 'post_new_post_date', '2017-10-01 01:32:40'),
(470, 40, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(471, 40, 'post_new_post_date_gmt', '2017-10-01 01:32:40'),
(472, 40, 'post_prev_post_excerpt', ''),
(473, 40, 'post_new_post_excerpt', 'slideshow'),
(474, 40, '_message_key', 'post_updated'),
(475, 40, '_user_id', '1'),
(476, 40, '_user_login', 'destroyer'),
(477, 40, '_user_email', 'garrettcullen@yahoo.com'),
(478, 40, '_server_remote_addr', '::1'),
(479, 40, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(480, 41, 'post_id', '97'),
(481, 41, 'post_type', 'acf-field-group'),
(482, 41, 'post_title', 'Slideshow'),
(483, 41, '_message_key', 'post_updated'),
(484, 41, '_user_id', '1'),
(485, 41, '_user_login', 'destroyer'),
(486, 41, '_user_email', 'garrettcullen@yahoo.com'),
(487, 41, '_server_remote_addr', '::1'),
(488, 41, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(489, 42, 'post_id', '101'),
(490, 42, 'post_type', 'acf-field'),
(491, 42, 'post_title', 'Video Link'),
(492, 42, '_message_key', 'post_updated'),
(493, 42, '_user_id', '1'),
(494, 42, '_user_login', 'destroyer'),
(495, 42, '_user_email', 'garrettcullen@yahoo.com'),
(496, 42, '_server_remote_addr', '::1'),
(497, 42, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(498, 43, 'post_id', '102'),
(499, 43, 'post_type', 'acf-field'),
(500, 43, 'post_title', 'Video or Linked Slide?') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(501, 43, '_message_key', 'post_updated'),
(502, 43, '_user_id', '1'),
(503, 43, '_user_login', 'destroyer'),
(504, 43, '_user_email', 'garrettcullen@yahoo.com'),
(505, 43, '_server_remote_addr', '::1'),
(506, 43, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(507, 44, 'post_id', '97'),
(508, 44, 'post_type', 'acf-field-group'),
(509, 44, 'post_title', 'Slideshow'),
(510, 44, '_message_key', 'post_updated'),
(511, 44, '_user_id', '1'),
(512, 44, '_user_login', 'destroyer'),
(513, 44, '_user_email', 'garrettcullen@yahoo.com'),
(514, 44, '_server_remote_addr', '::1'),
(515, 44, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(516, 45, 'post_id', '97'),
(517, 45, 'post_type', 'acf-field-group'),
(518, 45, 'post_title', 'Slideshow'),
(519, 45, '_message_key', 'post_updated'),
(520, 45, '_user_id', '1'),
(521, 45, '_user_login', 'destroyer'),
(522, 45, '_user_email', 'garrettcullen@yahoo.com'),
(523, 45, '_server_remote_addr', '::1'),
(524, 45, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(525, 46, 'post_id', '102'),
(526, 46, 'post_type', 'acf-field'),
(527, 46, 'post_title', 'Video or Linked Slide?'),
(528, 46, '_message_key', 'post_updated'),
(529, 46, '_user_id', '1'),
(530, 46, '_user_login', 'destroyer'),
(531, 46, '_user_email', 'garrettcullen@yahoo.com'),
(532, 46, '_server_remote_addr', '::1'),
(533, 46, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(534, 47, 'post_id', '100'),
(535, 47, 'post_type', 'acf-field'),
(536, 47, 'post_title', 'Page Link'),
(537, 47, '_message_key', 'post_updated'),
(538, 47, '_user_id', '1'),
(539, 47, '_user_login', 'destroyer'),
(540, 47, '_user_email', 'garrettcullen@yahoo.com'),
(541, 47, '_server_remote_addr', '::1'),
(542, 47, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(543, 48, 'post_id', '101'),
(544, 48, 'post_type', 'acf-field'),
(545, 48, 'post_title', 'Video Link'),
(546, 48, '_message_key', 'post_updated'),
(547, 48, '_user_id', '1'),
(548, 48, '_user_login', 'destroyer'),
(549, 48, '_user_email', 'garrettcullen@yahoo.com'),
(550, 48, '_server_remote_addr', '::1'),
(551, 48, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(552, 49, 'post_id', '99'),
(553, 49, 'post_type', 'acf-field'),
(554, 49, 'post_title', 'Slide'),
(555, 49, '_message_key', 'post_updated'),
(556, 49, '_user_id', '1'),
(557, 49, '_user_login', 'destroyer'),
(558, 49, '_user_email', 'garrettcullen@yahoo.com'),
(559, 49, '_server_remote_addr', '::1'),
(560, 49, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(561, 50, 'post_id', '97'),
(562, 50, 'post_type', 'acf-field-group'),
(563, 50, 'post_title', 'Slideshow'),
(564, 50, '_message_key', 'post_updated'),
(565, 50, '_user_id', '1'),
(566, 50, '_user_login', 'destroyer'),
(567, 50, '_user_email', 'garrettcullen@yahoo.com'),
(568, 50, '_server_remote_addr', '::1'),
(569, 50, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(570, 51, 'post_id', '97'),
(571, 51, 'post_type', 'acf-field-group'),
(572, 51, 'post_title', 'Slideshow'),
(573, 51, '_message_key', 'post_updated'),
(574, 51, '_user_id', '1'),
(575, 51, '_user_login', 'destroyer'),
(576, 51, '_user_email', 'garrettcullen@yahoo.com'),
(577, 51, '_server_remote_addr', '::1'),
(578, 51, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(579, 52, 'post_id', '99'),
(580, 52, 'post_type', 'acf-field'),
(581, 52, 'post_title', 'Desktop Slide'),
(582, 52, '_message_key', 'post_updated'),
(583, 52, '_user_id', '1'),
(584, 52, '_user_login', 'destroyer'),
(585, 52, '_user_email', 'garrettcullen@yahoo.com'),
(586, 52, '_server_remote_addr', '::1'),
(587, 52, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(588, 53, 'post_id', '97'),
(589, 53, 'post_type', 'acf-field-group'),
(590, 53, 'post_title', 'Slideshow'),
(591, 53, '_message_key', 'post_updated'),
(592, 53, '_user_id', '1'),
(593, 53, '_user_login', 'destroyer'),
(594, 53, '_user_email', 'garrettcullen@yahoo.com'),
(595, 53, '_server_remote_addr', '::1'),
(596, 53, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(597, 54, 'post_id', '97'),
(598, 54, 'post_type', 'acf-field-group'),
(599, 54, 'post_title', 'Slideshow'),
(600, 54, '_message_key', 'post_updated') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(601, 54, '_user_id', '1'),
(602, 54, '_user_login', 'destroyer'),
(603, 54, '_user_email', 'garrettcullen@yahoo.com'),
(604, 54, '_server_remote_addr', '::1'),
(605, 54, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(606, 55, 'post_id', '103'),
(607, 55, 'post_type', 'acf-field'),
(608, 55, 'post_title', 'Mobile Slide'),
(609, 55, '_message_key', 'post_updated'),
(610, 55, '_user_id', '1'),
(611, 55, '_user_login', 'destroyer'),
(612, 55, '_user_email', 'garrettcullen@yahoo.com'),
(613, 55, '_server_remote_addr', '::1'),
(614, 55, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(615, 56, 'post_id', '97'),
(616, 56, 'post_type', 'acf-field-group'),
(617, 56, 'post_title', 'Slideshow'),
(618, 56, '_message_key', 'post_updated'),
(619, 56, '_user_id', '1'),
(620, 56, '_user_login', 'destroyer'),
(621, 56, '_user_email', 'garrettcullen@yahoo.com'),
(622, 56, '_server_remote_addr', '::1'),
(623, 56, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(624, 57, 'post_type', 'attachment'),
(625, 57, 'attachment_id', '63'),
(626, 57, 'attachment_title', 'Screen Shot 2017-09-18 at 8.33.40 PM'),
(627, 57, 'attachment_filename', 'Screen-Shot-2017-09-18-at-8.33.40-PM.png'),
(628, 57, 'attachment_mime', 'image/png'),
(629, 57, '_message_key', 'attachment_deleted'),
(630, 57, '_user_id', '1'),
(631, 57, '_user_login', 'destroyer'),
(632, 57, '_user_email', 'garrettcullen@yahoo.com'),
(633, 57, '_server_remote_addr', '::1'),
(634, 57, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(635, 58, 'post_type', 'attachment'),
(636, 58, 'attachment_id', '104'),
(637, 58, 'attachment_title', 'm1'),
(638, 58, 'attachment_filename', 'm1.jpg'),
(639, 58, 'attachment_mime', 'image/jpeg'),
(640, 58, 'attachment_filesize', '176430'),
(641, 58, '_message_key', 'attachment_created'),
(642, 58, '_user_id', '1'),
(643, 58, '_user_login', 'destroyer'),
(644, 58, '_user_email', 'garrettcullen@yahoo.com'),
(645, 58, '_server_remote_addr', '::1'),
(646, 58, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(647, 59, 'post_type', 'attachment'),
(648, 59, 'attachment_id', '105'),
(649, 59, 'attachment_title', 'm2'),
(650, 59, 'attachment_filename', 'm2.jpg'),
(651, 59, 'attachment_mime', 'image/jpeg'),
(652, 59, 'attachment_filesize', '122141'),
(653, 59, '_message_key', 'attachment_created'),
(654, 59, '_user_id', '1'),
(655, 59, '_user_login', 'destroyer'),
(656, 59, '_user_email', 'garrettcullen@yahoo.com'),
(657, 59, '_server_remote_addr', '::1'),
(658, 59, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(659, 60, 'post_type', 'attachment'),
(660, 60, 'attachment_id', '106'),
(661, 60, 'attachment_title', 'm3'),
(662, 60, 'attachment_filename', 'm3.jpg'),
(663, 60, 'attachment_mime', 'image/jpeg'),
(664, 60, 'attachment_filesize', '165130'),
(665, 60, '_message_key', 'attachment_created'),
(666, 60, '_user_id', '1'),
(667, 60, '_user_login', 'destroyer'),
(668, 60, '_user_email', 'garrettcullen@yahoo.com'),
(669, 60, '_server_remote_addr', '::1'),
(670, 60, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(671, 61, 'post_type', 'attachment'),
(672, 61, 'attachment_id', '107'),
(673, 61, 'attachment_title', 'm4'),
(674, 61, 'attachment_filename', 'm4.jpg'),
(675, 61, 'attachment_mime', 'image/jpeg'),
(676, 61, 'attachment_filesize', '104865'),
(677, 61, '_message_key', 'attachment_created'),
(678, 61, '_user_id', '1'),
(679, 61, '_user_login', 'destroyer'),
(680, 61, '_user_email', 'garrettcullen@yahoo.com'),
(681, 61, '_server_remote_addr', '::1'),
(682, 61, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(683, 62, 'post_type', 'attachment'),
(684, 62, 'attachment_id', '108'),
(685, 62, 'attachment_title', 'm5'),
(686, 62, 'attachment_filename', 'm5.jpg'),
(687, 62, 'attachment_mime', 'image/jpeg'),
(688, 62, 'attachment_filesize', '186404'),
(689, 62, '_message_key', 'attachment_created'),
(690, 62, '_user_id', '1'),
(691, 62, '_user_login', 'destroyer'),
(692, 62, '_user_email', 'garrettcullen@yahoo.com'),
(693, 62, '_server_remote_addr', '::1'),
(694, 62, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(695, 63, 'post_type', 'attachment'),
(696, 63, 'attachment_id', '109'),
(697, 63, 'attachment_title', 'slide-clientresults'),
(698, 63, 'attachment_filename', 'slide-clientresults.jpg'),
(699, 63, 'attachment_mime', 'image/jpeg'),
(700, 63, 'attachment_filesize', '217490') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(701, 63, '_message_key', 'attachment_created'),
(702, 63, '_user_id', '1'),
(703, 63, '_user_login', 'destroyer'),
(704, 63, '_user_email', 'garrettcullen@yahoo.com'),
(705, 63, '_server_remote_addr', '::1'),
(706, 63, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(707, 64, 'post_type', 'attachment'),
(708, 64, 'attachment_id', '110'),
(709, 64, 'attachment_title', 'slide-findclass'),
(710, 64, 'attachment_filename', 'slide-findclass.jpg'),
(711, 64, 'attachment_mime', 'image/jpeg'),
(712, 64, 'attachment_filesize', '237606'),
(713, 64, '_message_key', 'attachment_created'),
(714, 64, '_user_id', '1'),
(715, 64, '_user_login', 'destroyer'),
(716, 64, '_user_email', 'garrettcullen@yahoo.com'),
(717, 64, '_server_remote_addr', '::1'),
(718, 64, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(719, 65, 'post_type', 'attachment'),
(720, 65, 'attachment_id', '111'),
(721, 65, 'attachment_title', 'slide-ourstory'),
(722, 65, 'attachment_filename', 'slide-ourstory.jpg'),
(723, 65, 'attachment_mime', 'image/jpeg'),
(724, 65, 'attachment_filesize', '140626'),
(725, 65, '_message_key', 'attachment_created'),
(726, 65, '_user_id', '1'),
(727, 65, '_user_login', 'destroyer'),
(728, 65, '_user_email', 'garrettcullen@yahoo.com'),
(729, 65, '_server_remote_addr', '::1'),
(730, 65, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(731, 66, 'post_type', 'attachment'),
(732, 66, 'attachment_id', '112'),
(733, 66, 'attachment_title', 'slide-society'),
(734, 66, 'attachment_filename', 'slide-society.jpg'),
(735, 66, 'attachment_mime', 'image/jpeg'),
(736, 66, 'attachment_filesize', '167827'),
(737, 66, '_message_key', 'attachment_created'),
(738, 66, '_user_id', '1'),
(739, 66, '_user_login', 'destroyer'),
(740, 66, '_user_email', 'garrettcullen@yahoo.com'),
(741, 66, '_server_remote_addr', '::1'),
(742, 66, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(743, 67, 'post_type', 'attachment'),
(744, 67, 'attachment_id', '113'),
(745, 67, 'attachment_title', 'slide-video'),
(746, 67, 'attachment_filename', 'slide-video.jpg'),
(747, 67, 'attachment_mime', 'image/jpeg'),
(748, 67, 'attachment_filesize', '243268'),
(749, 67, '_message_key', 'attachment_created'),
(750, 67, '_user_id', '1'),
(751, 67, '_user_login', 'destroyer'),
(752, 67, '_user_email', 'garrettcullen@yahoo.com'),
(753, 67, '_server_remote_addr', '::1'),
(754, 67, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(755, 68, 'post_id', '5'),
(756, 68, 'post_type', 'page'),
(757, 68, 'post_title', 'Welcome To Studio Barre'),
(758, 68, '_message_key', 'post_updated'),
(759, 68, '_user_id', '1'),
(760, 68, '_user_login', 'destroyer'),
(761, 68, '_user_email', 'garrettcullen@yahoo.com'),
(762, 68, '_server_remote_addr', '::1'),
(763, 68, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(764, 69, 'post_id', '97'),
(765, 69, 'post_type', 'acf-field-group'),
(766, 69, 'post_title', 'Slideshow'),
(767, 69, '_message_key', 'post_updated'),
(768, 69, '_user_id', '1'),
(769, 69, '_user_login', 'destroyer'),
(770, 69, '_user_email', 'garrettcullen@yahoo.com'),
(771, 69, '_server_remote_addr', '::1'),
(772, 69, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(773, 70, 'post_id', '102'),
(774, 70, 'post_type', 'acf-field'),
(775, 70, 'post_title', 'Video or Linked Slide?'),
(776, 70, '_message_key', 'post_updated'),
(777, 70, '_user_id', '1'),
(778, 70, '_user_login', 'destroyer'),
(779, 70, '_user_email', 'garrettcullen@yahoo.com'),
(780, 70, '_server_remote_addr', '::1'),
(781, 70, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(782, 71, 'post_id', '100'),
(783, 71, 'post_type', 'acf-field'),
(784, 71, 'post_title', 'Page Link'),
(785, 71, '_message_key', 'post_updated'),
(786, 71, '_user_id', '1'),
(787, 71, '_user_login', 'destroyer'),
(788, 71, '_user_email', 'garrettcullen@yahoo.com'),
(789, 71, '_server_remote_addr', '::1'),
(790, 71, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(791, 72, 'post_id', '97'),
(792, 72, 'post_type', 'acf-field-group'),
(793, 72, 'post_title', 'Slideshow'),
(794, 72, '_message_key', 'post_updated'),
(795, 72, '_user_id', '1'),
(796, 72, '_user_login', 'destroyer'),
(797, 72, '_user_email', 'garrettcullen@yahoo.com'),
(798, 72, '_server_remote_addr', '::1'),
(799, 72, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(800, 73, 'post_id', '38') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(801, 73, 'post_type', 'page'),
(802, 73, 'post_title', 'About Us'),
(803, 73, '_message_key', 'post_trashed'),
(804, 73, '_user_id', '1'),
(805, 73, '_user_login', 'destroyer'),
(806, 73, '_user_email', 'garrettcullen@yahoo.com'),
(807, 73, '_server_remote_addr', '::1'),
(808, 73, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/edit.php?post_type=page'),
(809, 74, 'menu_id', '2'),
(810, 74, 'menu_name', 'Top Nav'),
(811, 74, 'menu_items_added', '1'),
(812, 74, 'menu_items_removed', '1'),
(813, 74, '_message_key', 'edited_menu'),
(814, 74, '_user_id', '1'),
(815, 74, '_user_login', 'destroyer'),
(816, 74, '_user_email', 'garrettcullen@yahoo.com'),
(817, 74, '_server_remote_addr', '::1'),
(818, 74, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(819, 75, 'term_id', '2'),
(820, 75, 'from_term_name', 'Top Nav'),
(821, 75, 'from_term_taxonomy', 'nav_menu'),
(822, 75, 'from_term_slug', 'top-nav'),
(823, 75, 'from_term_description', ''),
(824, 75, 'to_term_name', 'Top Nav'),
(825, 75, 'to_term_taxonomy', 'nav_menu'),
(826, 75, 'to_term_slug', 'null'),
(827, 75, 'to_term_description', ''),
(828, 75, '_message_key', 'edited_term'),
(829, 75, '_user_id', '1'),
(830, 75, '_user_login', 'destroyer'),
(831, 75, '_user_email', 'garrettcullen@yahoo.com'),
(832, 75, '_server_remote_addr', '::1'),
(833, 75, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(834, 76, 'post_id', '97'),
(835, 76, 'post_type', 'acf-field-group'),
(836, 76, 'post_title', 'Slideshow'),
(837, 76, '_message_key', 'post_updated'),
(838, 76, '_user_id', '1'),
(839, 76, '_user_login', 'destroyer'),
(840, 76, '_user_email', 'garrettcullen@yahoo.com'),
(841, 76, '_server_remote_addr', '::1'),
(842, 76, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(843, 77, 'post_id', '103'),
(844, 77, 'post_type', 'acf-field'),
(845, 77, 'post_title', 'Mobile Slide'),
(846, 77, '_message_key', 'post_deleted'),
(847, 77, '_user_id', '1'),
(848, 77, '_user_login', 'destroyer'),
(849, 77, '_user_email', 'garrettcullen@yahoo.com'),
(850, 77, '_server_remote_addr', '::1'),
(851, 77, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(852, 78, 'post_id', '97'),
(853, 78, 'post_type', 'acf-field-group'),
(854, 78, 'post_title', 'Slideshow'),
(855, 78, '_message_key', 'post_updated'),
(856, 78, '_user_id', '1'),
(857, 78, '_user_login', 'destroyer'),
(858, 78, '_user_email', 'garrettcullen@yahoo.com'),
(859, 78, '_server_remote_addr', '::1'),
(860, 78, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(861, 79, 'post_id', '5'),
(862, 79, 'post_type', 'page'),
(863, 79, 'post_title', 'Welcome To Studio Barre'),
(864, 79, '_message_key', 'post_updated'),
(865, 79, '_user_id', '1'),
(866, 79, '_user_login', 'destroyer'),
(867, 79, '_user_email', 'garrettcullen@yahoo.com'),
(868, 79, '_server_remote_addr', '::1'),
(869, 79, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(870, 80, 'post_id', '97'),
(871, 80, 'post_type', 'acf-field-group'),
(872, 80, 'post_title', 'Slideshow'),
(873, 80, '_message_key', 'post_updated'),
(874, 80, '_user_id', '1'),
(875, 80, '_user_login', 'destroyer'),
(876, 80, '_user_email', 'garrettcullen@yahoo.com'),
(877, 80, '_server_remote_addr', '::1'),
(878, 80, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(879, 81, 'post_id', '117'),
(880, 81, 'post_type', 'acf-field'),
(881, 81, 'post_title', 'Mobile Slideshow'),
(882, 81, '_message_key', 'post_updated'),
(883, 81, '_user_id', '1'),
(884, 81, '_user_login', 'destroyer'),
(885, 81, '_user_email', 'garrettcullen@yahoo.com'),
(886, 81, '_server_remote_addr', '::1'),
(887, 81, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(888, 82, 'post_id', '118'),
(889, 82, 'post_type', 'acf-field'),
(890, 82, 'post_title', 'Video or Linked Slide?'),
(891, 82, '_message_key', 'post_updated'),
(892, 82, '_user_id', '1'),
(893, 82, '_user_login', 'destroyer'),
(894, 82, '_user_email', 'garrettcullen@yahoo.com'),
(895, 82, '_server_remote_addr', '::1'),
(896, 82, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(897, 83, 'post_id', '119'),
(898, 83, 'post_type', 'acf-field'),
(899, 83, 'post_title', 'Page Link'),
(900, 83, '_message_key', 'post_updated') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(901, 83, '_user_id', '1'),
(902, 83, '_user_login', 'destroyer'),
(903, 83, '_user_email', 'garrettcullen@yahoo.com'),
(904, 83, '_server_remote_addr', '::1'),
(905, 83, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(906, 84, 'post_id', '120'),
(907, 84, 'post_type', 'acf-field'),
(908, 84, 'post_title', 'Video Link'),
(909, 84, '_message_key', 'post_updated'),
(910, 84, '_user_id', '1'),
(911, 84, '_user_login', 'destroyer'),
(912, 84, '_user_email', 'garrettcullen@yahoo.com'),
(913, 84, '_server_remote_addr', '::1'),
(914, 84, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(915, 85, 'post_id', '121'),
(916, 85, 'post_type', 'acf-field'),
(917, 85, 'post_title', 'Mobile Slide'),
(918, 85, '_message_key', 'post_updated'),
(919, 85, '_user_id', '1'),
(920, 85, '_user_login', 'destroyer'),
(921, 85, '_user_email', 'garrettcullen@yahoo.com'),
(922, 85, '_server_remote_addr', '::1'),
(923, 85, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(924, 86, 'post_id', '97'),
(925, 86, 'post_type', 'acf-field-group'),
(926, 86, 'post_title', 'Slideshow'),
(927, 86, '_message_key', 'post_updated'),
(928, 86, '_user_id', '1'),
(929, 86, '_user_login', 'destroyer'),
(930, 86, '_user_email', 'garrettcullen@yahoo.com'),
(931, 86, '_server_remote_addr', '::1'),
(932, 86, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(933, 87, 'post_id', '97'),
(934, 87, 'post_type', 'acf-field-group'),
(935, 87, 'post_title', 'Slideshow'),
(936, 87, '_message_key', 'post_updated'),
(937, 87, '_user_id', '1'),
(938, 87, '_user_login', 'destroyer'),
(939, 87, '_user_email', 'garrettcullen@yahoo.com'),
(940, 87, '_server_remote_addr', '::1'),
(941, 87, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(942, 88, 'post_id', '122'),
(943, 88, 'post_type', 'acf-field'),
(944, 88, 'post_title', 'Desktop Slideshow'),
(945, 88, '_message_key', 'post_updated'),
(946, 88, '_user_id', '1'),
(947, 88, '_user_login', 'destroyer'),
(948, 88, '_user_email', 'garrettcullen@yahoo.com'),
(949, 88, '_server_remote_addr', '::1'),
(950, 88, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(951, 89, 'post_id', '98'),
(952, 89, 'post_type', 'acf-field'),
(953, 89, 'post_title', 'Slideshow'),
(954, 89, '_message_key', 'post_updated'),
(955, 89, '_user_id', '1'),
(956, 89, '_user_login', 'destroyer'),
(957, 89, '_user_email', 'garrettcullen@yahoo.com'),
(958, 89, '_server_remote_addr', '::1'),
(959, 89, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(960, 90, 'post_id', '123'),
(961, 90, 'post_type', 'acf-field'),
(962, 90, 'post_title', 'Mobile Sections'),
(963, 90, '_message_key', 'post_updated'),
(964, 90, '_user_id', '1'),
(965, 90, '_user_login', 'destroyer'),
(966, 90, '_user_email', 'garrettcullen@yahoo.com'),
(967, 90, '_server_remote_addr', '::1'),
(968, 90, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(969, 91, 'post_id', '117'),
(970, 91, 'post_type', 'acf-field'),
(971, 91, 'post_title', 'Mobile Sections'),
(972, 91, '_message_key', 'post_updated'),
(973, 91, '_user_id', '1'),
(974, 91, '_user_login', 'destroyer'),
(975, 91, '_user_email', 'garrettcullen@yahoo.com'),
(976, 91, '_server_remote_addr', '::1'),
(977, 91, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(978, 92, 'post_id', '97'),
(979, 92, 'post_type', 'acf-field-group'),
(980, 92, 'post_title', 'Slideshow'),
(981, 92, '_message_key', 'post_updated'),
(982, 92, '_user_id', '1'),
(983, 92, '_user_login', 'destroyer'),
(984, 92, '_user_email', 'garrettcullen@yahoo.com'),
(985, 92, '_server_remote_addr', '::1'),
(986, 92, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(987, 93, 'post_id', '97'),
(988, 93, 'post_type', 'acf-field-group'),
(989, 93, 'post_title', 'Slideshow'),
(990, 93, '_message_key', 'post_updated'),
(991, 93, '_user_id', '1'),
(992, 93, '_user_login', 'destroyer'),
(993, 93, '_user_email', 'garrettcullen@yahoo.com'),
(994, 93, '_server_remote_addr', '::1'),
(995, 93, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(996, 94, 'post_id', '124'),
(997, 94, 'post_type', 'acf-field'),
(998, 94, 'post_title', 'Homepage Content'),
(999, 94, '_message_key', 'post_updated'),
(1000, 94, '_user_id', '1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1001, 94, '_user_login', 'destroyer'),
(1002, 94, '_user_email', 'garrettcullen@yahoo.com'),
(1003, 94, '_server_remote_addr', '::1'),
(1004, 94, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1005, 95, 'post_id', '125'),
(1006, 95, 'post_type', 'acf-field'),
(1007, 95, 'post_title', 'Homepage Content'),
(1008, 95, '_message_key', 'post_updated'),
(1009, 95, '_user_id', '1'),
(1010, 95, '_user_login', 'destroyer'),
(1011, 95, '_user_email', 'garrettcullen@yahoo.com'),
(1012, 95, '_server_remote_addr', '::1'),
(1013, 95, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1014, 96, 'post_id', '97'),
(1015, 96, 'post_type', 'acf-field-group'),
(1016, 96, 'post_title', 'Slideshow'),
(1017, 96, '_message_key', 'post_updated'),
(1018, 96, '_user_id', '1'),
(1019, 96, '_user_login', 'destroyer'),
(1020, 96, '_user_email', 'garrettcullen@yahoo.com'),
(1021, 96, '_server_remote_addr', '::1'),
(1022, 96, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1023, 97, 'post_id', '5'),
(1024, 97, 'post_type', 'page'),
(1025, 97, 'post_title', 'Welcome To Studio Barre'),
(1026, 97, '_message_key', 'post_updated'),
(1027, 97, '_user_id', '1'),
(1028, 97, '_user_login', 'destroyer'),
(1029, 97, '_user_email', 'garrettcullen@yahoo.com'),
(1030, 97, '_server_remote_addr', '::1'),
(1031, 97, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1032, 98, 'post_id', '5'),
(1033, 98, 'post_type', 'page'),
(1034, 98, 'post_title', 'Welcome To Studio Barre'),
(1035, 98, '_message_key', 'post_updated'),
(1036, 98, '_user_id', '1'),
(1037, 98, '_user_login', 'destroyer'),
(1038, 98, '_user_email', 'garrettcullen@yahoo.com'),
(1039, 98, '_server_remote_addr', '::1'),
(1040, 98, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1041, 99, 'post_id', '5'),
(1042, 99, 'post_type', 'page'),
(1043, 99, 'post_title', 'Welcome To Studio Barre'),
(1044, 99, '_message_key', 'post_updated'),
(1045, 99, '_user_id', '1'),
(1046, 99, '_user_login', 'destroyer'),
(1047, 99, '_user_email', 'garrettcullen@yahoo.com'),
(1048, 99, '_server_remote_addr', '::1'),
(1049, 99, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1050, 100, 'post_id', '5'),
(1051, 100, 'post_type', 'page'),
(1052, 100, 'post_title', 'Welcome To Studio Barre'),
(1053, 100, '_message_key', 'post_updated'),
(1054, 100, '_user_id', '1'),
(1055, 100, '_user_login', 'destroyer'),
(1056, 100, '_user_email', 'garrettcullen@yahoo.com'),
(1057, 100, '_server_remote_addr', '::1'),
(1058, 100, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1059, 101, 'post_id', '5'),
(1060, 101, 'post_type', 'page'),
(1061, 101, 'post_title', 'Welcome To Studio Barre'),
(1062, 101, '_message_key', 'post_updated'),
(1063, 101, '_user_id', '1'),
(1064, 101, '_user_login', 'destroyer'),
(1065, 101, '_user_email', 'garrettcullen@yahoo.com'),
(1066, 101, '_server_remote_addr', '::1'),
(1067, 101, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1068, 102, 'post_id', '5'),
(1069, 102, 'post_type', 'page'),
(1070, 102, 'post_title', 'Welcome To Studio Barre'),
(1071, 102, '_message_key', 'post_updated'),
(1072, 102, '_user_id', '1'),
(1073, 102, '_user_login', 'destroyer'),
(1074, 102, '_user_email', 'garrettcullen@yahoo.com'),
(1075, 102, '_server_remote_addr', '::1'),
(1076, 102, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1077, 103, 'post_id', '5'),
(1078, 103, 'post_type', 'page'),
(1079, 103, 'post_title', 'Welcome To Studio Barre'),
(1080, 103, '_message_key', 'post_updated'),
(1081, 103, '_user_id', '1'),
(1082, 103, '_user_login', 'destroyer'),
(1083, 103, '_user_email', 'garrettcullen@yahoo.com'),
(1084, 103, '_server_remote_addr', '::1'),
(1085, 103, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1086, 104, 'post_id', '5'),
(1087, 104, 'post_type', 'page'),
(1088, 104, 'post_title', 'Welcome To Studio Barre'),
(1089, 104, '_message_key', 'post_updated'),
(1090, 104, '_user_id', '1'),
(1091, 104, '_user_login', 'destroyer'),
(1092, 104, '_user_email', 'garrettcullen@yahoo.com'),
(1093, 104, '_server_remote_addr', '::1'),
(1094, 104, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1095, 105, 'post_id', '38'),
(1096, 105, 'post_type', 'page'),
(1097, 105, 'post_title', 'About Us'),
(1098, 105, '_message_key', 'post_restored'),
(1099, 105, '_user_id', '1'),
(1100, 105, '_user_login', 'destroyer') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1101, 105, '_user_email', 'garrettcullen@yahoo.com'),
(1102, 105, '_server_remote_addr', '::1'),
(1103, 105, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/edit.php?post_status=trash&post_type=page'),
(1104, 106, 'post_id', '38'),
(1105, 106, 'post_type', 'page'),
(1106, 106, 'post_title', 'About Us'),
(1107, 106, '_message_key', 'post_updated'),
(1108, 106, '_user_id', '1'),
(1109, 106, '_user_login', 'destroyer'),
(1110, 106, '_user_email', 'garrettcullen@yahoo.com'),
(1111, 106, '_server_remote_addr', '::1'),
(1112, 106, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/edit.php?post_status=trash&post_type=page'),
(1113, 107, 'post_id', '10'),
(1114, 107, 'post_type', 'page'),
(1115, 107, 'post_title', 'About Us'),
(1116, 107, '_message_key', 'post_trashed'),
(1117, 107, '_user_id', '1'),
(1118, 107, '_user_login', 'destroyer'),
(1119, 107, '_user_email', 'garrettcullen@yahoo.com'),
(1120, 107, '_server_remote_addr', '::1'),
(1121, 107, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/edit.php?post_type=page'),
(1122, 108, 'menu_id', '2'),
(1123, 108, 'menu_name', 'Top Nav'),
(1124, 108, 'menu_items_added', '1'),
(1125, 108, 'menu_items_removed', '1'),
(1126, 108, '_message_key', 'edited_menu'),
(1127, 108, '_user_id', '1'),
(1128, 108, '_user_login', 'destroyer'),
(1129, 108, '_user_email', 'garrettcullen@yahoo.com'),
(1130, 108, '_server_remote_addr', '::1'),
(1131, 108, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(1132, 109, 'term_id', '2'),
(1133, 109, 'from_term_name', 'Top Nav'),
(1134, 109, 'from_term_taxonomy', 'nav_menu'),
(1135, 109, 'from_term_slug', 'top-nav'),
(1136, 109, 'from_term_description', ''),
(1137, 109, 'to_term_name', 'Top Nav'),
(1138, 109, 'to_term_taxonomy', 'nav_menu'),
(1139, 109, 'to_term_slug', 'null'),
(1140, 109, 'to_term_description', ''),
(1141, 109, '_message_key', 'edited_term'),
(1142, 109, '_user_id', '1'),
(1143, 109, '_user_login', 'destroyer'),
(1144, 109, '_user_email', 'garrettcullen@yahoo.com'),
(1145, 109, '_server_remote_addr', '::1'),
(1146, 109, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(1147, 110, 'post_id', '5'),
(1148, 110, 'post_type', 'page'),
(1149, 110, 'post_title', 'Welcome To Studio Barre'),
(1150, 110, '_message_key', 'post_updated'),
(1151, 110, '_user_id', '1'),
(1152, 110, '_user_login', 'destroyer'),
(1153, 110, '_user_email', 'garrettcullen@yahoo.com'),
(1154, 110, '_server_remote_addr', '::1'),
(1155, 110, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1156, 111, 'post_id', '5'),
(1157, 111, 'post_type', 'page'),
(1158, 111, 'post_title', 'Welcome To Studio Barre'),
(1159, 111, '_message_key', 'post_updated'),
(1160, 111, '_user_id', '1'),
(1161, 111, '_user_login', 'destroyer'),
(1162, 111, '_user_email', 'garrettcullen@yahoo.com'),
(1163, 111, '_server_remote_addr', '::1'),
(1164, 111, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1165, 112, 'post_id', '5'),
(1166, 112, 'post_type', 'page'),
(1167, 112, 'post_title', 'Welcome To Studio Barre'),
(1168, 112, '_message_key', 'post_updated'),
(1169, 112, '_user_id', '1'),
(1170, 112, '_user_login', 'destroyer'),
(1171, 112, '_user_email', 'garrettcullen@yahoo.com'),
(1172, 112, '_server_remote_addr', '::1'),
(1173, 112, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=5&action=edit'),
(1174, 113, 'post_id', '38'),
(1175, 113, 'post_type', 'page'),
(1176, 113, 'post_title', 'About Us'),
(1177, 113, 'post_prev_post_content', ''),
(1178, 113, 'post_new_post_content', '<h2 class="white">Stronger, Leaner, More Confident</h2>\r\n				\r\n				\r\n				<h2>What is Studio Barre?</h2>\r\n				\r\n				<p>Studio Barre {strength. defined.} is a specialized barre workout class that focuses on building core strength, improving posture and developing long and lean muscles, like those of a dancer.</p>\r\n				\r\n				<p>Former professional dancer and fitness expert Shannon Higgins founded Studio Barre in 2012. Our mission is to give every client a results-oriented, full-body sculpting workout that is fun, effective and sassy. Walk into any Studio Barre for a community-loving barre class and walk out stronger, leaner and more confident.</p>\r\n				\r\n				<h2>Get Stronger</h2>\r\n				\r\n				<p>Studio Barre applies the perfect combination of arm, seat, thigh and ab exercises to define and sculpt the body. The 60-minute workout digs deep physically while the music and happy barre{tenders} keep you mentally in the moment and push you toward your best.</p>\r\n				\r\n				<h2>Get Leaner</h2>\r\n				\r\n				<p>Come to class once and feel a difference; come to class 3-4 times per week for a month and you will see a difference! Showing up to the barre consistently and regularly will create lean, long and strong muscles we all love. Our clients are proof that Studio Barre works.</p>\r\n				\r\n				<h2>Gain More Confidence</h2>\r\n				\r\n				<p>We help you build strong shoulders, core and back to literally raise you up. Stand taller and present a more confident stature. As you gain more strength, meet your goals and make new friends, your inner confidence matches your exterior. When you feel good, you look good… happy!</p>'),
(1179, 113, '_message_key', 'post_updated'),
(1180, 113, '_user_id', '1'),
(1181, 113, '_user_login', 'destroyer'),
(1182, 113, '_user_email', 'garrettcullen@yahoo.com'),
(1183, 113, '_server_remote_addr', '::1'),
(1184, 113, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=38&action=edit'),
(1185, 114, 'post_id', '97'),
(1186, 114, 'post_type', 'acf-field-group'),
(1187, 114, 'post_title', 'Slideshow'),
(1188, 114, '_message_key', 'post_updated'),
(1189, 114, '_user_id', '1'),
(1190, 114, '_user_login', 'destroyer'),
(1191, 114, '_user_email', 'garrettcullen@yahoo.com'),
(1192, 114, '_server_remote_addr', '::1'),
(1193, 114, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1194, 115, 'post_id', '102'),
(1195, 115, 'post_type', 'acf-field'),
(1196, 115, 'post_title', 'Video or Linked Slide?'),
(1197, 115, '_message_key', 'post_updated'),
(1198, 115, '_user_id', '1'),
(1199, 115, '_user_login', 'destroyer'),
(1200, 115, '_user_email', 'garrettcullen@yahoo.com') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1201, 115, '_server_remote_addr', '::1'),
(1202, 115, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1203, 116, 'post_id', '97'),
(1204, 116, 'post_type', 'acf-field-group'),
(1205, 116, 'post_title', 'Slideshow'),
(1206, 116, '_message_key', 'post_updated'),
(1207, 116, '_user_id', '1'),
(1208, 116, '_user_login', 'destroyer'),
(1209, 116, '_user_email', 'garrettcullen@yahoo.com'),
(1210, 116, '_server_remote_addr', '::1'),
(1211, 116, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1212, 117, 'post_id', '97'),
(1213, 117, 'post_type', 'acf-field-group'),
(1214, 117, 'post_title', 'Home Page'),
(1215, 117, 'post_prev_post_title', 'Slideshow'),
(1216, 117, 'post_new_post_title', 'Home Page'),
(1217, 117, '_message_key', 'post_updated'),
(1218, 117, '_user_id', '1'),
(1219, 117, '_user_login', 'destroyer'),
(1220, 117, '_user_email', 'garrettcullen@yahoo.com'),
(1221, 117, '_server_remote_addr', '::1'),
(1222, 117, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1223, 118, 'post_id', '97'),
(1224, 118, 'post_type', 'acf-field-group'),
(1225, 118, 'post_title', 'Home Page'),
(1226, 118, 'post_prev_post_title', 'Slideshow'),
(1227, 118, 'post_new_post_title', 'Home Page'),
(1228, 118, 'post_prev_post_excerpt', 'slideshow'),
(1229, 118, 'post_new_post_excerpt', 'home-page'),
(1230, 118, '_message_key', 'post_updated'),
(1231, 118, '_user_id', '1'),
(1232, 118, '_user_login', 'destroyer'),
(1233, 118, '_user_email', 'garrettcullen@yahoo.com'),
(1234, 118, '_server_remote_addr', '::1'),
(1235, 118, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=97&action=edit'),
(1236, 119, 'post_id', '140'),
(1237, 119, 'post_type', 'acf-field-group'),
(1238, 119, 'post_title', 'Inner Banners'),
(1239, 119, '_message_key', 'post_created'),
(1240, 119, '_user_id', '1'),
(1241, 119, '_user_login', 'destroyer'),
(1242, 119, '_user_email', 'garrettcullen@yahoo.com'),
(1243, 119, '_server_remote_addr', '::1'),
(1244, 119, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(1245, 120, 'post_id', '141'),
(1246, 120, 'post_type', 'acf-field'),
(1247, 120, 'post_title', 'Inner Banners'),
(1248, 120, '_message_key', 'post_updated'),
(1249, 120, '_user_id', '1'),
(1250, 120, '_user_login', 'destroyer'),
(1251, 120, '_user_email', 'garrettcullen@yahoo.com'),
(1252, 120, '_server_remote_addr', '::1'),
(1253, 120, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(1254, 121, 'post_id', '140'),
(1255, 121, 'post_type', 'acf-field-group'),
(1256, 121, 'post_title', 'Inner Banners'),
(1257, 121, 'post_prev_post_title', 'Auto Draft'),
(1258, 121, 'post_new_post_title', 'Inner Banners'),
(1259, 121, 'post_prev_post_name', ''),
(1260, 121, 'post_new_post_name', 'group_59d075ee3fe75'),
(1261, 121, 'post_prev_post_content', ''),
(1262, 121, 'post_new_post_content', 'a:7:{s:8:"location";a:4:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-about.php";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-maven.php";}}i:2;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:16:"page-society.php";}}i:3;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:15:"page-mentor.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:7:"excerpt";i:1;s:14:"featured_image";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}'),
(1263, 121, 'post_prev_post_status', 'auto-draft'),
(1264, 121, 'post_new_post_status', 'publish'),
(1265, 121, 'post_prev_post_date', '2017-10-01 04:58:22'),
(1266, 121, 'post_new_post_date', '2017-10-01 05:00:54'),
(1267, 121, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(1268, 121, 'post_new_post_date_gmt', '2017-10-01 05:00:54'),
(1269, 121, 'post_prev_post_excerpt', ''),
(1270, 121, 'post_new_post_excerpt', 'inner-banners'),
(1271, 121, '_message_key', 'post_updated'),
(1272, 121, '_user_id', '1'),
(1273, 121, '_user_login', 'destroyer'),
(1274, 121, '_user_email', 'garrettcullen@yahoo.com'),
(1275, 121, '_server_remote_addr', '::1'),
(1276, 121, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(1277, 122, 'post_type', 'attachment'),
(1278, 122, 'attachment_id', '142'),
(1279, 122, 'attachment_title', 'banner-ourstory'),
(1280, 122, 'attachment_filename', 'banner-ourstory.jpg'),
(1281, 122, 'attachment_mime', 'image/jpeg'),
(1282, 122, 'attachment_filesize', '101919'),
(1283, 122, '_message_key', 'attachment_created'),
(1284, 122, '_user_id', '1'),
(1285, 122, '_user_login', 'destroyer'),
(1286, 122, '_user_email', 'garrettcullen@yahoo.com'),
(1287, 122, '_server_remote_addr', '::1'),
(1288, 122, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=38&action=edit'),
(1289, 123, 'post_id', '38'),
(1290, 123, 'post_type', 'page'),
(1291, 123, 'post_title', 'About Us'),
(1292, 123, '_message_key', 'post_updated'),
(1293, 123, '_user_id', '1'),
(1294, 123, '_user_login', 'destroyer'),
(1295, 123, '_user_email', 'garrettcullen@yahoo.com'),
(1296, 123, '_server_remote_addr', '::1'),
(1297, 123, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=38&action=edit'),
(1298, 124, 'post_type', 'attachment'),
(1299, 124, 'attachment_id', '144'),
(1300, 124, 'attachment_title', 'banner-maven') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1301, 124, 'attachment_filename', 'banner-maven.jpg'),
(1302, 124, 'attachment_mime', 'image/jpeg'),
(1303, 124, 'attachment_filesize', '140770'),
(1304, 124, '_message_key', 'attachment_created'),
(1305, 124, '_user_id', '1'),
(1306, 124, '_user_login', 'destroyer'),
(1307, 124, '_user_email', 'garrettcullen@yahoo.com'),
(1308, 124, '_server_remote_addr', '::1'),
(1309, 124, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=80&action=edit'),
(1310, 125, 'post_type', 'attachment'),
(1311, 125, 'attachment_id', '145'),
(1312, 125, 'attachment_title', 'banner-mentor'),
(1313, 125, 'attachment_filename', 'banner-mentor.jpg'),
(1314, 125, 'attachment_mime', 'image/jpeg'),
(1315, 125, 'attachment_filesize', '159645'),
(1316, 125, '_message_key', 'attachment_created'),
(1317, 125, '_user_id', '1'),
(1318, 125, '_user_login', 'destroyer'),
(1319, 125, '_user_email', 'garrettcullen@yahoo.com'),
(1320, 125, '_server_remote_addr', '::1'),
(1321, 125, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=80&action=edit'),
(1322, 126, 'post_type', 'attachment'),
(1323, 126, 'attachment_id', '146'),
(1324, 126, 'attachment_title', 'banner-society'),
(1325, 126, 'attachment_filename', 'banner-society.jpg'),
(1326, 126, 'attachment_mime', 'image/jpeg'),
(1327, 126, 'attachment_filesize', '94284'),
(1328, 126, '_message_key', 'attachment_created'),
(1329, 126, '_user_id', '1'),
(1330, 126, '_user_login', 'destroyer'),
(1331, 126, '_user_email', 'garrettcullen@yahoo.com'),
(1332, 126, '_server_remote_addr', '::1'),
(1333, 126, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=80&action=edit'),
(1334, 127, 'post_id', '80'),
(1335, 127, 'post_type', 'page'),
(1336, 127, 'post_title', 'Barre Mavens'),
(1337, 127, '_message_key', 'post_updated'),
(1338, 127, '_user_id', '1'),
(1339, 127, '_user_login', 'destroyer'),
(1340, 127, '_user_email', 'garrettcullen@yahoo.com'),
(1341, 127, '_server_remote_addr', '::1'),
(1342, 127, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=80&action=edit'),
(1343, 128, 'post_id', '42'),
(1344, 128, 'post_type', 'page'),
(1345, 128, 'post_title', 'The Society'),
(1346, 128, '_message_key', 'post_updated'),
(1347, 128, '_user_id', '1'),
(1348, 128, '_user_login', 'destroyer'),
(1349, 128, '_user_email', 'garrettcullen@yahoo.com'),
(1350, 128, '_server_remote_addr', '::1'),
(1351, 128, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=42&action=edit'),
(1352, 129, 'post_id', '85'),
(1353, 129, 'post_type', 'page'),
(1354, 129, 'post_title', 'Mentors'),
(1355, 129, '_message_key', 'post_updated'),
(1356, 129, '_user_id', '1'),
(1357, 129, '_user_login', 'destroyer'),
(1358, 129, '_user_email', 'garrettcullen@yahoo.com'),
(1359, 129, '_server_remote_addr', '::1'),
(1360, 129, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/post.php?post=85&action=edit'),
(1361, 130, 'menu_id', '2'),
(1362, 130, 'menu_name', 'Top Nav'),
(1363, 130, 'menu_items_added', '0'),
(1364, 130, 'menu_items_removed', '0'),
(1365, 130, '_message_key', 'edited_menu'),
(1366, 130, '_user_id', '1'),
(1367, 130, '_user_login', 'destroyer'),
(1368, 130, '_user_email', 'garrettcullen@yahoo.com'),
(1369, 130, '_server_remote_addr', '::1'),
(1370, 130, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php'),
(1371, 131, 'term_id', '2'),
(1372, 131, 'from_term_name', 'Top Nav'),
(1373, 131, 'from_term_taxonomy', 'nav_menu'),
(1374, 131, 'from_term_slug', 'top-nav'),
(1375, 131, 'from_term_description', ''),
(1376, 131, 'to_term_name', 'Top Nav'),
(1377, 131, 'to_term_taxonomy', 'nav_menu'),
(1378, 131, 'to_term_slug', 'null'),
(1379, 131, 'to_term_description', ''),
(1380, 131, '_message_key', 'edited_term'),
(1381, 131, '_user_id', '1'),
(1382, 131, '_user_login', 'destroyer'),
(1383, 131, '_user_email', 'garrettcullen@yahoo.com'),
(1384, 131, '_server_remote_addr', '::1'),
(1385, 131, '_server_http_referer', 'http://studiobarre-demo.com/wp-admin/nav-menus.php') ;

#
# End of data contents of table `wp_simple_history_contexts`
# --------------------------------------------------------



#
# Delete any existing table `wp_site`
#

DROP TABLE IF EXISTS `wp_site`;


#
# Table structure of table `wp_site`
#

CREATE TABLE `wp_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_site`
#
INSERT INTO `wp_site` ( `id`, `domain`, `path`) VALUES
(1, 'studiobarre-demo.com', '/') ;

#
# End of data contents of table `wp_site`
# --------------------------------------------------------



#
# Delete any existing table `wp_sitemeta`
#

DROP TABLE IF EXISTS `wp_sitemeta`;


#
# Table structure of table `wp_sitemeta`
#

CREATE TABLE `wp_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=979 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_sitemeta`
#
INSERT INTO `wp_sitemeta` ( `meta_id`, `site_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'site_name', 'Studio Barre Sites'),
(2, 1, 'admin_email', 'garrettcullen@yahoo.com'),
(3, 1, 'admin_user_id', '1'),
(4, 1, 'registration', 'none'),
(5, 1, 'upload_filetypes', 'jpg jpeg png gif mov avi mpg 3gp 3g2 midi mid pdf doc ppt odt pptx docx pps ppsx xls xlsx key mp3 ogg m4a wav mp4 m4v webm ogv flv'),
(6, 1, 'blog_upload_space', '100'),
(7, 1, 'fileupload_maxk', '4000'),
(8, 1, 'site_admins', 'a:1:{i:0;s:9:"destroyer";}'),
(9, 1, 'allowedthemes', 'a:4:{s:20:"studiobarrecorporate";b:1;s:15:"twentyseventeen";b:1;s:14:"studiobarrezee";b:1;s:21:"studiobarreownastudio";b:1;}'),
(10, 1, 'illegal_names', 'a:9:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:5:"files";i:8;s:4:"blog";}'),
(11, 1, 'wpmu_upgrade_site', '38590'),
(12, 1, 'welcome_email', 'Howdy USERNAME,\r\n\r\nYour new SITE_NAME site has been successfully set up at:\r\nBLOG_URL\r\n\r\nYou can log in to the administrator account with the following information:\r\n\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLog in here: BLOG_URLwp-login.php\r\n\r\nWe hope you enjoy your new site. Thanks!\r\n\r\n--The Team @ SITE_NAME'),
(13, 1, 'first_post', 'Welcome to %s. This is your first post. Edit or delete it, then start blogging!'),
(14, 1, 'siteurl', 'http://studiobarre-demo.com/'),
(15, 1, 'add_new_users', '0'),
(16, 1, 'upload_space_check_disabled', '1'),
(17, 1, 'subdomain_install', '0'),
(18, 1, 'global_terms_enabled', '0'),
(19, 1, 'ms_files_rewriting', '0'),
(20, 1, 'initial_db_version', '38590'),
(21, 1, 'active_sitewide_plugins', 'a:10:{s:29:"gravityforms/gravityforms.php";i:1500870274;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:1502076040;s:34:"advanced-custom-fields-pro/acf.php";i:1503373044;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:1503373044;s:47:"healcode-mindbody-widget/healcode-mb-widget.php";i:1506318026;s:24:"wordpress-seo/wp-seo.php";i:1506318050;s:24:"simple-history/index.php";i:1506318081;s:33:"media-library-assistant/index.php";i:1506318136;s:57:"multisite-clone-duplicator/multisite-clone-duplicator.php";i:1506318232;s:63:"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php";i:1506576721;}'),
(22, 1, 'WPLANG', ''),
(28, 1, 'user_count', '1'),
(29, 1, 'blog_count', '3'),
(30, 1, 'can_compress_scripts', '1'),
(37, 1, 'recently_activated', 'a:1:{s:41:"better-wp-security/better-wp-security.php";i:1506318294;}'),
(76, 1, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1506834595;}'),
(162, 1, 'registrationnotification', 'yes'),
(163, 1, 'welcome_user_email', 'Howdy USERNAME,\r\n\r\nYour new account is set up.\r\n\r\nYou can log in with the following information:\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLOGINLINK\r\n\r\nThanks!\r\n\r\n--The Team @ SITE_NAME'),
(545, 1, 'wpseo_ms', 'a:2:{s:6:"access";s:5:"admin";s:11:"defaultblog";s:0:"";}'),
(552, 1, 'mucd_copy_files', 'yes'),
(553, 1, 'mucd_keep_users', 'yes'),
(554, 1, 'mucd_log', 'no'),
(555, 1, 'mucd_log_dir', '/Applications/MAMP/htdocs/studiobarre-new/wp-content/uploads/multisite-clone-duplicator-logs/'),
(556, 1, 'mucd_disable_enhanced_site_select', 'no'),
(557, 1, 'mucd_duplicables', 'all'),
(566, 1, 'itsec-storage', 'a:1:{s:6:"global";a:31:{s:18:"notification_email";a:1:{i:0;s:23:"garrettcullen@yahoo.com";}s:12:"backup_email";a:1:{i:0;s:23:"garrettcullen@yahoo.com";}s:15:"lockout_message";s:5:"error";s:20:"user_lockout_message";s:64:"You have been locked out due to too many invalid login attempts.";s:25:"community_lockout_message";s:77:"Your IP address has been flagged as a threat by the iThemes Security network.";s:9:"blacklist";b:1;s:15:"blacklist_count";i:3;s:16:"blacklist_period";i:7;s:19:"email_notifications";b:1;s:14:"lockout_period";i:15;s:18:"lockout_white_list";a:0:{}s:12:"log_rotation";i:14;s:8:"log_type";s:8:"database";s:12:"log_location";s:82:"/Applications/MAMP/htdocs/studiobarre-new/wp-content/uploads/ithemes-security/logs";s:8:"log_info";s:43:"studio-barre-9nEhcjy5W0wTCoH1pyK6VbnCHlSZ9g";s:14:"allow_tracking";b:0;s:11:"write_files";b:1;s:10:"nginx_file";s:52:"/Applications/MAMP/htdocs/studiobarre-new/nginx.conf";s:24:"infinitewp_compatibility";b:0;s:11:"did_upgrade";b:0;s:9:"lock_file";b:0;s:12:"digest_email";b:0;s:14:"proxy_override";b:0;s:14:"hide_admin_bar";b:0;s:16:"show_error_codes";b:0;s:25:"show_new_dashboard_notice";b:1;s:19:"show_security_check";b:1;s:16:"digest_last_sent";i:1506318282;s:15:"digest_messages";a:0:{}s:5:"build";i:4075;s:20:"activation_timestamp";i:0;}}'),
(578, 1, 'menu_items', 'a:0:{}'),
(579, 1, 'first_page', ''),
(580, 1, 'first_comment', ''),
(581, 1, 'first_comment_url', ''),
(582, 1, 'first_comment_author', ''),
(583, 1, 'limited_email_domains', ''),
(584, 1, 'banned_email_domains', ''),
(585, 1, 'first_comment_email', '') ;

#
# End of data contents of table `wp_sitemeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(31, 2, 0),
(32, 2, 0),
(33, 2, 0),
(34, 2, 0),
(37, 2, 0),
(44, 2, 0),
(45, 2, 0),
(48, 2, 0),
(49, 2, 0),
(50, 2, 0),
(52, 2, 0),
(56, 1, 0),
(58, 1, 0),
(60, 1, 0),
(82, 2, 0),
(88, 2, 0),
(134, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'nav_menu', '', 0, 14) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Nav', 'top-nav', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'destroyer'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"caec12b944991c600eaaf2c3ea8edfe22fe483b4d8364e3f091bfac523ae0f3b";a:4:{s:10:"expiration";i:1506968786;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";s:5:"login";i:1506795986;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '96'),
(17, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(18, 1, 'source_domain', 'studiobarre-demo.com'),
(19, 1, 'primary_blog', '1'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'wp_user-settings', 'libraryContent=browse&align=left&editor=html&urlbutton=none'),
(24, 1, 'wp_user-settings-time', '1506833544'),
(25, 1, 'wp_2_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(26, 1, 'wp_2_user_level', '10'),
(27, 1, 'wp_2_user-settings', 'libraryContent=browse&align=left&editor=html&urlbutton=none'),
(28, 1, 'wp_2_user-settings-time', '1506320023'),
(29, 1, 'wp_2_dashboard_quick_press_last_post_id', '3'),
(30, 1, 'gform_recent_forms', 'a:1:{i:0;s:1:"3";}'),
(31, 1, 'acf_user_settings', 'a:0:{}'),
(32, 1, 'wp_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:551:"To make sure all the links in your texts are counted, we need to analyze all your texts.\n					All you have to do is press the following button and we\'ll go through all your texts for you.\n\n					<button type="button" id="noticeRunLinkIndex" class="button">Count links</button>\n\n					The Text link counter feature provides insights in how many links are found in your text and how many links are referring to your text. This is very helpful when you are improving your <a href="https://yoa.st/15m?utm_content=5.4.2" target="_blank">internal linking</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-reindex-links";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:170:"Don\'t miss your crawl errors: <a href="http://studiobarre-demo.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(33, 1, 'itsec_user_activity_last_seen', '1506318282'),
(34, 1, 'wp_2_yoast_notifications', 'a:1:{i:0;a:2:{s:7:"message";s:184:"Don\'t miss your crawl errors: <a href="http://studiobarre-demo.com/carmel-valley/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(35, 1, 'wp_3_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(36, 1, 'wp_3_user_level', '10'),
(37, 1, 'wp_3_user-settings', 'libraryContent=browse&align=left&editor=html&urlbutton=none'),
(38, 1, 'wp_3_user-settings-time', '1506566918'),
(39, 1, 'wp_3_dashboard_quick_press_last_post_id', '3'),
(40, 1, 'wp_3_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:794:"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href="https://yoa.st/rate-yoast-seo?utm_content=5.4.2">give us a 5 stars rating on WordPress.org</a>!\n\nIf you are experiencing issues, <a href="https://yoa.st/bugreport?utm_content=5.4.2">please file a bug report</a> and we\'ll do our best to help you out.\n\nBy the way, did you know we also have a <a href=\'https://yoa.st/premium-notification?utm_content=5.4.2\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.\n\n<a class="button" href="http://studiobarre-demo.com/franchising/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell">Please don\'t show me this notification anymore</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-upsell-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:182:"Don\'t miss your crawl errors: <a href="http://studiobarre-demo.com/franchising/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(41, 1, '_yoast_wpseo_profile_updated', '1506396041'),
(42, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(43, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`, `spam`, `deleted`) VALUES
(1, 'destroyer', '$P$BNUWMvXQG/jMtjjvz0sAw.khv3todR1', 'destroyer', 'garrettcullen@yahoo.com', '', '2017-07-23 22:11:06', '', 0, 'destroyer', 0, 0) ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_links`
#

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_meta`
#

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;


#
# Table structure of table `wp_yoast_seo_meta`
#

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_meta`
#
INSERT INTO `wp_yoast_seo_meta` ( `object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(5, 0, NULL),
(8, 0, NULL),
(38, 0, NULL),
(42, 0, NULL),
(80, 0, NULL),
(85, 0, NULL) ;

#
# End of data contents of table `wp_yoast_seo_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

